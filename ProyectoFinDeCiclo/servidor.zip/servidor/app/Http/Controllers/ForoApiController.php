<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Foro;
use App\Models\Media;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ForoApiController extends Controller
{
    /**
     * 🔹 Devuelve un listado de foros paginado.
     */
    public function index(): JsonResponse
    {
        $foros = Foro::paginate(10);
        return response()->json([
            'success' => true,
            'data' => $foros
        ]);
    }

    /**
     *  Almacena un nuevo foro en la base de datos.
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'titulo' => 'required|string|max:255',
            'pelicula_asociada' => 'nullable|exists:medias,id',
        ]);

        $foro = Foro::create([
            'titulo' => $request->titulo,
            'pelicula_asociada' => $request->pelicula_asociada,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Foro creado correctamente.',
            'data' => $foro
        ], 201);
    }

    /**
     *  Muestra un foro específico con sus publicaciones.
     */
    public function show($id): JsonResponse
    {
        $foro = Foro::with('pelicula')->find($id);

        if (!$foro) {
            return response()->json([
                'success' => false,
                'message' => 'Foro no encontrado.'
            ], 404);
        }

        $publicaciones = $foro->publicaciones()
            ->with('user') 
            ->orderBy('fecha_creacion', 'desc')
            ->paginate(10);

        return response()->json([
            'success' => true,
            'data' => [
                'foro' => $foro,
                'publicaciones' => $publicaciones
            ]
        ]);
    }

    /**
     * Actualiza un foro en la base de datos.
     */
    public function update(Request $request, $id): JsonResponse
    {
        $foro = Foro::find($id);

        if (!$foro) {
            return response()->json([
                'success' => false,
                'message' => 'Foro no encontrado.'
            ], 404);
        }

        $request->validate([
            'titulo' => 'sometimes|required|string|max:255',
            'pelicula_asociada' => 'nullable|exists:medias,id',
        ]);

        $foro->update([
            'titulo' => $request->titulo ?? $foro->titulo,
            'pelicula_asociada' => $request->pelicula_asociada ?? $foro->pelicula_asociada,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Foro actualizado correctamente.',
            'data' => $foro
        ]);
    }

    /**
     *  Elimina un foro de la base de datos.
     */
    public function destroy($id): JsonResponse
    {
        $foro = Foro::find($id);

        if (!$foro) {
            return response()->json([
                'success' => false,
                'message' => 'Foro no encontrado.'
            ], 404);
        }

        $foro->delete();

        return response()->json([
            'success' => true,
            'message' => 'Foro eliminado correctamente.'
        ]);
    }
}
