<?php

namespace App\Http\Controllers;

use App\Models\Foro;
use App\Models\Media;
use Illuminate\Http\Request;

class ForoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $foros = Foro::paginate(10);
        return view('foros.index', compact('foros'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $medias = Media::all();
        return view('foros.create', compact('medias'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'titulo' => 'required|string|max:255',
            'pelicula_asociada' => 'nullable|exists:medias,id',
        ]);


        $foro = new Foro();
        $foro->titulo = $request->input('titulo');
        $foro->pelicula_asociada = $request->input('pelicula_asociada');
        $foro->save();

        return redirect()->to(path: 'foros')->with('success', 'El foro fue creado correctamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $foro = Foro::findOrFail($id);

        // Paginamos las publicaciones de este foro
        $publicaciones = $foro->publicaciones()->orderBy('fecha_creacion', 'desc')->paginate(10);

        return view('foros.show', compact('foro', 'publicaciones'));
    }



    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $foro = Foro::findOrFail($id);
        $medias = Media::all();
        return view('foros.edit', compact('foro', 'medias'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $foro = Foro::findOrFail($id);

        $request->validate([
            'titulo' => 'sometimes|required|string|max:255',
            'pelicula_asociada' => 'nullable|exists:medias,id',
        ]);

        $foro->titulo = $request->input('titulo');
        $foro->pelicula_asociada = $request->input('pelicula_asociada');
        $foro->save();

        return redirect()->route('foros.index')->with('success', 'El foro fue actualizado correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $foro = Foro::findOrFail($id);

        $foro->delete();
        return redirect()->to(path: 'foros')->with('success', 'El foro fué eliminado correctamente.');
    }
}
