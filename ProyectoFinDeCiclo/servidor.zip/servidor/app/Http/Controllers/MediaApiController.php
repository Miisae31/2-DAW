<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Media;
use App\Models\Pelicula;
use App\Models\Serie;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
class MediaApiController extends Controller
{
    /**
     *  Devuelve un listado paginado de medios (películas y series).
     */

public function index(): JsonResponse
{
    $medias = Media::with(['pelicula', 'serie'])->get();

    $formatted = $medias->map(function ($media) {
        return [
            'id' => $media->id,
            'titulo' => $media->titulo,
            'anio_creacion' => $media->anio_creacion,
            'sinopsis' => $media->sinopsis,
            'genero' => $media->genero,
            'puntuacion' => $media->puntuacion,
            'trailer' => $media->trailer,
            'portada' => config('app.url') . Storage::url($media->portada), // URL absoluta completa
            'tipo' => $media->pelicula ? 'pelicula' : ($media->serie ? 'serie' : 'desconocido')
        ];
    });

    return response()->json([
        'success' => true,
        'data' => $formatted
    ]);
}

    /**
     * Guarda una nueva película o serie en la base de datos.
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'titulo' => 'required|string|max:255',
            'anio_creacion' => 'required|integer',
            'director' => 'required|string|max:255',
            'guion' => 'required|string|max:255',
            'pais' => 'required|string|max:255',
            'sinopsis' => 'required|string',
            'genero' => 'required|string|max:255',
            'trailer' => 'nullable|string',
            'puntuacion' => 'nullable|numeric|min:0|max:10',
            'tipo' => 'required|in:pelicula,serie',
            'duracion' => 'nullable|required_if:tipo,pelicula|integer',
            'n_episodios' => 'nullable|required_if:tipo,serie|integer',
            'temporadas' => 'nullable|required_if:tipo,serie|integer',
            'portada' => 'nullable|image|max:2048',
        ]);

        $media = new Media();
        $media->fill($request->only([
            'titulo',
            'anio_creacion',
            'director',
            'guion',
            'pais',
            'sinopsis',
            'genero',
            'trailer',
            'puntuacion'
        ]));

        if ($request->hasFile('portada')) {
            $rutaImagen = $request->file('portada')->store('media/img/portadas', 'public');
            $media->portada = "storage/$rutaImagen";
        }

        $media->save();

        if ($request->tipo === 'pelicula') { // Si es una película
            Pelicula::create([
                'media_id' => $media->id,
                'duracion' => $request->duracion
            ]);
        } elseif ($request->tipo === 'serie') { // Si es una serie
            Serie::create([
                'media_id' => $media->id,
                'n_episodios' => $request->n_episodios,
                'temporadas' => $request->temporadas
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Media creada correctamente',
            'data' => $media
        ], 201);
    }

    /**
     *  Devuelve una película o serie específica.
     */


    public function show($id): JsonResponse
    {
        $media = Media::with(['pelicula', 'serie'])->find($id);

        if (!$media) {
            return response()->json([
                'success' => false,
                'message' => 'Media no encontrada'
            ], 404);
        }

        $formatted = [
            'id' => $media->id,
            'titulo' => $media->titulo,
            'anio_creacion' => $media->anio_creacion,
            'sinopsis' => $media->sinopsis,
            'genero' => $media->genero,
            'puntuacion' => $media->puntuacion,
            'trailer' => $media->trailer,
            'portada' => config('app.url') . Storage::url($media->portada), // URL absoluta completa
            'tipo' => $media->pelicula ? 'pelicula' : ($media->serie ? 'serie' : 'desconocido')
        ];

        return response()->json([
            'success' => true,
            'data' => $formatted
        ]);
    }


    /**
     *  Actualiza una película o serie en la base de datos.
     */
    public function update(Request $request, $id): JsonResponse
    {
        $media = Media::find($id);

        if (!$media) {
            return response()->json([
                'success' => false,
                'message' => 'Media no encontrada'
            ], 404);
        }

        $request->validate([
            'titulo' => 'required|string|max:255',
            'anio_creacion' => 'required|integer',
            'director' => 'required|string|max:255',
            'guion' => 'required|string|max:255',
            'pais' => 'required|string|max:255',
            'sinopsis' => 'required|string',
            'genero' => 'required|string|max:255',
            'trailer' => 'nullable|string',
            'puntuacion' => 'nullable|numeric|min:0|max:10',
            'tipo' => 'required|in:pelicula,serie',
            'duracion' => 'nullable|required_if:tipo,pelicula|integer',
            'n_episodios' => 'nullable|required_if:tipo,serie|integer',
            'temporadas' => 'nullable|required_if:tipo,serie|integer',
            'portada' => 'nullable|image|max:2048',
        ]);

        $media->fill($request->only([
            'titulo',
            'anio_creacion',
            'director',
            'guion',
            'pais',
            'sinopsis',
            'genero',
            'trailer',
            'puntuacion'
        ]));

        if ($request->hasFile('portada')) {
            if ($media->portada) {
                Storage::delete(str_replace('storage/', 'public/', $media->portada));
            }
            $rutaImagen = $request->file('portada')->store('media/img/portadas', 'public');
            $media->portada = "storage/$rutaImagen";
        }

        $media->save();

        if ($request->tipo === 'pelicula' && $media->pelicula) {
            $media->pelicula->update(['duracion' => $request->duracion]);
        } elseif ($request->tipo === 'serie' && $media->serie) {
            $media->serie->update([
                'n_episodios' => $request->n_episodios,
                'temporadas' => $request->temporadas
            ]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Media actualizada correctamente',
            'data' => $media
        ]);
    }

    /**
     *  Elimina una película o serie de la base de datos.
     */
    public function destroy($id): JsonResponse
    {
        $media = Media::find($id);

        if (!$media) {
            return response()->json([
                'success' => false,
                'message' => 'Media no encontrada'
            ], 404);
        }

        if ($media->portada) {
            Storage::delete(str_replace('storage/', 'public/', $media->portada));
        }

        $media->delete();

        return response()->json([
            'success' => true,
            'message' => 'Media eliminada correctamente'
        ]);
    }

    /**
     *  API para buscar medios por título (usado en buscador AJAX).
     */
    public function apifetchMedias(Request $request): JsonResponse
    {
        $nombres = Media::where("titulo", "like", $request->texto . "%")->take(10)->get(); // Buscamos los medios que empiecen por el texto
        return response()->json($nombres); // Devolvemos los nombres en formato JSON
    }

    //Metodo peticiones con token

    public function indexConToken(Request $request): JsonResponse
{
    $request->validate([
        'email' => 'required|email',
        'password' => 'required|string',
    ]);

    $email = $request->input('email');
    $password = $request->input('password');

    $premiumToken = $request->header('X-Premium-Token');

    if (!$premiumToken) {
        return response()->json([
            'success' => false,
            'message' => 'Token premium no proporcionado en cabecera.'
        ], 401);
    }

    $user = User::where('email', $email)->first();

    if (!$user) {
        return response()->json([
            'success' => false,
            'message' => 'Usuario no encontrado.'
        ], 404);
    }

    if (!Hash::check($password, $user->password)) {
        return response()->json([
            'success' => false,
            'message' => 'Contraseña incorrecta.'
        ], 401);
    }

    if (!$user->token_premium || $user->token_premium !== $premiumToken) {
        return response()->json([
            'success' => false,
            'message' => 'Token premium inválido o usuario no tiene acceso premium.'
        ], 403);
    }

    $medias = Media::with(['pelicula', 'serie'])->get();

    $formatted = $medias->map(function ($media) {
        return [
            'id' => $media->id,
            'titulo' => $media->titulo,
            'anio_creacion' => $media->anio_creacion,
            'sinopsis' => $media->sinopsis,
            'genero' => $media->genero,
            'puntuacion' => $media->puntuacion,
            'trailer' => $media->trailer,
            'portada' => config('app.url') . Storage::url($media->portada),
            'tipo' => $media->pelicula ? 'pelicula' : ($media->serie ? 'serie' : 'desconocido'),
        ];
    });

    return response()->json([
        'success' => true,
        'data' => $formatted
    ]);
}
}
