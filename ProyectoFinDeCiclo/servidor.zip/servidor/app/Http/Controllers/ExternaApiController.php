<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ExternaApiController extends Controller
{
    public function obterDatos()
    {
        // Realizamos la solicitud GET a la API
        $response = Http::withHeaders([

            'x-rapidapi-host' => 'imdb236.p.rapidapi.com',
            'x-rapidapi-key' => '69d74599a7mshf2f05c55c1da843p114d3cjsn45df98ad50ad',
            
        ])->get('https://imdb236.p.rapidapi.com/api/imdb/most-popular-movies');

        // Verificar si la respuesta es exitosa
        if ($response->successful()) {
            return response()->json([
                'success' => true,
                'data' => $response->json(),
            ]);
        } else {
            return response()->json([
                'success' => false,
                'error' => 'No se pudo obtener datos de la API externa',
            ], 500);
        }
    }
}
