<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ExternaController extends Controller
{
    public function obterDatos()
    {
        // Realizamos la solicitud GET a la API
        $response = Http::withHeaders([
            'x-rapidapi-key' => '69d74599a7mshf2f05c55c1da843p114d3cjsn45df98ad50ad',
            'x-rapidapi-host' => 'imdb236.p.rapidapi.com',
        ])->get('https://imdb236.p.rapidapi.com/api/imdb/most-popular-movies');

        // Devolvemos la respuesta de la API
        // Verificamos si la solicitud fue exitosa
        if ($response->successful()) {
            $peliculas = $response->json(); // Convierte la respuesta en un array
            return view('peliculas.api', compact('peliculas')); // Pasamos los datos a la vista
        } else {
            return view('peliculas.api')->with('error', 'No se pudo obtener datos de la API');
        }
    }
}
