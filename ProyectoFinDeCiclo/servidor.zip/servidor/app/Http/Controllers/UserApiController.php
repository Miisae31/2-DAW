<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class UserApiController extends Controller
{
    public function user(Request $request)
    {
        $user = Auth::user();

        if (!$user) {
            return response()->json(['message' => 'No autenticado'], 401);
        }

        return response()->json([
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'rol' => $user->rol ?? 'user',
            'token_premium' => $user->token_premium ?? null,
        ]);
    }


    public function logout(Request $request)
    {
        try {

            $request->session()->invalidate();
            $request->session()->regenerateToken();

            Log::info('Logout exitoso para el usuario ID: ' . optional($request->user())->id);

            return response()->json(['message' => 'Sesión cerrada correctamente']);
        } catch (\Throwable $e) {
            Log::error('Error en logout: ' . $e->getMessage());
            return response()->json(['message' => 'Error interno del servidor'], 500);
        }
    }

    public function activarPremium(Request $request)
    {
        $request->validate([
            'token_premium' => 'required|string|unique:users,token_premium',
        ]);
    
        $user = Auth::user();
    
        if (!$user) {
            return response()->json(['message' => 'No autenticado'], 401);
        }
    
        try {
            $user->update(['token_premium' => $request->token_premium]);
    
            return response()->json(['message' => 'Plan premium activado.'], 200);
    
        } catch (\Throwable $e) {
            Log::error('Error al activar premium: ' . $e->getMessage());
            return response()->json([
                'message' => 'Error interno del servidor',
                'error' => $e->getMessage()  // Para ver el error en el JSON
            ], 500);
        }
    }
    

}
