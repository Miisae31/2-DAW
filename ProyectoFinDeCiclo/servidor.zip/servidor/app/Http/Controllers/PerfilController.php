<?php

namespace App\Http\Controllers;

use App\Models\Perfil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
class PerfilController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $perfil = Perfil::where('user_id', Auth::id())->firstOrFail(); // Buscar el perfil del usuario autenticado
        return view('perfiles.index', data: compact('perfil')); // Mostrar la vista con el perfil
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create() {}

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request) {}

    /**
     * Display the specified resource.
     */
    public function show(Perfil $perfil)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Perfil $perfil)
    {
        $perfil = Perfil::where('user_id', Auth::id())->firstOrFail(); // Buscar el perfil del usuario autenticado
        return view('perfiles.edit', compact('perfil')); // Mostrar la vista con el perfil
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {

        $perfil = Perfil::where('user_id', Auth::id())->firstOrFail();

    $request->validate([
        'twitter' => 'nullable|string|max:255',
        'descripcion' => 'nullable|string',
        'username' => 'required|string|max:255',
        'instagram' => 'nullable|string|max:255',
        'imagen' => 'nullable|image|mimes:jpg,png,jpeg|max:2048', // Solo imágenes, máx 2MB
    ]);

    // Guardar imagen de perfil si se sube una nueva
    if ($request->hasFile('imagen')) { // Si se sube una imagen
        // Borrar la imagen anterior si existe
        if ($perfil->imagen && Storage::exists($perfil->imagen)) {
            Storage::delete($perfil->imagen);
        }

        // Guardar la nueva imagen
        $rutaImagen = $request->file('imagen')->storeAs(
            'media/img/perfiles', // Carpeta dentro de storage/app/public
            $request->file('imagen')->getClientOriginalName(),
            'public' // Usa el disco 'public'
        );

        // Guardar solo la ruta relativa
        $perfil->imagen = str_replace('public/', 'storage/', $rutaImagen);
    }

    $perfil->twitter = $request->input('twitter');
    $perfil->descripcion = $request->input('descripcion');
    $perfil->username = $request->input('username');
    $perfil->instagram = $request->input('instagram');
    $perfil->user_id = auth()->id();
    $perfil->save();

    return redirect()->route('perfiles.index')->with('success', 'Perfil actualizado correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy()
{
    $perfil = Perfil::where('user_id', Auth::id())->firstOrFail();
    $usuario = $perfil->user; // Obtiene el usuario asociado

    $perfil->delete(); // Elimina el perfil
    $usuario->delete(); // Elimina la cuenta de usuario

    Auth::logout(); // Cierra la sesión

    return redirect()->route('inicio')->with('success', 'Tu cuenta ha sido eliminada exitosamente.');
}
}
