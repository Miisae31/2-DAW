<?php

namespace App\Http\Controllers;

use App\Models\Media;
use Illuminate\Http\Request;
use App\Models\Pelicula;
use App\Models\Serie;

class MediaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $media = Media::paginate(15);
        return view('medias.index', compact('media'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('medias.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'titulo' => 'required|string|max:255',
            'anio_creacion' => 'required|integer',
            'director' => 'required|string|max:255',
            'guion' => 'required|string|max:255',
            'pais' => 'required|string|max:255',
            'sinopsis' => 'required|string',
            'genero' => 'required|string|max:255',
            'trailer' => 'nullable|string',
            'puntuacion' => 'nullable|numeric|min:0|max:10',
            'tipo' => 'required|in:pelicula,serie',
            'duracion' => 'nullable|required_if:tipo,pelicula|integer',
            'n_episodios' => 'nullable|required_if:tipo,serie|integer',
            'temporadas' => 'nullable|required_if:tipo,serie|integer',
            'portada' => 'required|image|max:2048',
        ]);

        // Crear el registro en la tabla `medias`
        $media = new Media();
        $media->titulo = $request->input('titulo');
        $media->anio_creacion = $request->input('anio_creacion');
        $media->director = $request->input('director');
        $media->guion = $request->input('guion');
        $media->pais = $request->input('pais');
        $media->sinopsis = $request->input('sinopsis');
        $media->genero = $request->input('genero');
        $media->trailer = $request->input('trailer');
        $media->puntuacion = $request->input('puntuacion');

        if ($request->hasFile('portada')) {
            $rutaImagen = $request->file('portada')->storeAs(
                'media/img/portadas', // 📂 Carpeta dentro de `storage/app/public`
                $request->file('portada')->getClientOriginalName(),
                'public'
            );

            // Guardar la ruta relativa en la BD (para acceder desde `storage/`)
            $media->portada = str_replace('public/', 'storage/', $rutaImagen);
        }
        $media->save();

        // Si es película, se crea en la tabla `peliculas`
        if ($request->tipo === 'pelicula') {
            $pelicula = new Pelicula();
            $pelicula->media_id = $media->id;
            $pelicula->duracion = $request->input('duracion');
            $pelicula->save();
        }

        // Si es serie, se crea en la tabla `series`
        if ($request->tipo === 'serie') {
            $serie = new Serie();
            $serie->media_id = $media->id;
            $serie->n_episodios = $request->input('n_episodios');
            $serie->temporadas = $request->input('temporadas');
            $serie->save();
        }

        return redirect()->to('medias')->with('success', 'Media creada correctamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $media = Media::find($id);
        return view('medias.show', compact('media'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $media = Media::findOrFail($id);
        return view('medias.edit', compact('media'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $media = Media::findOrFail($id);

        $request->validate([
            'titulo' => 'required|string|max:255',
            'anio_creacion' => 'required|integer',
            'director' => 'required|string|max:255',
            'guion' => 'required|string|max:255',
            'pais' => 'required|string|max:255',
            'sinopsis' => 'required|string',
            'genero' => 'required|string|max:255',
            'trailer' => 'nullable|string',
            'puntuacion' => 'nullable|numeric|min:0|max:10',
            'tipo' => 'required|in:pelicula,serie',
            'duracion' => 'nullable|required_if:tipo,pelicula|integer',
            'n_episodios' => 'nullable|required_if:tipo,serie|integer',
            'temporadas' => 'nullable|required_if:tipo,serie|integer',
            'portada' => 'nullable|image|max:2048',
        ]);

        // Actualizar Media
        $media->titulo = $request->input('titulo');
        $media->anio_creacion = $request->input('anio_creacion');
        $media->director = $request->input('director');
        $media->guion = $request->input('guion');
        $media->pais = $request->input('pais');
        $media->sinopsis = $request->input('sinopsis');
        $media->genero = $request->input('genero');
        $media->trailer = $request->input('trailer');
        $media->puntuacion = $request->input('puntuacion');

        if ($request->hasFile('portada')) {
            $rutaImagen = $request->file('portada')->storeAs(
                'media/img/portadas', //  Carpeta dentro de `storage/app/public`
                $request->file('portada')->getClientOriginalName(), //  Nombre original del archivo
                'public' //  Usa el disco 'public'
            );

            //  Guardar la ruta relativa en la BD (para acceder desde `storage/`)
            $media->portada = str_replace('public/', 'storage/', $rutaImagen);
        }

        $media->save();

        // Actualizar Película o Serie según el tipo
        if ($request->tipo === 'pelicula' && $media->pelicula) { // Si es película
            $media->pelicula->duracion = $request->input('duracion');
            $media->pelicula->save();
        } elseif ($request->tipo === 'serie' && $media->serie) { // Si es serie
            $media->serie->n_episodios = $request->input('n_episodios');
            $media->serie->temporadas = $request->input('temporadas');
            $media->serie->save();
        }

        return redirect()->to('medias')->with('success', 'Media actualizada correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $media = Media::findOrFail($id);

        $media->delete();

        return redirect()->to(path: 'medias')->with('success', 'La película fué eliminada correctamente.');
    }

    public function apifetchMedias(Request $request)
    {
        $nombres = Media::where("titulo", "like", $request->texto . "%")->take(10)->get(); // Devuelve los primeros 10 resultados
        return response()->json($nombres); // Devuelve un JSON con los nombres
    }
}
