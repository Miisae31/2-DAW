<?php

namespace App\Http\Controllers;

use App\Models\Actor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ActorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $actores = Actor::paginate(15);
        return view('actores.index', compact('actores'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('actores.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'fecha_nacimiento' => 'required|date',
            'biografia' => 'nullable|string',
            'pais' => 'required|string|max:255',
            'imagenActor' => 'nullable|image',
            'fecha_fallecimiento' => 'nullable|date',
        ]);

        $actor = new Actor();
        $actor->nombre = $request->input('nombre');
        $actor->fecha_nacimiento = $request->input('fecha_nacimiento');
        $actor->biografia = $request->input('biografia');
        $actor->pais = $request->input('pais');
        if ($request->hasFile('imagenActor')) {
            $rutaImagen = $request->file('imagenActor')->storeAs(
                'media/img/actores', // Carpeta dentro de storage/app/public
                $request->file('imagenActor')->getClientOriginalName(), // Nombre original del archivo
                'public' // Usa el disco 'public'
            );

            $actor->imagenActor = str_replace('public/', 'storage/', $rutaImagen);
        }
        $actor->fecha_fallecimiento = $request->input('fecha_fallecimiento');
        $actor->save();

        $actor->medias()->attach($request->input('medias'));

        return redirect()->to(path: 'actores')->with('success', 'El actor fue creada correctamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show(Actor $actor) {}

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $actor = Actor::find($id);
        return view('actores.edit', compact('actor'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $actor = Actor::findOrFail($id);

        $request->validate([
            'nombre' => 'required|string|max:255',
            'fecha_nacimiento' => 'required|date',
            'biografia' => 'nullable|string',
            'pais' => 'required|string|max:255',
            'imagenActor' => 'nullable|image',
            'fecha_fallecimiento' => 'nullable|date',
        ]);

        $actor->nombre = $request->input('nombre');
        $actor->fecha_nacimiento = $request->input('fecha_nacimiento');
        $actor->biografia = $request->input('biografia');
        $actor->pais = $request->input('pais');

        // Si se sube una nueva imagen
        if ($request->hasFile('imagenActor')) {
            // Borrar la imagen anterior si existe
            if ($actor->imagenActor && Storage::exists($actor->imagenActor)) {
                Storage::delete($actor->imagenActor);
            }

            // Guardar la nueva imagen con su nombre original
            $rutaImagen = $request->file('imagenActor')->storeAs(
                'public/media/img/actores',
                $request->file('imagenActor')->getClientOriginalName()
            );

            $actor->imagenActor = str_replace('public/', 'storage/', $rutaImagen);
        }

        $actor->fecha_fallecimiento = $request->input('fecha_fallecimiento');
        $actor->save();

        $actor->medias()->sync($request->input('medias', []));

        return redirect()->route('actores.index')->with('success', 'El actor fue actualizado correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $actor = Actor::findOrFail($id);

        if ($actor->imagenActor) {
            $rutaReal = str_replace('storage/', 'public/', $actor->imagenActor);
            if (Storage::exists($rutaReal)) {

                Storage::delete($rutaReal);
            }
        }
        $actor->medias()->detach();
        $actor->delete();

        return redirect()->route('actores.index')->with('success', 'El actor fue eliminado correctamente.');
    }
}
