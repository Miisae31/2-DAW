<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Actor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\JsonResponse;

class ActorApiController extends Controller
{
    /**
     * 🔹 Muestra un listado de actores paginado
     */
    public function index(): JsonResponse
    {
        $actores = Actor::with('medias')->get(); // Trae todos los actores con sus medias relacionadas
        $actoresFormatted = $actores->map(function ($actor) {
            return [
                'id' => $actor->id,
                'nombre' => $actor->nombre,
                'fecha_nacimiento' => $actor->fecha_nacimiento,
                'biografia' => $actor->biografia,
                'pais' => $actor->pais,
                'imagenActor' => $actor->imagenActor ? config('app.url') . Storage::url($actor->imagenActor) : null,
                'fecha_fallecimiento' => $actor->fecha_fallecimiento,
            ];
        });

        return response()->json([
            'success' => true,
            'data' => $actoresFormatted
        ]);
    }


    /**
     *  Guarda un nuevo actor en la base de datos
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'fecha_nacimiento' => 'required|date',
            'biografia' => 'nullable|string',
            'pais' => 'required|string|max:255',
            'imagenActor' => 'nullable|image|max:2048',
            'fecha_fallecimiento' => 'nullable|date',
        ]);

        $actor = new Actor(); // Creamos una nueva instancia de Actor
        $actor->nombre = $request->nombre;
        $actor->fecha_nacimiento = $request->fecha_nacimiento;
        $actor->biografia = $request->biografia;
        $actor->pais = $request->pais;

        if ($request->hasFile('imagenActor')) { // Si se ha enviado una imagen
            $rutaImagen = $request->file('imagenActor')->store('media/img/actores', 'public');
            $actor->imagenActor = "storage/$rutaImagen";
        }

        $actor->fecha_fallecimiento = $request->fecha_fallecimiento;
        $actor->save();

        return response()->json([ // Retornamos una respuesta JSON
            'success' => true,
            'message' => 'Actor creado exitosamente',
            'data' => $actor
        ], 201);
    }

    /**
     * Muestra un actor en específico
     */
    public function show($id): JsonResponse
    {
        $actor = Actor::findOrFail($id);
        $actorFormatted = [
            'id' => $actor->id,
            'nombre' => $actor->nombre,
            'fecha_nacimiento' => $actor->fecha_nacimiento,
            'biografia' => $actor->biografia,
            'pais' => $actor->pais,
            'imagenActor' => $actor->imagenActor ? config('app.url') . Storage::url($actor->imagenActor) : null,
            'fecha_fallecimiento' => $actor->fecha_fallecimiento,
        ];

        return response()->json([
            'success' => true,
            'data' => $actorFormatted
        ]);
    }

    /**
     * Actualiza un actor en la base de datos
     */
    public function update(Request $request, $id): JsonResponse
    {
        $actor = Actor::findOrFail($id);

        $request->validate([
            'nombre' => 'required|string|max:255',
            'fecha_nacimiento' => 'required|date',
            'biografia' => 'nullable|string',
            'pais' => 'required|string|max:255',
            'imagenActor' => 'nullable|image|max:2048',
            'fecha_fallecimiento' => 'nullable|date',
        ]);

        $actor->nombre = $request->nombre;
        $actor->fecha_nacimiento = $request->fecha_nacimiento;
        $actor->biografia = $request->biografia;
        $actor->pais = $request->pais;

        if ($request->hasFile('imagenActor')) { // Si se ha enviado una imagen
            if ($actor->imagenActor) { // Si el actor ya tenía una imagen
                Storage::delete(str_replace('storage/', 'public/', $actor->imagenActor)); // Borramos la imagen anterior
            }
            $rutaImagen = $request->file('imagenActor')->store('media/img/actores', 'public');
            $actor->imagenActor = "storage/$rutaImagen";
        }

        $actor->fecha_fallecimiento = $request->fecha_fallecimiento;
        $actor->save();

        return response()->json([
            'success' => true,
            'message' => 'Actor actualizado exitosamente',
            'data' => $actor
        ]);
    }

    /**
     * 🔹 Elimina un actor de la base de datos
     */
    public function destroy($id): JsonResponse
    {
        $actor = Actor::findOrFail($id);

        if ($actor->imagenActor) {
            Storage::delete(str_replace('storage/', 'public/', $actor->imagenActor));
        }

        $actor->delete();

        return response()->json([
            'success' => true,
            'message' => 'Actor eliminado exitosamente'
        ]);
    }

    public function actoresPorMedia($mediaId): JsonResponse
{
    // Obtener los actores relacionados con el mediaId
    $actores = Actor::whereHas('medias', function ($query) use ($mediaId) {
        $query->where('id', $mediaId);
    })->get();

    // Formatear los datos de los actores, incluyendo la URL absoluta de la imagen
    $actoresFormatted = $actores->map(function ($actor) {
        return [
            'id' => $actor->id,
            'nombre' => $actor->nombre,
            'fecha_nacimiento' => $actor->fecha_nacimiento,
            'biografia' => $actor->biografia,
            'pais' => $actor->pais,
            'imagenActor' => $actor->imagenActor ? config('app.url') . Storage::url($actor->imagenActor) : null,
            'fecha_fallecimiento' => $actor->fecha_fallecimiento,
        ];
    });

    // Devolver la respuesta JSON con los datos formateados
    return response()->json([
        'success' => true,
        'data' => $actoresFormatted
    ]);
}
}
