<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class LoginController extends Controller
{
    public function loginAPI(Request $request) {

    // Validacion dos campos que debe recibir
    $request->validate([
        'email' => 'required|string|email',
        'password' => 'required|string',
    ]);

    $credentials = request(['email','password']); // Obtenemos las credenciales

    if(!Auth::attempt($credentials)) { // Si las credenciales no son correctas
        return response()->json(['message' => 'Unauthorized'], 401); // Retornamos un mensaje de error
    }

    $user = $request->user(); // Obtenemos el usuario
    $tokenResult = $user->createToken('API Access Token'); // Creamos un token
    $token = $tokenResult->plainTextToken; // Obtenemos el token

    return response()->json([ // Retornamos un mensaje de exito
        'accessToken' =>$token,
        'token_type' => 'Bearer',
    ], 200);
    }

    public function getAPI () { // Funcion para obtener datos
        return response()->json(['message' => 'GET request successful'], 200); // Retornamos un mensaje de exito
    }
}
