<?php

namespace App\Http\Controllers;

use App\Models\Publicacion;
use Illuminate\Http\Request;
use App\Models\Foro;
use Illuminate\Support\Facades\Auth;

class PublicacionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index($foroId)
    {
        $foro = Foro::findOrFail($foroId);
        $publicaciones = Publicacion::where('foro_id', $foroId)->paginate(20);

        return view('foros.show', compact('publicaciones', 'foro'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create($foroId)
    {
        $foro = Foro::findOrFail($foroId);
        return view('publicaciones.create', compact('foro'));
    }


    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
{
    $request->validate([
        'foro_id' => 'required|exists:foros,id',
        'etiqueta' => 'nullable|string|max:255',
        'titulo' => 'required|string|max:255',
        'body' => 'required|string',
        'imagen' => 'nullable|string',
    ]);

    $publicacion = new Publicacion();
    $publicacion->user_id = Auth::id();
    $publicacion->foro_id = $request->input('foro_id');
    $publicacion->etiqueta = $request->input('etiqueta');
    $publicacion->titulo = $request->input('titulo');
    $publicacion->body = $request->input('body');
    $publicacion->imagen = $request->input('imagen');
    $publicacion->save();

    return redirect()->route('foros.show', $publicacion->foro_id)
        ->with('success', 'Publicación creada correctamente.');
}

    /**
     * Display the specified resource.
     */
    public function show($id)
    {
        $publicacion = Publicacion::findOrFail($id);
        return view('publicaciones.show', compact('publicacion'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $publicacion = Publicacion::findOrFail($id);
        if (Auth::id() !== $publicacion->user_id) {
            return redirect()->route('publicaciones.index', $publicacion->foro_id)
                ->with('error', 'No tienes permiso para editar esta publicación.');
        }

        return view('publicaciones.edit', compact('publicacion'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Publicacion $publicacion)
    {
        if (Auth::id() !== $publicacion->user_id) {
            return redirect()->route('publicaciones.index', $publicacion->foro_id)
                ->with('error', 'No tienes permiso para modificar esta publicación.');
        }

        $request->validate([
            'etiqueta' => 'nullable|string|max:255',
            'titulo' => 'required|string|max:255',
            'body' => 'required|string',
            'imagen' => 'nullable|string|max:255',
        ]);

        $publicacion->etiqueta = $request->input('etiqueta');
        $publicacion->titulo = $request->input('titulo');
        $publicacion->body = $request->input('body');
        $publicacion->imagen = $request->input('imagen');
        $publicacion->save();

        return redirect()->route('foros.show', $publicacion->foro_id)
            ->with('success', 'Publicación actualizada correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $publicacion = Publicacion::findOrFail($id);

        $publicacion->delete();

        return redirect()->route('publicaciones.index', $publicacion->foro_id)
            ->with('success', 'Publicación eliminada correctamente.');
    }
}
