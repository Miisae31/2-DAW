<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Perfil;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Http\JsonResponse;

class PerfilApiController extends Controller
{
    /**
     * 🔹 Obtener el perfil del usuario autenticado.
     */
    public function index(): JsonResponse
{
    $perfil = Perfil::with('user')->where('user_id', Auth::id())->first();

    if (!$perfil) {
        return response()->json([
            'success' => false,
            'message' => 'Perfil no encontrado.'
        ], 404);
    }

    return response()->json([
        'success' => true,
        'data' => [
            'id' => $perfil->id,
            'username' => $perfil->username,
            'descripcion' => $perfil->descripcion,
            'twitter' => $perfil->twitter,
            'instagram' => $perfil->instagram,
            'imagen' => $perfil->imagen ? config('app.url') . Storage::url($perfil->imagen) : null,
            'nombre' => $perfil->user->name,
            'email' => $perfil->user->email,
        ]
    ]);
}


    /**
     * Actualizar el perfil del usuario autenticado.
     */
    public function update(Request $request): JsonResponse
    {
        $perfil = Perfil::where('user_id', Auth::id())->first();

        if (!$perfil) {
            return response()->json([
                'success' => false,
                'message' => 'Perfil no encontrado.'
            ], 404);
        }

        $request->validate([
            'twitter' => 'nullable|string|max:255',
            'descripcion' => 'nullable|string',
            'username' => 'required|string|max:255',
            'instagram' => 'nullable|string|max:255',
            'imagen' => 'nullable|image|mimes:jpg,png,jpeg|max:2048',
        ]);

        // Guardar imagen de perfil si se sube una nueva
        if ($request->hasFile('imagen')) {
            // Borrar la imagen anterior si existe
            if ($perfil->imagen && Storage::exists($perfil->imagen)) {
                Storage::delete($perfil->imagen);
            }

            // Guardar la nueva imagen
            $rutaImagen = $request->file('imagen')->store('media/img/perfiles', 'public');
            $perfil->imagen = "storage/$rutaImagen";
        }

        $perfil->update([
            'twitter' => $request->input('twitter'),
            'descripcion' => $request->input('descripcion'),
            'username' => $request->input('username'),
            'instagram' => $request->input('instagram'),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Perfil actualizado correctamente.',
            'data' => $perfil
        ]);
    }

    /**
     *  Eliminar la cuenta del usuario autenticado junto con su perfil.
     */
    public function destroy(): JsonResponse
    {
        $perfil = Perfil::where('user_id', Auth::id())->first();

        if (!$perfil) {
            return response()->json([
                'success' => false,
                'message' => 'Perfil no encontrado.'
            ], 404);
        }

        $usuario = $perfil->user;

        // Eliminar la imagen del perfil si existe
        if ($perfil->imagen && Storage::exists($perfil->imagen)) {
            Storage::delete($perfil->imagen);
        }

        $perfil->delete();
        $usuario->delete();


        return response()->json([
            'success' => true,
            'message' => 'Tu cuenta ha sido eliminada exitosamente.'
        ]);
    }
}
