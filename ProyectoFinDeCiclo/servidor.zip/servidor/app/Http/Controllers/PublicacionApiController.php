<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Publicacion;
use Illuminate\Http\Request;
use App\Models\Foro;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\JsonResponse;

class PublicacionApiController extends Controller
{
    /**
     *  Obtener publicaciones de un foro específico (Paginadas)
     */
    public function index($foroId): JsonResponse
    {
        $foro = Foro::find($foroId);

        if (!$foro) {
            return response()->json([
                'success' => false,
                'message' => 'Foro no encontrado.'
            ], 404);
        }

        $publicaciones = Publicacion::where('foro_id', $foroId)->paginate(20);

        return response()->json([
            'success' => true,
            'data' => $publicaciones
        ]);
    }

    /**
     *  Crear una nueva publicación en un foro
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'foro_id' => 'required|exists:foros,id',
            'etiqueta' => 'nullable|string|max:255',
            'titulo' => 'required|string|max:255',
            'body' => 'required|string',
            'imagen' => 'nullable|string',
        ]);

        $publicacion = new Publicacion();
        $publicacion->user_id = Auth::id();
        $publicacion->foro_id = $request->foro_id;
        $publicacion->etiqueta = $request->etiqueta;
        $publicacion->titulo = $request->titulo;
        $publicacion->body = $request->body;
        $publicacion->imagen = $request->imagen;
        $publicacion->save();

        return response()->json([
            'success' => true,
            'message' => 'Publicación creada correctamente.',
            'data' => $publicacion
        ], 201);
    }

    /**
     * Obtener una publicación en específico
     */
    public function show($id): JsonResponse
    {
        $publicacion = Publicacion::find($id);

        if (!$publicacion) {
            return response()->json([
                'success' => false,
                'message' => 'Publicación no encontrada.'
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $publicacion
        ]);
    }

    /**
     *  Actualizar una publicación (Solo el dueño puede hacerlo)
     */
    public function update(Request $request, $id): JsonResponse
    {
        $publicacion = Publicacion::find($id);

        if (!$publicacion) {
            return response()->json([
                'success' => false,
                'message' => 'Publicación no encontrada.'
            ], 404);
        }

        if (Auth::id() !== $publicacion->user_id) {
            return response()->json([
                'success' => false,
                'message' => 'No tienes permiso para modificar esta publicación.'
            ], 403);
        }

        $request->validate([
            'etiqueta' => 'nullable|string|max:255',
            'titulo' => 'required|string|max:255',
            'body' => 'required|string',
            'imagen' => 'nullable|string|max:255',
        ]);

        $publicacion->update($request->all());

        return response()->json([
            'success' => true,
            'message' => 'Publicación actualizada correctamente.',
            'data' => $publicacion
        ]);
    }

    /**
     *
     */
    public function destroy($id): JsonResponse
    {
        $publicacion = Publicacion::find($id);

        if (!$publicacion) {
            return response()->json([
                'success' => false,
                'message' => 'Publicación no encontrada.'
            ], 404);
        }

        if (Auth::id() !== $publicacion->user_id) {
            return response()->json([
                'success' => false,
                'message' => 'No tienes permiso para eliminar esta publicación.'
            ], 403);
        }

        $publicacion->delete();

        return response()->json([
            'success' => true,
            'message' => 'Publicación eliminada correctamente.'
        ]);
    }
}
