<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Publicacion extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'foro_id', 'etiqueta', 'body', 'titulo', 'imagen', 'fecha_creacion', 'fecha_modificacion'];

    const CREATED_AT = 'fecha_creacion';
    const UPDATED_AT = 'fecha_modificacion';

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function foro()
    {
        return $this->belongsTo(Foro::class);
    }
}
