<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Pelicula;
use App\Models\Serie;


class Media extends Model
{
    protected $table = 'medias';
    protected $fillable = ['titulo', 'anio_creacion', 'director', 'guion', 'pais', 'sinopsis', 'genero', 'trailer', 'puntuacion', 'portada'];


    public function pelicula()
    {
        return $this->hasOne(Pelicula::class);
    }

    public function serie()
    {
        return $this->hasOne(Serie::class);
    }

    public function actores() {
        return $this->belongsToMany(Actor::class, 'actor_media');
    }
}
