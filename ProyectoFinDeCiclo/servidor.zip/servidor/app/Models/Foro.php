<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Publicacion;
class Foro extends Model
{
    use HasFactory;

    protected $fillable = ['titulo', 'pelicula_asociada', 'fecha_creacion', 'fecha_modificacion'];

        // 🔹 Especificamos los nombres personalizados de los timestamps
        const CREATED_AT = 'fecha_creacion';
        const UPDATED_AT = 'fecha_modificacion';

    public function pelicula()
    {
        return $this->belongsTo(Media::class, 'pelicula_asociada');
    }

    public function publicaciones()
    {
        return $this->hasMany(Publicacion::class);
    }
}
