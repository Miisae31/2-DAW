<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Actor extends Model
{
    use HasFactory;

    protected $fillable = ['nombre', 'fecha_nacimiento', 'biografia', 'pais', 'imagenActor', 'fecha_fallecimiento'];

    public function medias()
    {
        return $this->belongsToMany(Media::class, 'actor_media');
    }
}

