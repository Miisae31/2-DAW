<title>MovieLoot</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="stylesheet" href="<?php echo e(asset('css/header.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/menu.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/buscador.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/contenidoInicial.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/thumbnails.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/inicio.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/paginacion.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/perfil.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/media-view.css')); ?>">
<script src="<?php echo e(asset(path: 'js/menuDesplegable.js')); ?>"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.2/css/bulma.min.css">

<header class="menu">
    <!-- Cabecera de la página -->
    <div class="div1">
        <!-- Div con el logo y el slogan -->
        <a href="http://localhost:8000/inicio" target="_self">
            <img src=<?php echo e(asset('media/img/logoSinFondo.png')); ?> class="logo" alt="" width="125"
                height="125" />
        </a>
        <p class="slogan">
            <?php echo e(__('idioma.slogan')); ?>

        </p>
    </div>
<?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/layouts/cabecera.blade.php ENDPATH**/ ?>