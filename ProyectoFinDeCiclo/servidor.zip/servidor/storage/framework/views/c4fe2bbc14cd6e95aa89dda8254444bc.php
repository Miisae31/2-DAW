<?php echo $__env->make('layouts.cabecera', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.buscador', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class=''>
    <?php if(request()->path() !== 'inicio'): ?>
        <?php echo $__env->make('components.back_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('cuerpo'); ?>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    // Se ejecuta cuando el contenido HTML de la página se ha cargado completamente.
    document.addEventListener('DOMContentLoaded', function() {

        // Obtener los elementos del DOM que se utilizarán en el script.
        var hamburguesaIcono = document.getElementById('hamburguesaIcono'); // Icono del menú hamburguesa.
        var menuDesplegable = document.getElementById(
        'menuDesplegable'); // El menú desplegable que se va a mostrar u ocultar.

        // Evento que se dispara cuando se hace clic en el icono del menú hamburguesa.
        hamburguesaIcono.addEventListener('click', function() {
            // Alterna la clase 'show' en el menú desplegable, lo que activa o desactiva su visibilidad.
            menuDesplegable.classList.toggle('show');

            // Alterna la clase 'active' en el menú, lo que puede usarse para añadir efectos visuales como el desplazamiento o la opacidad.
            menuDesplegable.classList.toggle("active");

            // Alterna la clase 'active' en el icono de la hamburguesa para agregar animación o cambios de estilo (por ejemplo, rotación).
            hamburguesaIcono.classList.toggle('active');
        });

        // Evento para detectar cuando el cursor sale del área del menú desplegable.
        menuDesplegable.addEventListener('mouseleave', function() {
            // Si el cursor sale del menú, se elimina la clase 'show' para ocultarlo.
            menuDesplegable.classList.remove('show');

            // Se elimina la clase 'active' del icono de la hamburguesa para devolverlo a su estado original.
            hamburguesaIcono.classList.remove('active');
        });
    });
    // Se ejecuta cuando el contenido HTML de la página se ha cargado completamente.
    document.addEventListener('DOMContentLoaded', function() {

        // Obtener los elementos del DOM que se utilizarán en el script.
        var hamburguesaIcono = document.getElementById('hamburguesaIcono'); // Icono del menú hamburguesa.
        var menuDesplegable = document.getElementById(
        'menuDesplegable'); // El menú desplegable que se va a mostrar u ocultar.

        // Evento que se dispara cuando se hace clic en el icono del menú hamburguesa.
        hamburguesaIcono.addEventListener('click', function() {
            // Alterna la clase 'show' en el menú desplegable, lo que activa o desactiva su visibilidad.
            menuDesplegable.classList.toggle('show');

            // Alterna la clase 'active' en el menú, lo que puede usarse para añadir efectos visuales como el desplazamiento o la opacidad.
            menuDesplegable.classList.toggle("active");

            // Alterna la clase 'active' en el icono de la hamburguesa para agregar animación o cambios de estilo (por ejemplo, rotación).
            hamburguesaIcono.classList.toggle('active');
        });

        // Evento para detectar cuando el cursor sale del área del menú desplegable.
        menuDesplegable.addEventListener('mouseleave', function() {
            // Si el cursor sale del menú, se elimina la clase 'show' para ocultarlo.
            menuDesplegable.classList.remove('show');

            // Se elimina la clase 'active' del icono de la hamburguesa para devolverlo a su estado original.
            hamburguesaIcono.classList.remove('active');
        });
    });
</script>
<?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/layouts/personalizada.blade.php ENDPATH**/ ?>