<?php $__env->startSection('cuerpo'); ?>
    <div class="container">
        <h1 class="title has-text-primary mt-3"><?php echo e(__('idioma.lista_medias')); ?></h1>

        <a href="<?php echo e(route('medias.create')); ?>" class="button is-primary mb-4"><?php echo e(__('idioma.crear_media')); ?></a>

        <?php if(session('success')): ?>
            <div class="notification is-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-container">
            <table class="table is-striped is-hoverable is-fullwidth">
                <thead>
                    <tr class="has-background-primary has-text-white">
                        <th><?php echo e(__('idioma.titulo')); ?></th>
                        <th><?php echo e(__('idioma.director')); ?></th>
                        <th><?php echo e(__('idioma.pais')); ?></th>
                        <th><?php echo e(__('idioma.genero')); ?></th>
                        <th class="has-text-right"><?php echo e(__('idioma.acciones')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medias): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($medias->titulo); ?></td>
                            <td><?php echo e($medias->director); ?></td>
                            <td><?php echo e($medias->pais); ?></td>
                            <td><?php echo e($medias->genero); ?></td>
                            <td class="has-text-right">
                                <a href="<?php echo e(route('medias.edit', $medias->id)); ?>"
                                    class="button is-warning is-small"><?php echo e(__('idioma.modificar')); ?></a>
                                <form action="<?php echo e(route('medias.destroy', $medias->id)); ?>" method="POST" class="is-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="button is-danger is-small"
                                        onclick="return confirm('<?php echo e(__('idioma.confirmar_eliminar')); ?>');"><?php echo e(__('idioma.eliminar')); ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="pagination is-centered mt-4 mb-4">
            <?php echo e($media->links('pagination::default')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.personalizada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/medias/index.blade.php ENDPATH**/ ?>