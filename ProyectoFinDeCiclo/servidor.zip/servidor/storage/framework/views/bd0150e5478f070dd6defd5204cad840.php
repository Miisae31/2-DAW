<?php $__env->startSection('cuerpo'); ?>
<div class="container mt-5">
    <h1 class="title has-text-primary">Películas Populares</h1>

    <?php if(isset($error)): ?>
        <div class="notification is-danger"><?php echo e($error); ?></div>
    <?php endif; ?>

    <div class="columns is-multiline">
        <?php $__currentLoopData = $peliculas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelicula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="column is-one-quarter">
                <div class="card mb-3">
                    <div class="card-image">
                        <figure class="image is-4by5">
                            <img src="<?php echo e($pelicula['primaryImage']); ?>"
                                 alt="<?php echo e($pelicula['primaryTitle']); ?>">
                        </figure>
                    </div>
                    <div class="card-content">
                        <p class="title is-5"><?php echo e($pelicula['primaryTitle']); ?></p>
                        <p class="subtitle is-6">Año: <?php echo e($pelicula['startYear']); ?></p>
                        <p><strong>Duración:</strong> <?php echo e($pelicula['runtimeMinutes']); ?> min</p>
                        <p><strong>Género:</strong> <?php echo e(implode(', ', $pelicula['genres'])); ?></p>
                        <p><strong>Puntuación:</strong> <?php echo e($pelicula['averageRating']); ?> (<?php echo e($pelicula['numVotes']); ?> votos)</p>
                        <a href="<?php echo e($pelicula['url']); ?>" target="_blank" class="button is-link mt-3">Ver en IMDb</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.personalizada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/peliculas/api.blade.php ENDPATH**/ ?>