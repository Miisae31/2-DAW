<div>
    <button id="backbutton" class="button is-info mb-4 mt-4" onclick="window.history.back();">
        ← <?php echo e(__('idioma.volver_atras')); ?>

    </button>
</div>
<?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/components/back_button.blade.php ENDPATH**/ ?>