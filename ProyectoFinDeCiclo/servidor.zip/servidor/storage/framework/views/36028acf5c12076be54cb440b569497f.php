<footer id="footer" class="footerWeb">
    <!-- Pie de página -->
    <div class="footer-content">
        <!-- Contenido del pie de página -->
        <p>&copy; 2024 Hugo Fernández Pinho. <?php echo e(__('idioma.derechos')); ?></p>
        <p><?php echo e(__('idioma.contacto')); ?>: hugofernandezpinho@gmail.com</p>
        <p>
            <?php echo e(__('idioma.siguenos')); ?>: <a href="#">Facebook</a> | <a href="#">Twitter</a> |
            <a href="#">Instagram</a>
        </p>
        <p><?php echo e(__('idioma.terminos')); ?></p>
    </div>
    <script defer src="<?php echo e(asset('js/menuDesplegable.js')); ?>"></script>

    <script defer>
        // Se ejecuta cuando el contenido HTML de la página se ha cargado completamente.
        document.addEventListener('DOMContentLoaded', function() {

            // Obtener los elementos del DOM que se utilizarán en el script.
            var hamburguesaIcono = document.getElementById('hamburguesaIcono'); // Icono del menú hamburguesa.
            var menuDesplegable = document.getElementById(
            'menuDesplegable'); // El menú desplegable que se va a mostrar u ocultar.

            // Evento que se dispara cuando se hace clic en el icono del menú hamburguesa.
            hamburguesaIcono.addEventListener('click', function() {
                // Alterna la clase 'show' en el menú desplegable, lo que activa o desactiva su visibilidad.
                menuDesplegable.classList.toggle('show');

                // Alterna la clase 'active' en el menú, lo que puede usarse para añadir efectos visuales como el desplazamiento o la opacidad.
                menuDesplegable.classList.toggle("active");

                // Alterna la clase 'active' en el icono de la hamburguesa para agregar animación o cambios de estilo (por ejemplo, rotación).
                hamburguesaIcono.classList.toggle('active');
            });

            // Evento para detectar cuando el cursor sale del área del menú desplegable.
            menuDesplegable.addEventListener('mouseleave', function() {
                // Si el cursor sale del menú, se elimina la clase 'show' para ocultarlo.
                menuDesplegable.classList.remove('show');

                // Se elimina la clase 'active' del icono de la hamburguesa para devolverlo a su estado original.
                hamburguesaIcono.classList.remove('active');
            });
        });
    </script>

</footer>
<?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/layouts/footer.blade.php ENDPATH**/ ?>