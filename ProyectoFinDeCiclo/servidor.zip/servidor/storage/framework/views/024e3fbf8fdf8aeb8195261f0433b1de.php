<?php $__env->startSection('cuerpo'); ?>
    <div class="container mt-6 mb-6">
        <div class="box">
            <!-- Perfil de usuario -->
            <div class="has-text-centered">
                <figure class="image is-128x128 is-inline-block">
                    <img class="perfil-imagen"
                        src="<?php echo e($perfil->imagen ? asset('storage/' . $perfil->imagen) : asset('media/img/default.jpg')); ?>"
                        alt="Avatar de usuario">
                </figure>
                <h2 class="title is-4 mt-3"><?php echo e(auth()->user()->name); ?></h2>
                <p class="subtitle is-6 mt-3">&#64;<?php echo e($perfil->username); ?></p>
                <a href="<?php echo e(route('perfiles.edit', $perfil->id)); ?>" class="button is-info is-small mb-3"><?php echo e(__('idioma.editar_perfil')); ?></a>
            </div>

            <!-- Información del usuario -->
            <div class="content has-text-centered">
                <h3 class="title is-5"><?php echo e(__('idioma.informacion')); ?></h3>
                <p><strong><?php echo e(__('idioma.correo')); ?>:</strong> <?php echo e(auth()->user()->email); ?></p>
                <p><strong><?php echo e(__('idioma.biografia')); ?>:</strong> <?php echo e($perfil->descripcion ?? 'Sin biografía'); ?></p>

                <?php if($perfil->twitter): ?>
                    <p><strong>Twitter:</strong> <?php echo e($perfil->twitter); ?></p>
                <?php endif; ?>
                <?php if($perfil->instagram): ?>
                    <p><strong>Instagram:</strong> <?php echo e($perfil->instagram); ?></p>
                <?php endif; ?>
            </div>

            <!-- Botón de eliminar perfil -->
            <div class="has-text-centered mt-4">
                <form action="<?php echo e(route('perfiles.destroy', $perfil->id)); ?>" method="POST" onsubmit="return confirmDelete()">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="button is-danger"><?php echo e(__('idioma.eliminar_perfil')); ?></button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete() {
            return confirm('<?php echo e(__('idioma.confirmar_eliminar_cuenta')); ?>');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.personalizada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/perfiles/index.blade.php ENDPATH**/ ?>