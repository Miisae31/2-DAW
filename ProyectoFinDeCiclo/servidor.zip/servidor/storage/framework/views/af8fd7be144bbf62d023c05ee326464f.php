<div class="div3">

    <!-- Div con los iconos de usuario y hamburguesa -->
    <div class="iconosMenu">


        <div class="divUsuario">
            <?php if(auth()->guard()->guest()): ?>
                <a href=<?php echo e(route('login')); ?>>
                    <i class="fa-solid fa-user" id="usuarioIcono"></i>
                </a>
            <?php else: ?>
                <!-- Si el usuario está autenticado, muestra el icono de cerrar sesión -->
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="logout-form">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="logout-button">
                        <i class="fa-solid fa-sign-out-alt" id="usuarioIcono"></i>
                    </button>
                </form>
            <?php endif; ?>
        </div>
        <div class="divHamburguesa">
            <i class="fa-solid fa-bars" id="hamburguesaIcono"></i>
        </div>
    </div>
    <nav id="menuDesplegable" class="menuDesplegableCSS">
        <!-- Menú desplegable -->
        <ul>
            <li><a href="http://localhost:8000/inicio"><?php echo e(__('idioma.inicio')); ?></a></li>
            <li><a href="http://localhost:8000/foros"><?php echo e(__('idioma.foros')); ?></a></li>
            <li>
                <a href="<?php echo e(route('idioma', 'es')); ?>"><?php echo e(__('idioma.spanish')); ?></a>
                <a href="<?php echo e(route('idioma', 'en')); ?>"><?php echo e(__('idioma.english')); ?></a>
            </li>
        </ul>
    </nav>
</div>

</header>
<?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/layouts/menu.blade.php ENDPATH**/ ?>