<?php if($paginator->hasPages()): ?>
    <nav class="pagination is-centered mt-4" role="navigation" aria-label="pagination">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="pagination-previous has-background-lila has-text-white" disabled>«</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pagination-previous has-background-lila has-text-white">«</a>
        <?php endif; ?>

        
        <ul class="pagination-list">
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($element)): ?>
                    <li><span class="pagination-ellipsis has-text-white">&hellip;</span></li>
                <?php endif; ?>

                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li>
                                <a class="pagination-link has-background-morado has-text-white is-size-5 has-text-weight-bold"
                                   style="border-radius: 8px; padding: 10px 15px; box-shadow: 0px 0px 10px rgba(0,0,0,0.3);">
                                    <?php echo e($page); ?>

                                </a>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="<?php echo e($url); ?>" class="pagination-link has-background-lila has-text-white"
                                   style="border-radius: 5px; padding: 8px 12px;">
                                    <?php echo e($page); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pagination-next has-background-lila has-text-white">»</a>
        <?php else: ?>
            <span class="pagination-next has-background-lila has-text-white" disabled>»</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH /home/administrador/Documentos/PRUEBA DE COMPILADO/Laravel/MovieLoot Backend Laravel/resources/views/vendor/pagination/default.blade.php ENDPATH**/ ?>