@extends('layouts.personalizada')

@section('cuerpo')
<div class="container">
    <h1 class="title has-text-primary mt-3">{{ __('idioma.foros') }}</h1>

    <!-- Botón para crear foro -->
    <div class="is-flex is-justify-content-space-between is-align-items-center mb-4">
        <p class="subtitle">{{ __('idioma.explora_foros') }}</p>
        <a href="{{ route('foros.create') }}" class="button is-primary">{{ __('idioma.crear_foro') }}</a>
    </div>

    <div class="columns is-multiline">
        @foreach ($foros as $foro)
        <div class="column is-half">
            <div class="box">
                <article class="media">
                    <div class="media-content">
                        <div class="content">
                            <h2 class="title is-4"><a href="{{ route('foros.show', $foro->id) }}" class="has-text-primary">{{ $foro->titulo }}</a></h2>

                            @if ($foro->pelicula)
                                <p><strong>{{ __('idioma.pelicula_asociada') }}:</strong> {{ $foro->pelicula->titulo }}</p>
                            @endif

                            <p class="has-text-grey">{{ __('idioma.creado_el') }} {{ $foro->fecha_creacion }}</p>
                        </div>
                    </div>
                </article>
            </div>
        </div>
        @endforeach
    </div>

    <div class="pagination is-centered mt-4 mb-4">
        {{ $foros->links('pagination::default') }}
    </div>
</div>
@endsection
