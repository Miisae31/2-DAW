@extends('layouts.personalizada')

@section('cuerpo')
<div class="container">
    <h1 class="title has-text-primary mt-4">{{ __('idioma.modificar_foro') }}</h1>

    <div class="box mb-4">
        <form action="{{ route('foros.update', $foro->id) }}" method="POST">
            @csrf
            @method('PUT')

            <!-- Título del foro -->
            <div class="field">
                <label class="label">{{ __('idioma.titulo') }}</label>
                <div class="control">
                    <input class="input @error('titulo') is-danger @enderror" type="text" name="titulo" value="{{ old('titulo', $foro->titulo) }}">
                </div>
                @error('titulo')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Película Asociada -->
            <div class="field">
                <label class="label">{{ __('idioma.pelicula_asociada') }}</label>
                <div class="control">
                    <div class="select is-fullwidth">
                        <select name="pelicula_asociada">
                            <option value="">{{ __('idioma.sin_pelicula_asociada') }}</option>
                            @foreach($medias as $media)
                                <option value="{{ $media->id }}" {{ old('pelicula_asociada', $foro->pelicula_asociada) == $media->id ? 'selected' : '' }}>
                                    {{ $media->titulo }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                @error('pelicula_asociada')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Botones -->
            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-primary">{{ __('idioma.boton_actualizar_foro') }}</button>
                </div>
                <div class="control">
                    <a href="{{ route('foros.index') }}" class="button is-light">{{ __('idioma.boton_cancelar') }}</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
