@extends('layouts.personalizada')

@section('cuerpo')
    <div class="container">
        <h1 class="title has-text-primary mt-4">{{ $foro->titulo }}</h1>

        @if ($foro->pelicula)
            <p class="subtitle mt-2">{{ __('idioma.foro_sobre') }}: <strong>{{ $foro->pelicula->titulo }}</strong></p>
        @endif

        <!-- Botones para administrar el foro (solo si el usuario es administrador) -->
        @auth
        <div class="buttons-container">

            @if (auth()->user()->rol === 'admin')
                    <a href="{{ route('foros.edit', $foro->id) }}" class="button is-warning">{{ __('idioma.editar_foro') }}</a>
                    <form action="{{ route('foros.destroy', $foro->id) }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="button is-danger"
                            onclick="return confirm('{{ __('idioma.confirmar_borrar_foro') }}');">
                            {{ __('idioma.borrar_foro') }}
                        </button>
                    </form>
            @endif
        </div>

        @endauth
        <!-- Botón para crear publicación (solo si está autenticado) -->
        @auth
            <a href="{{ route('publicaciones.create', $foro->id) }}"
                class="button is-primary mb-4 mt-4">{{ __('idioma.crear_post') }}</a>
        @endauth

        <!-- Lista de publicaciones -->
        <div class="box">
            @if ($foro->publicaciones->count() > 0)
                @foreach ($foro->publicaciones as $publicacion)
                    <article class="media box mb-3">
                        <div class="media-content">
                            <div class="content">
                                <p>
                                    <strong>{{ $publicacion->titulo }}</strong>
                                    <br>
                                    {{ Str::limit($publicacion->contenido, 150) }}
                                    <br>
                                    <small>Por {{ $publicacion->user->name }} el
                                        {{ $publicacion->fecha_creacion->format('d/m/Y') }}</small>
                                </p>
                            </div>
                            <nav class="level">
                                <div class="level-left">
                                    <a href="{{ route('publicaciones.show', $publicacion->id) }}"
                                        class="button is-primary is-small">{{ __('idioma.ver_mas') }}</a>
                                    @auth
                                        @if (auth()->user()->id == $publicacion->user_id)
                                            <a href="{{ route('publicaciones.edit', $publicacion->id) }}"
                                                class="button is-warning is-small ml-2">{{ __('idioma.editar') }}</a>
                                            <form action="{{ route('publicaciones.destroy', $publicacion->id) }}"
                                                method="POST" class="ml-2">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="button is-danger is-small"
                                                    onclick="return confirm('{{ __('idioma.eliminar_publicacion') }}');">{{ __('idioma.eliminar') }}</button>
                                            </form>
                                        @endif
                                    @endauth
                                </div>
                            </nav>
                        </div>
                    </article>
                @endforeach
            @else
                <p class="has-text-grey">No hay publicaciones en este foro aún.</p>
            @endif
        </div>

        <!-- Paginación -->
        <div class="pagination is-centered mt-4">
            {{ $publicaciones->links('pagination::default') }}
        </div>

    </div>
@endsection
