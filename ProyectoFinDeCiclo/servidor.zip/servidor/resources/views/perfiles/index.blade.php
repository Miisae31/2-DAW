@extends('layouts.personalizada')

@section('cuerpo')
    <div class="container mt-6 mb-6">
        <div class="box">
            <!-- Perfil de usuario -->
            <div class="has-text-centered">
                <figure class="image is-128x128 is-inline-block">
                    <img class="perfil-imagen"
                        src="{{ $perfil->imagen ? asset('storage/' . $perfil->imagen) : asset('media/img/default.jpg') }}"
                        alt="Avatar de usuario">
                </figure>
                <h2 class="title is-4 mt-3">{{ auth()->user()->name }}</h2>
                <p class="subtitle is-6 mt-3">&#64;{{ $perfil->username }}</p>
                <a href="{{ route('perfiles.edit', $perfil->id) }}" class="button is-info is-small mb-3">{{ __('idioma.editar_perfil') }}</a>
            </div>

            <!-- Información del usuario -->
            <div class="content has-text-centered">
                <h3 class="title is-5">{{ __('idioma.informacion') }}</h3>
                <p><strong>{{ __('idioma.correo') }}:</strong> {{ auth()->user()->email }}</p>
                <p><strong>{{ __('idioma.biografia') }}:</strong> {{ $perfil->descripcion ?? 'Sin biografía' }}</p>

                @if ($perfil->twitter)
                    <p><strong>Twitter:</strong> {{ $perfil->twitter }}</p>
                @endif
                @if ($perfil->instagram)
                    <p><strong>Instagram:</strong> {{ $perfil->instagram }}</p>
                @endif
            </div>

            <!-- Botón de eliminar perfil -->
            <div class="has-text-centered mt-4">
                <form action="{{ route('perfiles.destroy', $perfil->id) }}" method="POST" onsubmit="return confirmDelete()">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="button is-danger">{{ __('idioma.eliminar_perfil') }}</button>
                </form>
            </div>
        </div>
    </div>

    <script>
        function confirmDelete() {
            return confirm('{{ __('idioma.confirmar_eliminar_cuenta') }}');
        }
    </script>
@endsection
