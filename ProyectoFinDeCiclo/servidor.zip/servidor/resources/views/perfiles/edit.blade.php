@extends('layouts.personalizada')

@section('cuerpo')
<div class="container mt-6 mb-6">
    <h1 class="title has-text-primary mt-4">{{ __('idioma.editar_perfil') }}</h1>

    <div class="box">
        <form action="{{ route('perfiles.update', $perfil->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <!-- Imagen de perfil actual -->
            <div class="field has-text-centered">
                <figure class="image is-128x128 is-inline-block">
                    <img class="is-rounded"
                         src="{{ $perfil->imagen ? url('storage/' . $perfil->imagen) : url('storage/media/img/perfiles/default.jpg') }}"
                         alt="Avatar de usuario">
                </figure>
            </div>
            
            

            <!-- Subir nueva imagen -->
            <div class="field">
                <label class="label">{{ __('idioma.nueva_imagen_perfil') }}</label>
                <div class="control">
                    <input class="input @error('imagen') is-danger @enderror" type="file" name="imagen">
                </div>
                @error('imagen')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Nombre de usuario -->
            <div class="field">
                <label class="label">{{ __('idioma.nombre_usuario') }}</label>
                <div class="control">
                    <input class="input @error('username') is-danger @enderror" type="text" name="username" value="{{ old('username', $perfil->username) }}">
                </div>
                @error('username')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Descripción -->
            <div class="field">
                <label class="label">{{ __('idioma.descripcion') }}</label>
                <div class="control">
                    <textarea class="textarea @error('descripcion') is-danger @enderror" name="descripcion">{{ old('descripcion', $perfil->descripcion) }}</textarea>
                </div>
                @error('descripcion')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Twitter -->
            <div class="field">
                <label class="label">Twitter</label>
                <div class="control">
                    <input class="input @error('twitter') is-danger @enderror" type="text" name="twitter" value="{{ old('twitter', $perfil->twitter) }}">
                </div>
                @error('twitter')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Instagram -->
            <div class="field">
                <label class="label">Instagram</label>
                <div class="control">
                    <input class="input @error('instagram') is-danger @enderror" type="text" name="instagram" value="{{ old('instagram', $perfil->instagram) }}">
                </div>
                @error('instagram')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Botones -->
            <div class="field is-grouped mt-4">
                <div class="control">
                    <button class="button is-primary">{{ __('idioma.guardar_cambios') }}</button>
                </div>
                <div class="control">
                    <a href="{{ route('perfiles.index') }}" class="button is-light">{{ __('idioma.cancelar') }}</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
