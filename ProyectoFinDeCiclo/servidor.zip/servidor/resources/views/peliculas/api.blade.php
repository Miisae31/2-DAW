@extends('layouts.personalizada')

@section('cuerpo')
<div class="container mt-5">
    <h1 class="title has-text-primary">Películas Populares</h1>

    @if(isset($error))
        <div class="notification is-danger">{{ $error }}</div>
    @endif

    <div class="columns is-multiline">
        @foreach($peliculas as $pelicula)
            <div class="column is-one-quarter">
                <div class="card mb-3">
                    <div class="card-image">
                        <figure class="image is-4by5">
                            <img src="{{ $pelicula['primaryImage'] }}"
                                 alt="{{ $pelicula['primaryTitle'] }}">
                        </figure>
                    </div>
                    <div class="card-content">
                        <p class="title is-5">{{ $pelicula['primaryTitle'] }}</p>
                        <p class="subtitle is-6">Año: {{ $pelicula['startYear'] }}</p>
                        <p><strong>Duración:</strong> {{ $pelicula['runtimeMinutes'] }} min</p>
                        <p><strong>Género:</strong> {{ implode(', ', $pelicula['genres']) }}</p>
                        <p><strong>Puntuación:</strong> {{ $pelicula['averageRating'] }} ({{ $pelicula['numVotes'] }} votos)</p>
                        <a href="{{ $pelicula['url'] }}" target="_blank" class="button is-link mt-3">Ver en IMDb</a>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
