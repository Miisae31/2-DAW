<div>
    <button id="backbutton" class="button is-info mb-4 mt-4" onclick="window.history.back();">
        ← {{ __('idioma.volver_atras') }}
    </button>
</div>
