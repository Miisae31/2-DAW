@extends('layouts.personalizada')

@section('cuerpo')
    <div class="container">
        <h1 class="title has-text-primary mt-4">{{ $publicacion->titulo }}</h1>

        <div class="box">
            <p class="subtitle">
                <strong>{{ __('idioma.publicado_por') }}:</strong> {{ $publicacion->user->name }}
                <span class="has-text-grey">el {{ $publicacion->fecha_creacion->format('d/m/Y') }}</span>
            </p>

            <!-- Etiqueta (si tiene) -->
            @if ($publicacion->etiqueta)
                <span class="tag is-info mb-2">{{ $publicacion->etiqueta }}</span>
            @endif

            <!-- Imagen (si tiene) -->
            @if ($publicacion->imagen)
                <figure class="image mt-3">
                    <img src="{{ $publicacion->imagen }}" alt="Imagen de la publicación"
                        style="max-width: 500px; height: auto; display: block; margin: 0 auto; border-radius: 10px;">
                </figure>
            @endif

            <!-- Contenido de la publicación -->
            <div class="content mt-4">
                <p>{{ $publicacion->body }}</p>
            </div>

            <!-- Botones de acción -->
            <div class="buttons mt-4">
                <a href="{{ route('foros.show', $publicacion->foro_id) }}"
                    class="button is-light">{{ __('idioma.volver_al_foro') }}</a>

                @auth
                    @if (auth()->user()->id === $publicacion->user_id || auth()->user()->rol === 'admin')
                        <a href="{{ route('publicaciones.edit', $publicacion->id) }}"
                            class="button is-warning">{{ __('idioma.editar') }}</a>
                        <form action="{{ route('publicaciones.destroy', $publicacion->id) }}" method="POST" class="is-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="button is-danger"
                                onclick="return confirm('{{ __('idioma.eliminar_publicacion_confirm') }}');">Eliminar</button>
                        </form>
                    @endif
                @endauth
            </div>
        </div>
    </div>
@endsection
