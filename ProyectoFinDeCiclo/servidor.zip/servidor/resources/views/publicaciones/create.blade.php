@extends('layouts.personalizada')

@section('cuerpo')
<div class="container">
    <h1 class="title has-text-primary mt-4">{{ __('idioma.crear_publicacion_en', ['foro' => $foro->titulo]) }}</h1>

    <div class="box mb-6">
        <form action="{{ route('publicaciones.store') }}" method="POST">
            @csrf

            <!-- ID del Foro -->
            <input type="hidden" name="foro_id" value="{{ $foro->id }}">

            <!-- Título de la Publicación -->
            <div class="field">
                <label class="label">{{ __('idioma.titulo') }}</label>
                <div class="control">
                    <input class="input @error('titulo') is-danger @enderror" type="text" name="titulo" value="{{ old('titulo') }}">
                </div>
                @error('titulo')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Etiqueta (Opcional) -->
            <div class="field">
                <label class="label">{{ __('idioma.etiqueta_opcional') }}</label>
                <div class="control">
                    <input class="input @error('etiqueta') is-danger @enderror" type="text" name="etiqueta" value="{{ old('etiqueta') }}">
                </div>
                @error('etiqueta')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Contenido de la Publicación -->
            <div class="field">
                <label class="label">{{ __('idioma.contenido') }}</label>
                <div class="control">
                    <textarea class="textarea @error('body') is-danger @enderror" name="body">{{ old('body') }}</textarea>
                </div>
                @error('body')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Imagen Opcional -->
            <div class="field">
                <label class="label">{{ __('idioma.imagen_opcional') }}</label>
                <div class="control">
                    <input class="input @error('imagen') is-danger @enderror" type="text" name="imagen" value="{{ old('imagen') }}" placeholder="https://example.com/imagen.jpg">
                </div>
                @error('imagen')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Botones -->
            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-primary">{{ __('idioma.publicar') }}</button>
                </div>
                <div class="control">
                    <a href="{{ route('foros.show', $foro->id) }}" class="button is-light">{{ __('idioma.cancelar') }}</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
