@extends('layouts.personalizada')

@section('cuerpo')
<div class="container">
    <h1 class="title has-text-primary mt-4">{{ __('idioma.editar_publicacion') }}</h1>

    <div class="box">
        <form action="{{ route('publicaciones.update', $publicacion->id) }}" method="POST">
            @csrf
            @method('PUT')

            <!-- Título -->
            <div class="field">
                <label class="label">{{ __('idioma.titulo') }}</label>
                <div class="control">
                    <input class="input @error('titulo') is-danger @enderror" type="text" name="titulo"
                        value="{{ old('titulo', $publicacion->titulo) }}">
                </div>
                @error('titulo')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Etiqueta (Opcional) -->
            <div class="field">
                <label class="label">{{ __('idioma.etiqueta_opcional') }}</label>
                <div class="control">
                    <input class="input @error('etiqueta') is-danger @enderror" type="text" name="etiqueta"
                        value="{{ old('etiqueta', $publicacion->etiqueta) }}">
                </div>
                @error('etiqueta')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Contenido -->
            <div class="field">
                <label class="label">{{ __('idioma.contenido') }}</label>
                <div class="control">
                    <textarea class="textarea @error('body') is-danger @enderror" name="body">{{ old('body', $publicacion->body) }}</textarea>
                </div>
                @error('body')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Imagen (Opcional) -->
            <div class="field">
                <label class="label">{{ __('idioma.url_imagen_opcional') }}</label>
                <div class="control">
                    <input class="input @error('imagen') is-danger @enderror" type="text" name="imagen"
                        value="{{ old('imagen', $publicacion->imagen) }}" placeholder="https://example.com/imagen.jpg">
                </div>
                @error('imagen')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Botones -->
            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-primary">{{ __('idioma.actualizar_publicacion') }}</button>
                </div>
                <div class="control">
                    <a href="{{ route('publicaciones.index', $publicacion->foro_id) }}" class="button is-light">{{ __('idioma.cancelar') }}</a>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection
