<div class="div2 buscadorArea">
    <!-- Icono de lupa -->
    <label for="buscador">
        <i class="fa-solid fa-magnifying-glass"></i>
    </label>

    <!-- Input de búsqueda -->
    <input
        id="buscador"
        type="search"
        placeholder="{{ __('idioma.buscar_peliculas') }}"
        onkeyup="buscarMedias()"
    >

    <!-- Lista de resultados -->
    <ul id="suxerencias"></ul>
</div>

<script>
// Función para buscar películas
    function buscarMedias() {
    let texto = document.getElementById('buscador').value; // Obtenemos el texto del input

    if (texto.length > 0) {
        fetch(`/mediasapifetch?texto=${texto}`) // Hacemos una petición GET a la API
            .then(response => response.json()) // Convertimos la respuesta a JSON
            .then(data => {
                let resultadoHTML = ""; // Creamos una variable para almacenar el HTML de los resultados
                if (data.length > 0) { // Si hay resultados
                    data.forEach(media => { // Recorremos los resultados
                        resultadoHTML += `
                            <li>
                                <a href="/medias/${media.id}">${media.titulo}</a>
                            </li>
                        `;
                    }); // Creamos un elemento <li> por cada resultado
                } else {
                    resultadoHTML = `<li>No se encontraron resultados</li>`;
                }

                let suxerencias = document.getElementById('suxerencias'); // Obtenemos el elemento <ul> de las sugerencias
                suxerencias.innerHTML = resultadoHTML; // Insertamos el HTML de los resultados en el elemento <ul>
                suxerencias.style.display = 'block'; // Mostramos el elemento <ul> con estilo de bloque
            })
            .catch(error => console.error('Error:', error));
    } else {
        document.getElementById('suxerencias').innerHTML = "";
        document.getElementById('suxerencias').style.display = 'none';
    }
}

</script>


