<div class="div3">

    <!-- Div con los iconos de usuario y hamburguesa -->
    <div class="iconosMenu">


        <div class="divUsuario">
            @guest
                <a href={{ route('login') }}>
                    <i class="fa-solid fa-user" id="usuarioIcono"></i>
                </a>
            @else
                <!-- Si el usuario está autenticado, muestra el icono de cerrar sesión -->
                <form method="POST" action="{{ route('logout') }}" class="logout-form">
                    @csrf
                    <button type="submit" class="logout-button">
                        <i class="fa-solid fa-sign-out-alt" id="usuarioIcono"></i>
                    </button>
                </form>
            @endguest
        </div>
        <div class="divHamburguesa">
            <i class="fa-solid fa-bars" id="hamburguesaIcono"></i>
        </div>
    </div>
    <nav id="menuDesplegable" class="menuDesplegableCSS">
        <!-- Menú desplegable -->
        <ul>
            <li><a href="http://localhost:8000/inicio">{{ __('idioma.inicio') }}</a></li>
            <li><a href="http://localhost:8000/foros">{{ __('idioma.foros') }}</a></li>
            <li>
                <a href="{{ route('idioma', 'es') }}">{{ __('idioma.spanish') }}</a>
                <a href="{{ route('idioma', 'en') }}">{{ __('idioma.english') }}</a>
            </li>
        </ul>
    </nav>
</div>

</header>
