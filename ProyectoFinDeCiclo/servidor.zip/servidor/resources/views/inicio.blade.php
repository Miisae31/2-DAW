@extends('layouts.personalizada')
@section('cuerpo')
<div class="contenidoInicio">
    <!-- Contenido de la página -->
    <div class="inicioVideo">
        <div class="divVideo1">
            <label for="video" id="labelVideo" class="title">El Pingüino (2022)</label>
            <div class="divVideoBordes">
                <iframe id="video" width="560" height="315" src="https://www.youtube.com/embed/RNEt4JPlrFE?si=Wbeetf0yTVVXFcoi" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
            </div>
            <div class="textoDebajoVideo">
                <h4>El Pingüino (2022)</h4>
                <p>
                    El Pingüino es una serie 'spin-off' de The Batman que profundiza
                    en la vida del icónico villano del Caballero Oscuro. La trama
                    sigue a Oswald Cobblepot, conocido como El Pingüino, mientras
                    lucha por consolidar su dominio en el oscuro y peligroso mundo del
                    crimen de Gotham City. Tras los eventos de la película The Batman,
                    Cobblepot busca expandir su imperio criminal y enfrentar a rivales
                    que amenazan su poder.
                </p>
            </div>
        </div>

        <div class="divVideo2">
            <div class="portadaRelacionados1" id="Pelicula1" data-id="1">
                <!-- Div con la portada de la película relacionada -->
                <label for="imagen1" id="labelPelicula1" class="imageSugeridos">Relacionados:</label>
                <a href="html/pelicula.html">
                    <img src="media/img/peakyBlinders.jpg" id="imagen1" titulo="Peaky Blinders"
                        class="imageSugeridos pelicula" alt="" />
                </a>
            </div>

            <div class="portadaRelacionados2" id="Pelicula2">
                <!-- Div con la portada de la película relacionada -->
                <a href="html/pelicula.html">
                    <img src="media/img/seven.jpg" class="imageSugeridos pelicula" alt="" />
                </a>
            </div>

            <div class="portadaRelacionados3" id="Pelicula3">
                <!-- Div con la portada de la película relacionada -->
                <a href="html/pelicula.html">
                    <img src="media/img/dexter.jpg" class="imageSugeridos pelicula" alt="" titulo="Dexter" />
                </a>
            </div>

            <div class="portadaPelicula1" id="PortadaPelicula1">
                <!-- Descripción de la película relacionada -->
                <div class="textoSugeridos">
                    <p>Peaky Blinders(2013)</p>
                    <p>Steven Knight (Creador) ...</p>
                    <p>Cillian Murphy, Sam Neill...</p>
                </div>
            </div>

            <div class="portadaPelicula2" id="PortadaPelicula2">
                <!-- Descripción de la película relacionada -->
                <div class="textoSugeridos">
                    <p>Seven(1999)</p>
                    <p>David Fincher</p>
                    <p>Brad Pitt, Morgan Freeman ...</p>
                </div>
            </div>

            <div class="portadaPelicula3" id="PortadaPelicula3">
                <!-- Descripción de la película relacionada -->
                <div class="textoSugeridos">
                    <p>Dexter(2006)</p>
                    <p>James Manos Jr. (Creador)</p>
                    <p>Michael C. Hall, Jennifer Carpenter...</p>
                </div>
            </div>
        </div>
    </div>

    <div class="mejoresValoradasTitulo">
        <h2 class="title">{{ __('idioma.top_mejores_valoradas') }}</h2>
        <div class="vl" id="vlMejoresValoradas"></div>
        <!-- Línea divisoria -->
    </div>

    <div class="mejoresValoradasImagenes">
        <!-- Imágenes de las películas mejor valoradas -->

        <div class="div1MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/elPadrino.jpg" class="pelicula" titulo="El padrino" alt="" />
            </a>
        </div>

        <div class="div2MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/elPadrino2.jpg" class="pelicula" titulo="El padrino II" alt="" />
            </a>
        </div>

        <div class="div3MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/theWire.jpg" class="pelicula" titulo="The Wire" alt="" />
            </a>
        </div>

        <div class="div4MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/breakingBad.jpg" class="pelicula" titulo="Breaking Bad" alt="" />
            </a>
        </div>

        <div class="div5MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/laListaDeSchindler.jpg" class="pelicula" titulo="La lista de Schindler"
                    alt="" />
            </a>
        </div>

        <div class="div1MejoresValoradas">
            <!-- Div con la información de la película mejor valorada -->
            <div class="ratingsMejoresValoradas">
                <div class="div1Ratings">
                    <!-- Div con la nota de la película -->
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9.2</p>
                </div>
                <div class="div2Ratings">
                    <!-- Div con el título de la película -->
                    <h3>El Padrino (1972)</h3>
                </div>
                <div class="div3Ratings">
                    <!-- Div con el icono de información -->
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div2MejoresValoradas">
            <div class="ratingsMejoresValoradas">
                <div class="div1Ratings">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9</p>
                </div>

                <div class="div2Ratings">
                    <h3>El Padrino 2 (1974)</h3>
                </div>

                <div class="div3Ratings">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div3MejoresValoradas">
            <div class="ratingsMejoresValoradas">
                <div class="div1Ratings">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9.3</p>
                </div>

                <div class="div2Ratings">
                    <h3>The wire (2002)</h3>
                </div>

                <div class="div3Ratings">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div4MejoresValoradas">
            <div class="ratingsMejoresValoradas">
                <div class="div1Ratings">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9.5</p>
                </div>
                <div class="div2Ratings">
                    <h3>Breaking Bad (2008)</h3>
                </div>
                <div class="div3Ratings">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div5MejoresValoradas">
            <div class="ratingsMejoresValoradas">
                <div class="div1Ratings">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">8.9</p>
                </div>
                <div class="div2Ratings">
                    <h3>La lista de Schindler (1993)</h3>
                </div>
                <div class="div3Ratings">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>
    </div>

    <div class="mejoresValoradasTitulo">
        <!-- Título de las películas mejor valoradas por género -->
        <h2 class="generoTitulo title">{{ __('idioma.top_mejores_valoradas_genero') }}</h2>
        <div class="vlGenero"></div>
    </div>

    <div class="mejoresValoradasImagenes">
        <!-- Imágenes de las películas mejor valoradas por género -->

        <div class="div1MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/fullMetalJacket.jpg" class="pelicula" titulo="Full Metal Jacket" alt="" />
            </a>
        </div>

        <div class="div2MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/theSimpsons.jpg" class="pelicula" titulo="Los Simpsons" alt="" />
            </a>
        </div>

        <div class="div3MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/cosmos.jpg" class="pelicula" titulo="Cosmos: Un Viaje Personal" alt="" />
            </a>
        </div>

        <div class="div4MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/elSilencioDeLosCorderos.jpg" class="pelicula"
                    titulo="El silencio de los corderos" alt="" />
            </a>
        </div>

        <div class="div5MejoresValoradasFoto">
            <a href="html/pelicula.html">
                <img src="/media/img/blackMirror.jpg" class="pelicula" titulo="Black Mirror" alt="" />
            </a>
        </div>

        <div class="div1MejoresValoradas">
            <div class="ratingsMejoresValoradasGenero">
                <!-- Div con la información de la película mejor valorada por género -->
                <div class="div1RatingsGenero">
                    <!-- Div con la nota de la película -->
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9.2</p>
                </div>
                <div class="div2RatingsGenero">
                    <!-- Div con el título de la película -->
                    <h3>La Chaqueta Metálica (1987)</h3>
                </div>
                <div class="div3RatingsGenero">
                    <!-- Div con el género de la película -->
                    <p class="textoGenero">Género: Bélico</p>
                </div>
                <div class="div4RatingsGenero">
                    <!-- Div con el icono de información -->
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div2MejoresValoradas">
            <div class="ratingsMejoresValoradasGenero">
                <div class="div1RatingsGenero">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9</p>
                </div>

                <div class="div2RatingsGenero">
                    <h3>Los Simpsons (1989)</h3>
                </div>
                <div class="div3RatingsGenero">
                    <p class="textoGenero">Género: Animado</p>
                </div>
                <div class="div4RatingsGenero">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div3MejoresValoradas">
            <div class="ratingsMejoresValoradasGenero">
                <div class="div1RatingsGenero">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9.3</p>
                </div>

                <div class="div2RatingsGenero">
                    <h3>Cosmos (1980)</h3>
                </div>
                <div class="div3RatingsGenero">
                    <p class="textoGenero">Género: Documental</p>
                </div>

                <div class="div4RatingsGenero">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div4MejoresValoradas">
            <div class="ratingsMejoresValoradasGenero">
                <div class="div1Ratings">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">9.5</p>
                </div>
                <div class="div2RatingsGenero">
                    <h3>El silencio de los corderos (1991)</h3>
                </div>
                <div class="div3RatingsGenero">
                    <p class="textoGenero">Género: Terror</p>
                </div>
                <div class="div4RatingsGenero">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>

        <div class="div5MejoresValoradas">
            <div class="ratingsMejoresValoradasGenero">
                <div class="div1RatingsGenero">
                    <i class="fa-solid fa-star" style="color: #b197fc"></i>
                    <p class="notaEstrella">8.9</p>
                </div>
                <div class="div2RatingsGenero">
                    <h3>Black Mirror (2011)</h3>
                </div>
                <div class="div3RatingsGenero">
                    <p class="textoGenero">Género: Ciencia Ficción</p>
                </div>
                <div class="div4RatingsGenero">
                    <i class="fa-solid fa-circle-info info" style="color: #b197fc"></i>
                    <span class="textoInformacion">Más información</span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
