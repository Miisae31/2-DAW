@extends('layouts.personalizada')

@section('cuerpo')
    <div class="container">
        <h1 class="title has-text-primary mt-4">{{ __('idioma.crear_actor_titulo') }}</h1>

        <div class="box mb-4">
            <form action="{{ route('actores.store') }}" method="POST" enctype="multipart/form-data">
                @csrf

                <!-- Nombre -->
                <div class="field">
                    <label class="label">{{ __('idioma.nombre') }}</label>
                    <div class="control">
                        <input class="input @error('nombre') is-danger @enderror" type="text" name="nombre"
                            value="{{ old('nombre') }}">
                    </div>
                    @error('nombre')
                        <p class="help is-danger">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Fecha de Nacimiento -->
                <div class="field">
                    <label class="label">{{ __('idioma.fecha_nacimiento') }}</label>
                    <div class="control">
                        <input class="input @error('fecha_nacimiento') is-danger @enderror" type="date"
                            name="fecha_nacimiento" value="{{ old('fecha_nacimiento') }}">
                    </div>
                    @error('fecha_nacimiento')
                        <p class="help is-danger">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Biografía -->
                <div class="field">
                    <label class="label">{{ __('idioma.biografia') }}</label>
                    <div class="control">
                        <textarea class="textarea @error('biografia') is-danger @enderror" name="biografia">{{ old('biografia') }}</textarea>
                    </div>
                    @error('biografia')
                        <p class="help is-danger">{{ $message }}</p>
                    @enderror
                </div>

                <!-- País -->
                <div class="field">
                    <label class="label">{{ __('idioma.pais') }}</label>
                    <div class="control">
                        <input class="input @error('pais') is-danger @enderror" type="text" name="pais"
                            value="{{ old('pais') }}">
                    </div>
                    @error('pais')
                        <p class="help is-danger">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Imagen del Actor -->
                <div class="field">
                    <label class="label">{{ __('idioma.imagen_actor') }}</label>
                    <div class="control">
                        <input class="input @error('imagenActor') is-danger @enderror" type="file" name="imagenActor"
                            accept="image/*">
                    </div>
                    @error('imagenActor')
                        <p class="help is-danger">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Fecha de Fallecimiento -->
                <div class="field">
                    <label class="label">{{ __('idioma.fecha_fallecimiento_opcional') }}</label>
                    <div class="control">
                        <input class="input @error('fecha_fallecimiento') is-danger @enderror" type="date"
                            name="fecha_fallecimiento"
                            value="{{ old('fecha_fallecimiento') }}">
                    </div>
                    @error('fecha_fallecimiento')
                        <p class="help is-danger">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Botones -->
                <div class="field is-grouped">
                    <div class="control">
                        <button class="button is-primary">{{ __('idioma.crear_actor') }}</button>
                    </div>
                    <div class="control">
                        <a href="{{ route('actores.index') }}" class="button is-light">{{ __('idioma.cancelar') }}</a>
                    </div>
                </div>
            </form>
        </div>
    </div>
@endsection
