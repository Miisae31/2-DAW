@extends('layouts.personalizada')

@section('cuerpo')
<div class="container">
    <h1 class="title has-text-primary mt-3">{{ __('idioma.lista_actores') }}</h1>

    <a href="{{ route('actores.create') }}" class="button is-primary mb-4">{{ __('idioma.crear_actor') }}</a>

    @if(session('success'))
        <div class="notification is-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="table-container">
        <table class="table is-striped is-hoverable is-fullwidth">
            <thead>
                <tr class="has-background-primary has-text-white">
                    <th>{{ __('idioma.nombre') }}</th>
                    <th>{{ __('idioma.fecha_nacimiento') }}</th>
                    <th class="has-text-right">{{ __('idioma.acciones') }}</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($actores as $actor)
                    <tr>
                        <td>{{ $actor->nombre }}</td>
                        <td>{{ $actor->fecha_nacimiento }}</td>
                        <td class="has-text-right">
                            <a href="{{ route('actores.edit', $actor->id) }}" class="button is-warning is-small">{{ __('idioma.modificar') }}</a>
                            <form action="{{ route('actores.destroy', $actor->id) }}" method="POST" class="is-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="button is-danger is-small" onclick="return confirm('{{ __('idioma.confirmar_eliminar') }}');"> {{ __('idioma.eliminar') }}</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <div class="pagination is-centered mt-4 mb-4">
        {{ $actores->links('pagination::default') }}
    </div>
</div>
@endsection
