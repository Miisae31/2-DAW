@extends('layouts.personalizada')

@section('cuerpo')
    <div class="paginaEntera">
        <!-- Contenedor principal del contenido -->
        <div class="contentMedia">
            <!-- Título de la película -->
            <h1 class="movie-title">
                {{ $media->titulo }}
                <span class="movie-year">({{ $media->anio_creacion }})</span>
            </h1>

            <div class="media-container">
                <!-- Contenedor para el tráiler en video -->
                <div class="trailer">
                    @if ($media->trailer)
                        <iframe width="700" height="450" src="{{ $media->trailer }}" title="YouTube video player"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                    @else
                        <p>{{__('idioma.no_trailer') }}</p>
                    @endif
                </div>

                <!-- Contenedor para el póster de la película -->
                <div class="poster">
                    <img src="{{ asset('storage/' . $media->portada) }}" alt="Portada de la película">
                </div>
            </div>

            <!-- Sinopsis de la película y géneros -->
            <div class="synopsis">
                <h2>{{ __('idioma.sinopsis') }}</h2>
                <p>{{ $media->sinopsis }}</p>
                <h2>{{ __('idioma.generos') }}:</h2>
                <p>{{ $media->genero }}</p>
            </div>
        </div>

        <!-- Sección del reparto principal -->
        <div class="mejoresValoradasTitulo mb-4">
            <h2 class="title">{{ __('idioma.reparto_principal') }}</h2>
            <div class="vl"></div>
        </div>

        <div class="actoresPrincipalesImagenes">
            @foreach ($media->actores->take(5) as $index => $actor)
                <div class="div{{ $index + 1 }}Actor">
                    <img src="{{ $actor->imagenActor && file_exists(public_path('storage/' . $actor->imagenActor)) ? asset('storage/' . $actor->imagenActor) : asset('media/img/default.jpg') }}"
                        alt="{{ $actor->nombre }}">
                </div>
                <div class="div{{ $index + 7 }}Actor">
                    <div class="descripcion">
                        <div class="divNombre">
                            <h2>{{ $actor->nombre }}</h2>
                        </div>
                        <div class="divProfesion">
                            <p>{{ __('idioma.actor') }}</p>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection
