@extends('layouts.personalizada')

@section('cuerpo')
    <div class="container">
        <h1 class="title has-text-primary mt-3">{{ __('idioma.lista_medias') }}</h1>

        <a href="{{ route('medias.create') }}" class="button is-primary mb-4">{{ __('idioma.crear_media') }}</a>

        @if (session('success'))
            <div class="notification is-success">
                {{ session('success') }}
            </div>
        @endif

        <div class="table-container">
            <table class="table is-striped is-hoverable is-fullwidth">
                <thead>
                    <tr class="has-background-primary has-text-white">
                        <th>{{ __('idioma.titulo') }}</th>
                        <th>{{ __('idioma.director') }}</th>
                        <th>{{ __('idioma.pais') }}</th>
                        <th>{{ __('idioma.genero') }}</th>
                        <th class="has-text-right">{{ __('idioma.acciones') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($media as $medias)
                        <tr>
                            <td>{{ $medias->titulo }}</td>
                            <td>{{ $medias->director }}</td>
                            <td>{{ $medias->pais }}</td>
                            <td>{{ $medias->genero }}</td>
                            <td class="has-text-right">
                                <a href="{{ route('medias.edit', $medias->id) }}"
                                    class="button is-warning is-small">{{ __('idioma.modificar') }}</a>
                                <form action="{{ route('medias.destroy', $medias->id) }}" method="POST" class="is-inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="button is-danger is-small"
                                        onclick="return confirm('{{ __('idioma.confirmar_eliminar') }}');">{{ __('idioma.eliminar') }}</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div class="pagination is-centered mt-4 mb-4">
            {{ $media->links('pagination::default') }}
        </div>
    </div>
@endsection
