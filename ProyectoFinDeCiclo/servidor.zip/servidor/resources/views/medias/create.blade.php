@extends('layouts.personalizada')

@section('cuerpo')
<div class="container">
    <h1 class="title has-text-primary mt-4">{{ __('idioma.crear_media') }}</h1>

    <div class="box">
        <form action="{{ route('medias.store') }}" method="POST" enctype="multipart/form-data">
            @csrf

            <!-- Título -->
            <div class="field">
                <label class="label">{{ __('idioma.titulo') }}</label>
                <div class="control">
                    <input class="input @error('titulo') is-danger @enderror" type="text" name="titulo" value="{{ old('titulo') }}">
                </div>
                @error('titulo')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

             <!-- Imagen de Portada -->
             <div class="field">
                <label class="label">{{ __('idioma.portada') }}</label>
                <div class="control">
                    <input class="input @error('portada') is-danger @enderror" type="file" name="portada" accept="image/*">
                </div>
                @error('portada')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Año de Creación -->
            <div class="field">
                <label class="label">{{ __('idioma.anio_creacion') }}</label>
                <div class="control">
                    <input class="input @error('anio_creacion') is-danger @enderror" type="number" name="anio_creacion" value="{{ old('anio_creacion') }}">
                </div>
                @error('anio_creacion')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Director -->
            <div class="field">
                <label class="label">{{ __('idioma.director') }}</label>
                <div class="control">
                    <input class="input @error('director') is-danger @enderror" type="text" name="director" value="{{ old('director') }}">
                </div>
                @error('director')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Guion -->
            <div class="field">
                <label class="label">{{ __('idioma.guion') }}</label>
                <div class="control">
                    <input class="input @error('guion') is-danger @enderror" type="text" name="guion" value="{{ old('guion') }}">
                </div>
                @error('guion')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- País -->
            <div class="field">
                <label class="label">{{ __('idioma.pais') }}</label>
                <div class="control">
                    <input class="input @error('pais') is-danger @enderror" type="text" name="pais" value="{{ old('pais') }}">
                </div>
                @error('pais')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Sinopsis -->
            <div class="field">
                <label class="label">{{ __('idioma.sinopsis') }}</label>
                <div class="control">
                    <textarea class="textarea @error('sinopsis') is-danger @enderror" name="sinopsis">{{ old('sinopsis') }}</textarea>
                </div>
                @error('sinopsis')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Género -->
            <div class="field">
                <label class="label">{{ __('idioma.genero') }}</label>
                <div class="control">
                    <input class="input @error('genero') is-danger @enderror" type="text" name="genero" value="{{ old('genero') }}">
                </div>
                @error('genero')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Tráiler -->
            <div class="field">
                <label class="label">{{ __('idioma.trailer') }}</label>
                <div class="control">
                    <input class="input @error('trailer') is-danger @enderror" type="text" name="trailer" value="{{ old('trailer') }}" placeholder="https://www.youtube.com/watch?v=xxxxxxx">
                </div>
                @error('trailer')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Puntuación -->
            <div class="field">
                <label class="label">{{ __('idioma.puntuacion') }}</label>
                <div class="control">
                    <input class="input @error('puntuacion') is-danger @enderror" type="text" name="puntuacion" value="{{ old('puntuacion') }}">
                </div>
                @error('puntuacion')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Tipo -->
            <div class="field">
                <label class="label">{{ __('idioma.tipo') }}</label>
                <div class="control">
                    <div class="select">
                        <select name="tipo" id="tipo" class="@error('tipo') is-danger @enderror">
                            <option value="pelicula" {{ old('tipo') == 'pelicula' ? 'selected' : '' }}>{{ __('idioma.pelicula') }}</option>
                            <option value="serie" {{ old('tipo') == 'serie' ? 'selected' : '' }}>{{ __('idioma.serie') }}</option>
                        </select>
                    </div>
                </div>
                @error('tipo')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Duración (solo para películas) -->
            <div class="field" id="duracionField" style="display: none;">
                <label class="label">{{ __('idioma.duracion') }}</label>
                <div class="control">
                    <input class="input @error('duracion') is-danger @enderror" type="text" name="duracion" value="{{ old('duracion') }}">
                </div>
                @error('duracion')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Número de Episodios (solo para series) -->
            <div class="field" id="episodiosField" style="display: none;">
                <label class="label">{{ __('idioma.numero_episodios') }}</label>
                <div class="control">
                    <input class="input @error('n_episodios') is-danger @enderror" type="text" name="n_episodios" value="{{ old('n_episodios') }}">
                </div>
                @error('n_episodios')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Temporadas (solo para series) -->
            <div class="field" id="temporadasField" style="display: none;">
                <label class="label">{{ __('idioma.temporadas') }}</label>
                <div class="control">
                    <input class="input @error('temporadas') is-danger @enderror" type="text" name="temporadas" value="{{ old('temporadas') }}">
                </div>
                @error('temporadas')
                    <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <!-- Botones -->
            <div class="field is-grouped">
                <div class="control">
                    <button class="button is-primary">{{ __('idioma.guardar') }}</button>
                </div>
                <div class="control">
                    <a href="{{ route('medias.index') }}" class="button is-light">{{ __('idioma.cancelar') }}</a>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const tipoSelect = document.getElementById('tipo');
        const duracionField = document.getElementById('duracionField');
        const episodiosField = document.getElementById('episodiosField');
        const temporadasField = document.getElementById('temporadasField');

        function toggleFields() {
            if (tipoSelect.value === 'pelicula') {
                duracionField.style.display = 'block';
                episodiosField.style.display = 'none';
                temporadasField.style.display = 'none';
            } else {
                duracionField.style.display = 'none';
                episodiosField.style.display = 'block';
                temporadasField.style.display = 'block';
            }
        }

        tipoSelect.addEventListener('change', toggleFields);
        toggleFields();
    });
</script>

@endsection
