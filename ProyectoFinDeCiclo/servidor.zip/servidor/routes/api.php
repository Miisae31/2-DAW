<?php

use App\Http\Controllers\ForoApiController;
use App\Http\Controllers\MediaApiController;
use App\Http\Controllers\PerfilApiController;
use App\Http\Controllers\PublicacionApiController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ActorApiController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\ExternaApiController;
use App\Http\Controllers\PeliculaApiController;
use App\Http\Controllers\SerieApiController;
use App\Http\Controllers\UserApiController;
/*\
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

//  Rutas de actores (API)
Route::get('/actores/{id}', [ActorApiController::class, 'show']); // Visible sin login

Route::get('/actores', [ActorApiController::class, 'index']); // Visible sin login
Route::get('/actores/media/{mediaId}', [ActorApiController::class, 'actoresPorMedia']);
Route::middleware(['auth:sanctum', 'admin'])->group(function () {
    Route::post('/actores', [ActorApiController::class, 'store']);
    Route::put('/actores/{id}', [ActorApiController::class, 'update']);
    Route::delete('/actores/{id}', [ActorApiController::class, 'destroy']);
});

//  Rutas de foros (API)
Route::get('/foros', [ForoApiController::class, 'index']); // Visible sin login
Route::get('/foros/{id}', [ForoApiController::class, 'show']); // Visible sin login

Route::middleware(['auth:sanctum'])->group(function () {
    Route::post('/foros', [ForoApiController::class, 'store']);
    Route::put('/foros/{id}', [ForoApiController::class, 'update']);
    Route::delete('/foros/{id}', [ForoApiController::class, 'destroy'])->middleware('admin');
});

//  Rutas de medias (API)
Route::get('/medias/{id}', [MediaApiController::class, 'show']); // Visible sin login
Route::get('/medias', [MediaApiController::class, 'index']); // Visible sin login

Route::middleware(['auth:sanctum'])->group(function () {
    Route::post('/medias', [MediaApiController::class, 'store'])->middleware('admin');
    Route::put('/medias/{id}', [MediaApiController::class, 'update']);
    Route::delete('/medias/{id}', [MediaApiController::class, 'destroy'])->middleware('admin');
});

//  Rutas de perfiles (API) (requiere autenticación)
Route::middleware(['auth:sanctum'])->group(function () {
    Route::get('/perfiles', [PerfilApiController::class, 'index']);
    Route::get('/perfiles/{id}', [PerfilApiController::class, 'show']);
    Route::put('/perfiles/{id}', [PerfilApiController::class, 'update']);
    Route::delete('/perfiles/{id}', [PerfilApiController::class, 'destroy']);
});

//  Rutas de publicaciones (API)
Route::get('/foros/{foro_id}/publicaciones', [PublicacionApiController::class, 'index']); // Visible sin login
Route::get('/publicaciones/{id}', [PublicacionApiController::class, 'show']); // Visible sin login

Route::middleware(['auth:sanctum'])->group(function () {
    Route::post('/publicaciones', [PublicacionApiController::class, 'store']);
    Route::put('/publicaciones/{id}', [PublicacionApiController::class, 'update']);
    Route::delete('/publicaciones/{id}', [PublicacionApiController::class, 'destroy'])->middleware('admin');
});

Route::get('/externa', [ExternaApiController::class, 'obterDatos']);

Route::post('loginAPI', [LoginController::class, 'loginAPI']);

Route::middleware('auth:sanctum')->get('/user', [UserApiController::class, 'user']);
Route::middleware ('auth:sanctum')->post('/logout', [UserApiController::class, 'logout']);


Route::middleware('auth:sanctum')->post('/user/token-premium', [UserApiController::class, 'activarPremium']);

Route::post('/media/premium', [MediaApiController::class, 'indexConToken']);

