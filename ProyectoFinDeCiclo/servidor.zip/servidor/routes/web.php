<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ActorController;
use App\Http\Controllers\ForoController;
use App\Http\Controllers\MediaController;
use App\Http\Controllers\PerfilController;
use App\Http\Controllers\PublicacionController;
use App\Http\Controllers\ExternaController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Página principal
/*
Route::get('/', function () {
    return view('inicio');
});
*/

// Dashboard (requiere autenticación y verificación)

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');



// Perfil de usuario (protegido con auth)
Route::middleware(['auth'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

//  Rutas de actores (CRUD)
Route::get('actores/{actor}', [ActorController::class, 'show'])->name('actores.show'); // Visible sin login

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('actores', [ActorController::class, 'index'])->name('actores.index');
    Route::get('actorescrear', [ActorController::class, 'create'])->name('actores.create'); 
    Route::post('actores', [ActorController::class, 'store'])->name('actores.store');
    Route::get('actores/{actor}/edit', [ActorController::class, 'edit'])->name('actores.edit');
    Route::put('actores/{actor}', [ActorController::class, 'update'])->name('actores.update');
    Route::delete('actores/{actor}', [ActorController::class, 'destroy'])->name('actores.destroy');
});



//  Rutas de foros (CRUD)
/*
Route::get('foros', [ForoController::class, 'index'])->name('foros.index'); // Visible sin login
Route::get('foros/{foro}', [ForoController::class, 'show'])->name('foros.show'); // Visible sin login
Route::middleware(['auth'])->group(function () {
    Route::get('foroscrear', [ForoController::class, 'create'])->name('foros.create');
    Route::post('foros', [ForoController::class, 'store'])->name('foros.store');
    Route::get('foros/{foro}/edit', [ForoController::class, 'edit'])->name('foros.edit');
    Route::put('foros/{foro}', [ForoController::class, 'update'])->name('foros.update');
    Route::delete('foros/{foro}', [ForoController::class, 'destroy'])->middleware('admin')->name('foros.destroy');
});
*/


//  Rutas de medios (CRUD)
Route::get('medias/{media}', [MediaController::class, 'show'])->name('medias.show'); // Visible sin login
Route::middleware(['auth'])->group(function () {
    Route::get('medias', [MediaController::class, 'index'])->middleware('admin')->name('medias.index');
    Route::get('mediascrear', [MediaController::class, 'create'])->middleware('admin')->name('medias.create');
    Route::post('medias', [MediaController::class, 'store'])->name('medias.store');
    Route::get('medias/{media}/edit', [MediaController::class, 'edit'])->middleware('admin')->name('medias.edit');
    Route::put('medias/{media}', [MediaController::class, 'update'])->name('medias.update');
    Route::delete('medias/{media}', [MediaController::class, 'destroy'])->middleware('admin')->name('medias.destroy');
});

//  Rutas de perfiles (CRUD)
Route::middleware(['auth'])->group(function () {
    Route::get('perfiles', [PerfilController::class, 'index'])->name('perfiles.index');
    Route::get('perfiles/{perfil}/edit', [PerfilController::class, 'edit'])->name('perfiles.edit');
    Route::put('perfiles/{perfil}', [PerfilController::class, 'update'])->name('perfiles.update');
    Route::delete('perfiles/{perfil}', [PerfilController::class, 'destroy'])->name('perfiles.destroy');
});

//  Rutas de publicaciones (CRUD)
/*
Route::get('foros/{foro}/publicaciones', [PublicacionController::class, 'index'])->name('publicaciones.index'); // Visible sin login
Route::get('publicaciones/{publicacion}', [PublicacionController::class, 'show'])->name('publicaciones.show'); // Visible sin login
Route::middleware(['auth'])->group(function () {
    Route::get('foros/{foro}/publicacionescrear', [PublicacionController::class, 'create'])->name('publicaciones.create');
    Route::post('publicaciones', [PublicacionController::class, 'store'])->name('publicaciones.store');
    Route::get('publicaciones/{publicacion}/edit', [PublicacionController::class, 'edit'])->name('publicaciones.edit');
    Route::put('publicaciones/{publicacion}', [PublicacionController::class, 'update'])->name('publicaciones.update');
    Route::delete('publicaciones/{publicacion}', [PublicacionController::class, 'destroy'])->middleware('admin')->name('publicaciones.destroy');
});
*/


// Ruta de la API externa
Route::get('/vistaPelis', [ExternaController::class, 'obterDatos'])->name('peliculas.api');


// Ruta de inicio
/*
Route::get('/inicio', function () {
    return view('inicio');
})->name('inicio');
*/

// Rutas para el buscador de medias
Route::get('mediasapifetch', [MediaController::class, 'apifetchMedias']);

// Rutas para los idiomas
Route::get('language/{locale}', function ($locale) {
    app()->setLocale($locale);
    session()->put('locale', $locale);
    return redirect()->back();
})->name('idioma');

// Rutas angular 
Route::post('/login', [AuthenticatedSessionController::class, 'store'])->name('login');
Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');

Route::get('/{any}', function () {
    return file_get_contents(filename: public_path('angular/index.html'));
})->where('any', '^(?!login|logout|register|api|sanctum|csrf-cookie|media|storage).*$');





require __DIR__.'/auth.php';
