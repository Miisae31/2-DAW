<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Actor;
use App\Models\Media;
use Illuminate\Support\Facades\DB;

class ActorMediaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $asignaciones = [
            'Leonardo DiCaprio' => ['Inception', 'Titanic'],
            'Scarlett Johansson' => ['The Avengers', 'Lost in Translation'],
            'Tom Hanks' => ['Forrest Gump', 'Saving Private Ryan'],
            'Natalie Portman' => ['Black Swan', 'V for Vendetta'],
            'Morgan Freeman' => ['The Shawshank Redemption', 'Se7en'],
            'Brad Pitt' => ['Fight Club', 'Once Upon a Time in Hollywood'],
            'Emma Watson' => ['Harry Potter and the Sorcerer\'s Stone', 'Beauty and the Beast'],
            'Robert Downey Jr.' => ['Iron Man', 'Sherlock Holmes'],
            'Christian Bale' => ['The Dark Knight', 'American Psycho'],
            'Angelina Jolie' => ['Tomb Raider', 'Maleficent'],
            'Matthew McConaughey' => ['Interstellar'],
            'Anne Hathaway' => ['Interstellar'],
            'Jessica Chastain' => ['Interstellar'],
            'Michael Caine' => ['Interstellar'],
            'Matt Damon' => ['Interstellar'],
            'Aaron Paul' => ['Breaking Bad'],
            'Bryan Cranston' => ['Breaking Bad'],
            'Anna Gunn' => ['Breaking Bad'],
            'Dean Norris' => ['Breaking Bad'],
            'Bob Odenkirk' => ['Breaking Bad'],
            'Al Pacino' => ['The Godfather', 'Scarface', 'The Godfather Part II'],
            'Robert De Niro' => ['Taxi Driver', 'Goodfellas', 'The Godfather Part II'],
            'James Caan' => ['The Godfather', 'Misery', 'The Godfather Part II'],
            'Diane Keaton' => ['The Godfather', 'Annie Hall', 'The Godfather Part II'],
            'Talia Shire' => ['The Godfather', 'Rocky', 'The Godfather Part II'],
            'Marlon Brando' => ['The Godfather', 'A Streetcar Named Desire', 'Apocalypse Now'],
            'Michael K. Williams' => ['The Wire'],
            'Dominic West' => ['The Wire'],
            'Felicia Pearson' => ['The Wire'],
            'Lance Reddick' => ['The Wire'],
            'Wood Harris' => ['The Wire'],
            'Liam Neeson' => ['Schindler\'s List', 'Taken'],
            'Ralph Fiennes' => ['Schindler\'s List', 'The Grand Budapest Hotel'],
            'Ben Kingsley' => ['Schindler\'s List', 'Gandhi'],
            'Caroline Goodall' => ['Schindler\'s List', 'The Princess Diaries'],
            'Embeth Davidtz' => ['Schindler\'s List'],

        ]; // Asignaciones de actores a películas

        foreach ($asignaciones as $actorNombre => $titulosMedias) { // Recorremos las asignaciones
            $actor = Actor::where('nombre', $actorNombre)->first(); // Buscamos el actor

            if ($actor) { // Si el actor existe
                foreach ($titulosMedias as $tituloMedia) { // Recorremos los títulos de las películas
                    $media = Media::where('titulo', $tituloMedia)->first(); // Buscamos la película

                    if ($media) { // Si la película existe
                        DB::table('actor_media')->insert([ // Insertamos la relación
                            'actor_id' => $actor->id,
                            'media_id' => $media->id,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    }
                }
            }
        }
    }
}
