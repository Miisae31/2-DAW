<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Foro;
use App\Models\Media;

class ForoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Definir las relaciones específicas entre foro y media
        $forosData = [
            'Foro de Inception' => 'Inception',
            'Foro de Titanic' => 'Titanic',
            'Foro de The Dark Knight' => 'The Dark Knight',
            'Foro de Breaking Bad' => 'Breaking Bad',
            'Foro de Game of Thrones' => 'Game of Thrones',
            'Foro de The Godfather' => 'The Godfather',
        ];

        foreach ($forosData as $foroNombre => $mediaTitulo) {
            // Buscar la película/serie por su título
            $media = Media::where('titulo', $mediaTitulo)->first();

            // Si la película/serie existe, crear el foro
            if ($media) {
                Foro::create([
                    'titulo' => $foroNombre,
                    'pelicula_asociada' => $media->id, // Asignar ID exacto
                ]);
            }
        }

    }
}
