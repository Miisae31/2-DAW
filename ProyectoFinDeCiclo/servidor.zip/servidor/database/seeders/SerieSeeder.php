<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Media;
use App\Models\Serie;

class SerieSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $series = [
            ['titulo' => 'Breaking Bad', 'n_episodios' => 62, 'temporadas' => 5],
            ['titulo' => 'Game of Thrones', 'n_episodios' => 73, 'temporadas' => 8],
            ['titulo' => 'Stranger Things', 'n_episodios' => 34, 'temporadas' => 4],
            ['titulo' => 'The Mandalorian', 'n_episodios' => 24, 'temporadas' => 3],
            ['titulo' => 'The Witcher', 'n_episodios' => 24, 'temporadas' => 3],
            ['titulo' => 'Better Call Saul', 'n_episodios' => 63, 'temporadas' => 6],
            ['titulo' => 'Sherlock', 'n_episodios' => 13, 'temporadas' => 4],
            ['titulo' => 'The Office', 'n_episodios' => 201, 'temporadas' => 9],
            ['titulo' => 'Friends', 'n_episodios' => 236, 'temporadas' => 10],
            ['titulo' => 'Money Heist', 'n_episodios' => 41, 'temporadas' => 5], // (La Casa de Papel)
        ];

        foreach ($series as $data) {
            $media = Media::where('titulo', $data['titulo'])->first();
            if ($media) {
                Serie::create([
                    'media_id' => $media->id,
                    'n_episodios' => $data['n_episodios'],
                    'temporadas' => $data['temporadas'],
                ]);
            }
        }
    }
}
