<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Media;

class MediaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $medias = [
            ['titulo' => 'Inception', 'anio_creacion' => 2010, 'director' => 'Christopher Nolan', 'guion' => 'Jonathan Nolan', 'pais' => 'EEUU', 'sinopsis' => 'Un ladrón roba información a través de sueños.', 'genero' => 'Ciencia Ficción', 'trailer' => 'https://youtube.com/inception', 'puntuacion' => 8.8, 'portada' => 'media/img/portadas/inception.jpg'],
                ['titulo' => 'Titanic', 'anio_creacion' => 1997, 'director' => 'James Cameron', 'guion' => 'James Cameron', 'pais' => 'EEUU', 'sinopsis' => 'Un romance trágico en el Titanic.', 'genero' => 'Romance', 'trailer' => 'https://youtube.com/titanic', 'puntuacion' => 9.1, 'portada' => 'media/img/portadas/titanic.jpg'],
                ['titulo' => 'The Dark Knight', 'anio_creacion' => 2008, 'director' => 'Christopher Nolan', 'guion' => 'Jonathan Nolan', 'pais' => 'EEUU', 'sinopsis' => 'Batman enfrenta al Joker.', 'genero' => 'Acción', 'trailer' => 'https://youtube.com/darkknight', 'puntuacion' => 9.0, 'portada' => 'media/img/portadas/theDarkKnight.jpg'],
                ['titulo' => 'Forrest Gump', 'anio_creacion' => 1994, 'director' => 'Robert Zemeckis', 'guion' => 'Eric Roth', 'pais' => 'EEUU', 'sinopsis' => 'La vida de un hombre con un coeficiente bajo.', 'genero' => 'Drama', 'trailer' => 'https://youtube.com/forrestgump', 'puntuacion' => 8.9, 'portada' => 'media/img/portadas/forrestGump.jpg'],
                ['titulo' => 'Interstellar', 'anio_creacion' => 2014, 'director' => 'Christopher Nolan', 'guion' => 'Jonathan Nolan', 'pais' => 'EEUU', 'sinopsis' => 'Exploración espacial en busca de un nuevo hogar.', 'genero' => 'Ciencia Ficción', 'trailer' => 'https://www.youtube.com/embed/UoSSbmD9vqc?si=ikosOfQmjiL4xFZN', 'puntuacion' => 9.2, 'portada' => 'media/img/portadas/interstellar.jpg'],
                ['titulo' => 'Gladiator', 'anio_creacion' => 2000, 'director' => 'Ridley Scott', 'guion' => 'David Franzoni', 'pais' => 'EEUU', 'sinopsis' => 'Un general romano busca venganza.', 'genero' => 'Acción', 'trailer' => 'https://youtube.com/gladiator', 'puntuacion' => 8.5, 'portada' => 'media/img/portadas/gladiator.jpg'],
                ['titulo' => 'The Matrix', 'anio_creacion' => 1999, 'director' => 'Wachowski', 'guion' => 'Wachowski', 'pais' => 'EEUU', 'sinopsis' => 'Descubriendo la verdad sobre la realidad.', 'genero' => 'Ciencia Ficción', 'trailer' => 'https://youtube.com/matrix', 'puntuacion' => 8.7, 'portada' => 'media/img/portadas/theMatrix.jpg'],
                ['titulo' => 'Pulp Fiction', 'anio_creacion' => 1994, 'director' => 'Quentin Tarantino', 'guion' => 'Quentin Tarantino', 'pais' => 'EEUU', 'sinopsis' => 'Historias criminales entrelazadas.', 'genero' => 'Crimen', 'trailer' => 'https://youtube.com/pulpfiction', 'puntuacion' => 9.0, 'portada' => 'media/img/portadas/pulpFiction.jpg'],
                ['titulo' => 'Avatar', 'anio_creacion' => 2009, 'director' => 'James Cameron', 'guion' => 'James Cameron', 'pais' => 'EEUU', 'sinopsis' => 'Una odisea en Pandora.', 'genero' => 'Ciencia Ficción', 'trailer' => 'https://youtube.com/avatar', 'puntuacion' => 8.1, 'portada' => 'media/img/portadas/avatar.jpg'],
                ['titulo' => 'The Godfather', 'anio_creacion' => 1972, 'director' => 'Francis Ford Coppola', 'guion' => 'Mario Puzo', 'pais' => 'EEUU', 'sinopsis' => 'Historia de la mafia Corleone.', 'genero' => 'Crimen', 'trailer' => 'https://www.youtube.com/embed/iOyQx7MXaz0?si=T6FbLVO9QX1aqe0u', 'puntuacion' => 9.3, 'portada' => 'media/img/portadas/elPadrino.jpg'],
                ['titulo' => 'The Shawshank Redemption', 'anio_creacion' => 1994, 'director' => 'Frank Darabont', 'guion' => 'Stephen King', 'pais' => 'EEUU', 'sinopsis' => 'Un banquero es encarcelado por un crimen que no cometió.', 'genero' => 'Drama', 'trailer' => 'https://youtube.com/shawshankredemption', 'puntuacion' => 9.3, 'portada' => 'media/img/portadas/shawshankRedemption.jpg'],
                ['titulo' => 'The Avengers', 'anio_creacion' => 2012, 'director' => 'Joss Whedon', 'guion' => 'Joss Whedon', 'pais' => 'EEUU', 'sinopsis' => 'Superhéroes se unen para salvar el mundo.', 'genero' => 'Acción', 'trailer' => 'https://youtube.com/avengers', 'puntuacion' => 8.0, 'portada' => 'media/img/portadas/theAvengers.jpg'],
                ['titulo' => 'Fight Club', 'anio_creacion' => 1999, 'director' => 'David Fincher', 'guion' => 'Chuck Palahniuk', 'pais' => 'EEUU', 'sinopsis' => 'Un hombre se une a un club de pelea.', 'genero' => 'Drama', 'trailer' => 'https://youtube.com/fightclub', 'puntuacion' => 8.8, 'portada' => 'media/img/portadas/fightClub.jpg'],
                ['titulo' => 'Schindler\'s List', 'anio_creacion' => 1993, 'director' => 'Steven Spielberg', 'guion' => 'Steven Zaillian', 'pais' => 'EEUU', 'sinopsis' => 'Un empresario salva a judíos durante el Holocausto.', 'genero' => 'Drama', 'trailer' => 'https://www.youtube.com/embed/xT0vKdCPH1Q?si=nehKLwK_9AITyk19', 'puntuacion' => 8.9, 'portada' => 'media/img/portadas/laListaDeSchindler.jpg'],
                ['titulo' => 'The Godfather Part II', 'anio_creacion' => 1974, 'director' => 'Francis Ford Coppola', 'guion' => 'Mario Puzo', 'pais' => 'EEUU', 'sinopsis' => 'La historia de Vito Corleone.', 'genero' => 'Crimen', 'trailer' => 'https://www.youtube.com/embed/SBRv7-y3gb8?si=31mUkEw55xntthPo', 'puntuacion' => 9.0, 'portada' => 'media/img/portadas/elPadrino2.jpg'],

                ['titulo' => 'The Wire', 'anio_creacion' => 2002, 'director' => 'David Simon', 'guion' => 'David Simon', 'pais' => 'EEUU', 'sinopsis' => 'Historias de la policía y el crimen en Baltimore.', 'genero' => 'Drama', 'trailer' => 'https://www.youtube.com/embed/1S5khOZ1wBs?si=DZ6Q6GTyFpOxBdJ8', 'puntuacion' => 9.3, 'portada' => 'media/img/portadas/theWire.jpg'],
                ['titulo' => 'Breaking Bad', 'anio_creacion' => 2008, 'director' => 'Vince Gilligan', 'guion' => 'Vince Gilligan', 'pais' => 'EEUU', 'sinopsis' => 'Un profesor de química se convierte en narcotraficante.', 'genero' => 'Drama', 'trailer' => 'https://www.youtube.com/embed/HhesaQXLuRY?si=ENzcVHC0tWxJUqOA', 'puntuacion' => 9.5, 'portada' => 'media/img/portadas/breakingBad.jpg'],
                ['titulo' => 'Game of Thrones', 'anio_creacion' => 2011, 'director' => 'David Benioff', 'guion' => 'George R.R. Martin', 'pais' => 'EEUU', 'sinopsis' => 'Una lucha por el trono de hierro.', 'genero' => 'Fantasía', 'trailer' => 'https://youtube.com/gameofthrones', 'puntuacion' => 9.2, 'portada' => 'media/img/portadas/gameOfThrones.jpg'],
                ['titulo' => 'Stranger Things', 'anio_creacion' => 2016, 'director' => 'Duffer Brothers', 'guion' => 'Duffer Brothers', 'pais' => 'EEUU', 'sinopsis' => 'Un grupo de niños enfrenta criaturas de otro mundo.', 'genero' => 'Ciencia Ficción', 'trailer' => 'https://youtube.com/strangerthings', 'puntuacion' => 8.7, 'portada' => 'media/img/portadas/strangerThings.jpg'],
                ['titulo' => 'The Mandalorian', 'anio_creacion' => 2019, 'director' => 'Jon Favreau', 'guion' => 'Jon Favreau', 'pais' => 'EEUU', 'sinopsis' => 'Un cazarrecompensas en la galaxia de Star Wars.', 'genero' => 'Ciencia Ficción', 'trailer' => 'https://youtube.com/themandalorian', 'puntuacion' => 8.8, 'portada' => 'media/img/portadas/theMandalorian.jpg'],
                ['titulo' => 'The Witcher', 'anio_creacion' => 2019, 'director' => 'Lauren Schmidt Hissrich', 'guion' => 'Andrzej Sapkowski', 'pais' => 'Polonia', 'sinopsis' => 'Un cazador de monstruos busca su destino.', 'genero' => 'Fantasía', 'trailer' => 'https://youtube.com/thewitcher', 'puntuacion' => 8.3, 'portada' => 'media/img/portadas/theWitcher.jpg'],
                ['titulo' => 'Better Call Saul', 'anio_creacion' => 2015, 'director' => 'Vince Gilligan', 'guion' => 'Vince Gilligan', 'pais' => 'EEUU', 'sinopsis' => 'Historia del abogado Saul Goodman.', 'genero' => 'Drama', 'trailer' => 'https://youtube.com/bettercallsaul', 'puntuacion' => 9.0, 'portada' => 'media/img/portadas/betterCallSaul.jpg'],
                ['titulo' => 'Sherlock', 'anio_creacion' => 2010, 'director' => 'Mark Gatiss', 'guion' => 'Arthur Conan Doyle', 'pais' => 'Reino Unido', 'sinopsis' => 'Sherlock Holmes en el siglo XXI.', 'genero' => 'Misterio', 'trailer' => 'https://youtube.com/sherlock', 'puntuacion' => 9.1, 'portada' => 'media/img/portadas/sherlock.jpg'],
                ['titulo' => 'The Office', 'anio_creacion' => 2005, 'director' => 'Greg Daniels', 'guion' => 'Ricky Gervais', 'pais' => 'EEUU', 'sinopsis' => 'Un falso documental sobre una oficina.', 'genero' => 'Comedia', 'trailer' => 'https://youtube.com/theoffice', 'puntuacion' => 8.9, 'portada' => 'media/img/portadas/theOffice.jpg'],
                ['titulo' => 'Friends', 'anio_creacion' => 1994, 'director' => 'David Crane', 'guion' => 'David Crane', 'pais' => 'EEUU', 'sinopsis' => 'La vida de seis amigos en Nueva York.', 'genero' => 'Comedia', 'trailer' => 'https://youtube.com/friends', 'puntuacion' => 8.9, 'portada' => 'media/img/portadas/friends.jpg'],
                ['titulo' => 'Money Heist', 'anio_creacion' => 2017, 'director' => 'Álex Pina', 'guion' => 'Álex Pina', 'pais' => 'España', 'sinopsis' => 'Un grupo de ladrones planea el mayor atraco de la historia.', 'genero' => 'Crimen', 'trailer' => 'https://youtube.com/moneyheist', 'puntuacion' => 8.2, 'portada' => 'media/img/portadas/moneyHeist.jpg'],

            ];

        foreach ($medias as $data) {
            Media::create($data);
        }
    }
}
