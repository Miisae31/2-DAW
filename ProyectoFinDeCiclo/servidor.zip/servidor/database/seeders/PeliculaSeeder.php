<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Media;
use App\Models\Pelicula;

class PeliculaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $peliculas = [
            ['titulo' => 'Inception', 'duracion' => 148],
            ['titulo' => 'Titanic', 'duracion' => 195],
            ['titulo' => 'The Dark Knight', 'duracion' => 152],
            ['titulo' => 'Forrest Gump', 'duracion' => 142],
            ['titulo' => 'Interstellar', 'duracion' => 169],
            ['titulo' => 'Gladiator', 'duracion' => 155],
            ['titulo' => 'The Matrix', 'duracion' => 136],
            ['titulo' => 'Pulp Fiction', 'duracion' => 154],
            ['titulo' => 'Avatar', 'duracion' => 162],
            ['titulo' => 'The Godfather', 'duracion' => 175],
        ];

        foreach ($peliculas as $data) {
            $media = Media::where('titulo', $data['titulo'])->first();
            if ($media) {
                Pelicula::create([
                    'media_id' => $media->id,
                    'duracion' => $data['duracion'],
                ]);
            }
        }
    }
}
