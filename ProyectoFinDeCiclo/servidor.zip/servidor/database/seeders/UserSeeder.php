<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Models\Perfil;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
         $adminId = DB::table('users')->insertGetId([
            'name' => 'Hugo',
            'email' => 'hugoapellidos@gmail.com',
            'email_verified_at' => Carbon::now(),
            'password' => Hash::make('abcd1234'),
            'rol' => 'admin',
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
        ]);


        Perfil::create([
            'user_id' => $adminId,
            'username' => 'HugoAdmin',
            'descripcion' => 'Administrador de MovieLoot',
            'twitter' => '@HugoAdmin',
            'instagram' => '@HugoAdmin',
            'imagen' => 'media/img/perfiles/simpson.jpg', // Imagen por defecto
        ]);
    }
}
