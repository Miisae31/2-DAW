<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Actor;

class ActorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $actores = [
            ['nombre' => 'Leonardo DiCaprio', 'fecha_nacimiento' => '1974-11-11', 'biografia' => 'Actor estadounidense.', 'pais' => 'EEUU', 'imagenActor' => 'leonardo.jpg'],
            ['nombre' => 'Scarlett Johansson', 'fecha_nacimiento' => '1984-11-22', 'biografia' => 'Actriz estadounidense.', 'pais' => 'EEUU', 'imagenActor' => 'scarlett.jpg'],
            ['nombre' => 'Tom Hanks', 'fecha_nacimiento' => '1956-07-09', 'biografia' => 'Actor y productor.', 'pais' => 'EEUU', 'imagenActor' => 'tomhanks.jpg'],
            ['nombre' => 'Natalie Portman', 'fecha_nacimiento' => '1981-06-09', 'biografia' => 'Actriz israelí-estadounidense.', 'pais' => 'Israel', 'imagenActor' => 'natalie.jpg'],
            ['nombre' => 'Morgan Freeman', 'fecha_nacimiento' => '1937-06-01', 'biografia' => 'Actor y narrador.', 'pais' => 'EEUU', 'imagenActor' => 'morgan.jpg'],
            ['nombre' => 'Brad Pitt', 'fecha_nacimiento' => '1963-12-18', 'biografia' => 'Actor y productor.', 'pais' => 'EEUU', 'imagenActor' => 'bradpitt.jpg'],
            ['nombre' => 'Emma Watson', 'fecha_nacimiento' => '1990-04-15', 'biografia' => 'Actriz británica.', 'pais' => 'Reino Unido', 'imagenActor' => 'emmawatson.jpg'],
            ['nombre' => 'Robert Downey Jr.', 'fecha_nacimiento' => '1965-04-04', 'biografia' => 'Actor estadounidense.', 'pais' => 'EEUU', 'imagenActor' => 'rdj.jpg'],
            ['nombre' => 'Christian Bale', 'fecha_nacimiento' => '1974-01-30', 'biografia' => 'Actor británico.', 'pais' => 'Reino Unido', 'imagenActor' => 'bale.jpg'],
            ['nombre' => 'Angelina Jolie', 'fecha_nacimiento' => '1975-06-04', 'biografia' => 'Actriz y directora.', 'pais' => 'EEUU', 'imagenActor' => 'angelina.jpg'],
            ['nombre' => 'Denzel Washington', 'fecha_nacimiento' => '1954-12-28', 'biografia' => 'Actor y director.', 'pais' => 'EEUU', 'imagenActor' => 'denzel.jpg'],
            ['nombre' => 'Meryl Streep', 'fecha_nacimiento' => '1949-06-22', 'biografia' => 'Actriz con múltiples premios Oscar.', 'pais' => 'EEUU', 'imagenActor' => 'meryl.jpg'],
            ['nombre' => 'Johnny Depp', 'fecha_nacimiento' => '1963-06-09', 'biografia' => 'Actor versátil conocido por Piratas del Caribe.', 'pais' => 'EEUU', 'imagenActor' => 'depp.jpg'],
            ['nombre' => 'Joaquin Phoenix', 'fecha_nacimiento' => '1974-10-28', 'biografia' => 'Actor ganador del Oscar por Joker.', 'pais' => 'EEUU', 'imagenActor' => 'joaquin.jpg'],
            ['nombre' => 'Charlize Theron', 'fecha_nacimiento' => '1975-08-07', 'biografia' => 'Actriz sudafricana con múltiples premios.', 'pais' => 'Sudáfrica', 'imagenActor' => 'charlize.jpg'],
            ['nombre' => 'Tom Cruise', 'fecha_nacimiento' => '1962-07-03', 'biografia' => 'Conocido por Misión Imposible.', 'pais' => 'EEUU', 'imagenActor' => 'cruise.jpg'],
            ['nombre' => 'Will Smith', 'fecha_nacimiento' => '1968-09-25', 'biografia' => 'Actor y rapero.', 'pais' => 'EEUU', 'imagenActor' => 'will.jpg'],
            ['nombre' => 'Hugh Jackman', 'fecha_nacimiento' => '1968-10-12', 'biografia' => 'Famoso por interpretar a Wolverine.', 'pais' => 'Australia', 'imagenActor' => 'hugh.jpg'],
            ['nombre' => 'Cate Blanchett', 'fecha_nacimiento' => '1969-05-14', 'biografia' => 'Actriz australiana con múltiples premios.', 'pais' => 'Australia', 'imagenActor' => 'cate.jpg'],
            ['nombre' => 'Samuel L. Jackson', 'fecha_nacimiento' => '1948-12-21', 'biografia' => 'Actor icónico de Hollywood.', 'pais' => 'EEUU', 'imagenActor' => 'samuel.jpg'],
            ['nombre' => 'Chris Hemsworth', 'fecha_nacimiento' => '1983-08-11', 'biografia' => 'Conocido por su papel de Thor.', 'pais' => 'Australia', 'imagenActor' => 'chris.jpg'],
            ['nombre' => 'Keanu Reeves', 'fecha_nacimiento' => '1964-09-02', 'biografia' => 'Famoso por The Matrix y John Wick.', 'pais' => 'Canadá', 'imagenActor' => 'keanu.jpg'],
            ['nombre' => 'Nicole Kidman', 'fecha_nacimiento' => '1967-06-20', 'biografia' => 'Actriz australiana de gran trayectoria.', 'pais' => 'Australia', 'imagenActor' => 'nicole.jpg'],
            ['nombre' => 'Javier Bardem', 'fecha_nacimiento' => '1969-03-01', 'biografia' => 'Actor español ganador del Oscar.', 'pais' => 'España', 'imagenActor' => 'javier.jpg'],
            ['nombre' => 'Penélope Cruz', 'fecha_nacimiento' => '1974-04-28', 'biografia' => 'Actriz española de renombre.', 'pais' => 'España', 'imagenActor' => 'penelope.jpg'],
            ['nombre' => 'Gary Oldman', 'fecha_nacimiento' => '1958-03-21', 'biografia' => 'Actor británico de gran prestigio.', 'pais' => 'Reino Unido', 'imagenActor' => 'gary.jpg'],
            ['nombre' => 'Ben Affleck', 'fecha_nacimiento' => '1972-08-15', 'biografia' => 'Actor y director estadounidense.', 'pais' => 'EEUU', 'imagenActor' => 'affleck.jpg'],
            ['nombre' => 'Matthew McConaughey', 'fecha_nacimiento' => '1969-11-04', 'biografia' => 'Actor y productor estadounidense, conocido por su papel en Interstellar.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/matthew_mcconaughey.jpg'],
            ['nombre' => 'Anne Hathaway', 'fecha_nacimiento' => '1982-11-12', 'biografia' => 'Actriz estadounidense ganadora del Oscar, famosa por sus papeles en El diablo viste a la moda e Interstellar.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/anne_hathaway.jpg'],
            ['nombre' => 'Jessica Chastain', 'fecha_nacimiento' => '1977-03-24', 'biografia' => 'Actriz estadounidense reconocida por su trabajo en La noche más oscura e Interstellar.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/jessica_chastain.jpg'],
            ['nombre' => 'Michael Caine', 'fecha_nacimiento' => '1933-03-14', 'biografia' => 'Actor británico icónico, colaborador frecuente de Christopher Nolan.', 'pais' => 'Reino Unido', 'imagenActor' => 'media/img/actores/michael_caine.jpg'],
            ['nombre' => 'Matt Damon', 'fecha_nacimiento' => '1970-10-08', 'biografia' => 'Actor y guionista estadounidense, famoso por El indomable Will Hunting y su aparición en Interstellar.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/matt_damon.jpg'],
            ['nombre' => 'Aaron Paul', 'fecha_nacimiento' => '1979-08-27', 'biografia' => 'Actor estadounidense conocido por su papel en Breaking Bad.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/aaron_paul.jpg'],
            ['nombre' => 'Bryan Cranston', 'fecha_nacimiento' => '1956-03-07', 'biografia' => 'Actor y director estadounidense, famoso por su papel en Breaking Bad.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/bryan_cranston.jpg'],
            ['nombre' => 'Anna Gunn', 'fecha_nacimiento' => '1968-08-11', 'biografia' => 'Actriz estadounidense conocida por su papel en Breaking Bad.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/anna_gunn.jpg'],
            ['nombre' => 'Dean Norris', 'fecha_nacimiento' => '1963-04-08', 'biografia' => 'Actor estadounidense conocido por su papel en Breaking Bad.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/dean_norris.jpg'],
            ['nombre' => 'Bob Odenkirk', 'fecha_nacimiento' => '1962-10-22', 'biografia' => 'Actor y guionista estadounidense, conocido por su papel en Breaking Bad.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/bob_odenkirk.jpg'],
            ['nombre' => 'Al Pacino', 'fecha_nacimiento' => '1940-04-25', 'biografia' => 'Actor y director estadounidense, famoso por El padrino y Scarface.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/al_pacino.jpg'],
            ['nombre' => 'Robert De Niro', 'fecha_nacimiento' => '1943-08-17', 'biografia' => 'Actor y director estadounidense, famoso por Taxi Driver y El padrino Parte II.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/robert_de_niro.jpg'],
            ['nombre' => 'James Caan', 'fecha_nacimiento' => '1940-03-26', 'biografia' => 'Actor estadounidense, famoso por El padrino y Misery.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/james_caan.jpg'],
            ['nombre' => 'Diane Keaton', 'fecha_nacimiento' => '1946-01-05', 'biografia' => 'Actriz estadounidense, famosa por El padrino y Annie Hall.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/diane_keaton.jpg'],
            ['nombre' => 'Talia Shire', 'fecha_nacimiento' => '1946-04-25', 'biografia' => 'Actriz estadounidense, famosa por El padrino y Rocky.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/talia_shire.jpg'],
            ['nombre' => 'Marlon Brando', 'fecha_nacimiento' => '1924-04-03', 'biografia' => 'Actor y director estadounidense, famoso por El padrino y Apocalypse Now.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/marlon_brando.jpg'],
            ['nombre' => 'Michael K. Williams', 'fecha_nacimiento' => '1966-11-22', 'biografia' => 'Actor estadounidense, conocido por su papel en The Wire.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/michael_k_williams.jpg'],
            ['nombre' => 'Dominic West', 'fecha_nacimiento' => '1969-10-15', 'biografia' => 'Actor británico, conocido por su papel en The Wire.', 'pais' => 'Reino Unido', 'imagenActor' => 'media/img/actores/dominic_west.jpg'],
            ['nombre' => 'Felicia Pearson', 'fecha_nacimiento' => '1980-05-18', 'biografia' => 'Actriz y rapera estadounidense, conocida por su papel en The Wire.', 'pais' => 'EEUU ', 'imagenActor' => 'media/img/actores/felicia_pearson.jpg'],
            ['nombre' => 'Lance Reddick', 'fecha_nacimiento' => '1962-12-31', 'biografia' => 'Actor y músico estadounidense, conocido por su papel en The Wire.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/lance_reddick.jpg'],
            ['nombre' => 'Wood Harris', 'fecha_nacimiento' => '1969-10-17', 'biografia' => 'Actor estadounidense, conocido por su papel en The Wire.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/wood_harris.jpg'],
            ['nombre' => 'Liam Neeson', 'fecha_nacimiento' => '1952-06-07', 'biografia' => 'Actor y productor irlandés, conocido por La lista de Schindler y Taken.', 'pais' => 'Irlanda', 'imagenActor' => 'media/img/actores/liam_neeson.jpg'],
            ['nombre' => 'Ralph Fiennes', 'fecha_nacimiento' => '1962-12-22', 'biografia' => 'Actor y director británico, conocido por La lista de Schindler y El gran hotel Budapest.', 'pais' => 'Reino Unido', 'imagenActor' => 'media/img/actores/ralph_fiennes.jpg'],
            ['nombre' => 'Ben Kingsley', 'fecha_nacimiento' => '1943-12-31', 'biografia' => 'Actor y productor británico, conocido por La lista de Schindler y Gandhi.', 'pais' => 'Reino Unido', 'imagenActor' => 'media/img/actores/ben_kingsley.jpg'],
            ['nombre' => 'Caroline Goodall', 'fecha_nacimiento' => '1959-11-13', 'biografia' => 'Actriz y guionista británica, conocida por La lista de Schindler y Diario de una princesa.', 'pais' => 'Reino Unido', 'imagenActor' => 'media/img/actores/caroline_goodall.jpg'],
            ['nombre' => 'Embeth Davidtz', 'fecha_nacimiento' => '1965-08-11', 'biografia' => 'Actriz estadounidense, conocida por La lista de Schindler.', 'pais' => 'EEUU', 'imagenActor' => 'media/img/actores/embeth_davidtz.jpg'],
        ];

        foreach ($actores as $actor) {
            Actor::create($actor);
        }
    }
}
