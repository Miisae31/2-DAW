export class Usuario {
    id!: number;
    name!: string;
    rol?: string;
  }
  
  export class Pelicula {
    titulo!: string;
  }
  
  export class Publicacion {
    id!: number;
    titulo!: string;
    contenido!: string;
    user!: Usuario;
    user_id!: number;
    fecha_creacion!: string;
  }
  
  export class Foro {
    id!: number;
    titulo!: string;
    pelicula?: Pelicula;
    publicaciones!: Publicacion[];
  }
  