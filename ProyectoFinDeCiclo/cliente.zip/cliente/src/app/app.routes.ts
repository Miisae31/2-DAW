import { EditarPublicacionComponent } from './foros/foro-detalle/editar-publicacion/editar-publicacion.component';
import { PerfilComponent } from "./perfil/perfil.component";
import { Routes } from "@angular/router";
import { MediaViewComponent } from "./media-view/media-view.component";
import { VistaGeneralComponent } from "./vista-general/vista-general.component";
import { ForosComponent } from "./foros/foros.component";
import { ForoDetalleComponent } from "./foros/foro-detalle/foro-detalle.component";
import { PublicacionDetalleComponent } from "./foros/foro-detalle/publicacion-detalle/publicacion-detalle.component";
import { CreateForoComponent } from "./foros/crear-foro/crear-foro.component";
import { adminGuard } from "./guards/admin.guard";
import { AdministracionComponent } from "./administracion/administracion.component";
import { authGuard } from "./guards/auth.guard";
import { EditarForoComponent } from "./foros/editar-foro/editar-foro.component";
import { canEditPublicacionGuard } from './guards/can-edit-publicacion.guard';
import { CrearPublicacionComponent } from './foros/foro-detalle/crear-publicacion/crear-publicacion.component';
import { PremiumComponent } from './premium/premium.component';
import { AyudaComponent } from './ayuda/ayuda.component';

// Hacemos las rutas para las redirecciones de la aplicación
export const routes: Routes = [
  { path: "inicio", title: "Inicio", component: VistaGeneralComponent }, 
  { path: "", redirectTo: "inicio", pathMatch: "full" }, 
  { path: "media-view", title: "Media", component: MediaViewComponent }, 
  { path: "perfil", title: "Perfil", component: PerfilComponent, canActivate: [authGuard] }, 
  { path: "foros", title: "Foros", component: ForosComponent }, 
  { path: "publicaciones/:id", component: PublicacionDetalleComponent },
  { path: "publicaciones/editar/:id", component: EditarPublicacionComponent, canActivate: [canEditPublicacionGuard] }, 
  { path: "foros/:foroId/crear-publicacion", title: "Crear Publicación", component: CrearPublicacionComponent, canActivate: [authGuard] },
  { path: "administracion", title: "Administración", component: AdministracionComponent, canActivate: [adminGuard] }, 
  { path: "foros/crear", title: "Crear Foro", component: CreateForoComponent, canActivate: [authGuard] },
  { path: "foros/editar/:id", title: "Editar Foro", component: EditarForoComponent, canActivate: [adminGuard] },
  { path: "foros/:id", component: ForoDetalleComponent }, 
  { path: 'perfil',component: PerfilComponent,canActivate: [authGuard],title: 'Tu Perfil' },
  { path: 'premium',component: PremiumComponent,canActivate: [authGuard],title: 'Planes Premium' },
  { path: 'ayuda',component: AyudaComponent,title: 'Ayuda' }

];
