import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-premium',
  templateUrl: './premium.component.html',
  styleUrls: ['./premium.component.css'],
  standalone: true,
  imports: [HeaderComponent, FooterComponent, CommonModule]
})
export class PremiumComponent implements OnInit {
  isPurchasing = false;
  purchaseComplete = false;
  tokenPremium: string | null = null;
  showToken = false;
  private baseUrl = 'http://localhost:8000'; 

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.checkPremiumStatus();
  }

  checkPremiumStatus() {
    this.http.get<{ token_premium?: string }>(`${this.baseUrl}/api/user`, { withCredentials: true }).subscribe({
      next: (user) => {
        if (user.token_premium) {
          this.purchaseComplete = true;
          this.tokenPremium = user.token_premium;  // Guarda el token para mostrarlo
        }
      },
      error: (err) => {
        console.error('Error al obtener usuario:', err);
      }
    });
  }

  copyToken() {
    if (!this.tokenPremium) return;
  
    navigator.clipboard.writeText(this.tokenPremium).then(() => {
      alert('Token copiado al portapapeles!');
    }, () => {
      alert('Error copiando el token');
    });
  }

  comprarPlan() {
    if (this.purchaseComplete) return;  // Por si acaso, evitar doble compra

    this.isPurchasing = true;
  
    setTimeout(() => {
      const token = this.generateToken();
  
      this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).subscribe({
        next: () => {
          const xsrfToken = this.getCookie('XSRF-TOKEN');
  
          this.http.post(
            `${this.baseUrl}/api/user/token-premium`,
            { token_premium: token },
            {
              withCredentials: true,
              headers: {
                'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
              }
            }
          ).subscribe({
            next: () => {
              this.isPurchasing = false;
              this.purchaseComplete = true;
            },
            error: () => {
              this.isPurchasing = false;
              alert('Error al activar el plan premium');
            }
          });
        },
        error: () => {
          this.isPurchasing = false;
          alert('Error obteniendo token CSRF');
        }
      });
    }, 2000);
  }
  
  private getCookie(name: string): string {
    const cookies = document.cookie.split('; ');
    const cookie = cookies.find(c => c.startsWith(name + '='));
    return cookie ? cookie.split('=')[1] : '';
  }

  generateToken(): string {
    return 'tok_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
  }
}
