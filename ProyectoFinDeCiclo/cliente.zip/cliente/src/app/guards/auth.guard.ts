import { inject } from '@angular/core';
import { CanActivateFn } from '@angular/router';
import { ServizoLoginService } from '../services/servizo-login.service';
import { map, take } from 'rxjs/operators';

export const authGuard: CanActivateFn = (route, state) => {
  const servicio = inject(ServizoLoginService);

  return servicio.user$.pipe(
    take(1),
    map(user => {
      if (user) {
        return true; // Usuario autenticado
      } else {
        window.location.href = 'http://localhost:8000/login'; // Redirige fuera del SPA
        return false;
      }
    })
  );
};
