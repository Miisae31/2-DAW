import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { ServizoLoginService } from '../services/servizo-login.service';
import { map, take } from 'rxjs/operators';

export const adminGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const servicio = inject(ServizoLoginService);

  return servicio.user$.pipe(
    take(1), // tomamos solo el primer valor emitido
    map(user => {
      if (user && user.rol === 'admin') {
        return true; // acceso permitido
      } else {
        router.navigate(['/inicio']); // redirigir si no es admin
        return false;
      }
    })
  );
};
