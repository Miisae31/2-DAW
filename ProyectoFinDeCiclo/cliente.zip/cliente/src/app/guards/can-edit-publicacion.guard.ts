import { Injectable, inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map, switchMap, of } from 'rxjs';
import { ForoService } from '../foros/foro.service';
import { ServizoLoginService } from '../services/servizo-login.service';

export const canEditPublicacionGuard: CanActivateFn = (route, state) => {
  const foroService = inject(ForoService);
  const loginService = inject(ServizoLoginService);
  const router = inject(Router);

  const id = +route.paramMap.get('id')!;

  return loginService.user$.pipe(
    switchMap(user => {
      if (!user) {
        router.navigate(['/foros']);
        return of(false);
      }

      return foroService.obtenerPublicacion(id).pipe(
        map((res: any) => {
          const publicacion = res.data || res;
          const isOwner = publicacion.user_id === user.id;
          const isAdmin = user.rol === 'admin';

          if (isOwner || isAdmin) {
            return true;
          }

          // Redirige a foro si no tiene permiso
          router.navigate(['/foros', publicacion.foro_id]);
          return false;
        })
      );
    })
  );
};
