import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, switchMap } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class PerfilService {
  private API_URL = 'http://localhost:8000/api';
  private baseUrl = 'http://localhost:8000';

  constructor(private http: HttpClient) {}

  obtenerPerfil(): Observable<any> {
    return this.http.get(`${this.API_URL}/perfiles`, { withCredentials: true });
  }

  eliminarPerfil(id: number): Observable<any> {
    const xsrfToken = this.getCookie('XSRF-TOKEN');

    return this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).pipe(
      switchMap(() =>
        this.http.delete(`${this.API_URL}/perfiles/${id}`, {
          withCredentials: true,
          headers: {
            'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
          },
        })
      )
    );
  }

  private getCookie(name: string): string {
    const cookies = document.cookie.split('; ');
    const cookie = cookies.find(c => c.startsWith(name + '='));
    return cookie ? cookie.split('=')[1] : '';
  }
}
