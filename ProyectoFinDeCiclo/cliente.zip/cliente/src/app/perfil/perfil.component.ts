import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { PerfilService } from './perfil.service';

@Component({
  selector: 'app-perfil',
  standalone: true,
  templateUrl: './perfil.component.html',
  styleUrl: './perfil.component.css',
  imports: [CommonModule, HeaderComponent, FooterComponent, RouterModule],
})
export class PerfilComponent implements OnInit {
  perfil: any = null;

  constructor(private perfilService: PerfilService, private router: Router) {}

  ngOnInit(): void {
    this.perfilService.obtenerPerfil().subscribe({
      next: (data) => {
        this.perfil = data.data;
      },
      error: (err) => {
        console.error('Error cargando perfil', err);
      },
    });
  }

  confirmarEliminar(): void {
    if (confirm('¿Estás seguro de que deseas eliminar tu perfil? Esta acción no se puede deshacer.')) {
      this.perfilService.eliminarPerfil(this.perfil.id).subscribe({
        next: () => {
          // redirige al logout o login
          this.router.navigate(['/inicio']);
        },
        error: () => {
          alert('Error al eliminar perfil');
        },
      });
    }
  }
}
