import { Component, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  @ViewChild('termsAudio') termsAudio!: ElementRef<HTMLAudioElement>;

  playTermsAudio(): void {
    this.termsAudio.nativeElement.play();
  }
}
