import { Component, OnInit } from "@angular/core";
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { ActoresComponent } from "./actores/actores.component";
import { CommonModule } from "@angular/common";
import { MediaService } from "./media.service";
import { ActorService } from "./actores/actores.service";
import { Serieclase } from "../models/serieclase";
import { Peliculaclase } from "../models/peliculaclase";
import { DomSanitizer, SafeResourceUrl } from "@angular/platform-browser";

@Component({
  selector: "app-media-view",
  standalone: true,
  imports: [HeaderComponent, FooterComponent, ActoresComponent, CommonModule],
  templateUrl: "./media-view.component.html",
  styleUrl: "./media-view.component.css",
})
export class MediaViewComponent implements OnInit {
  peliculaSeleccionada: Peliculaclase | null = null;
  serieSeleccionada: Serieclase | null = null;
  actoresFilm: any[] = [];
  safeTrailerUrl: SafeResourceUrl | null = null;

  constructor(
    private mediaService: MediaService,
    private actorService: ActorService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit(): void {
    const idStr = localStorage.getItem('mediaId');
    const id = idStr ? parseInt(idStr, 10) : null;

    if (id) {
      this.mediaService.getMediaById(id).subscribe({
        next: (response: { success: boolean; data: any }) => {
          if (response.success) {
            const media = response.data;

            if (media.trailer && typeof media.trailer === 'string' && media.trailer.trim() !== '') {
              this.safeTrailerUrl = this.sanitizer.bypassSecurityTrustResourceUrl(media.trailer);
            } else {
              console.warn('No se encontró una URL de trailer válida:', media.trailer);
              this.safeTrailerUrl = null; 
            }

            if (media.tipo?.toLowerCase() === 'pelicula') {
              this.peliculaSeleccionada = new Peliculaclase(
                media.id,
                media.titulo,
                media.anio_creacion,
                media.sinopsis,
                media.genero,
                media.puntuacion,
                media.trailer,
                media.portada
              );
            } else if (media.tipo?.toLowerCase() === 'serie') {
              this.serieSeleccionada = new Serieclase(
                media.id,
                media.titulo,
                media.anio_creacion,
                media.sinopsis,
                media.genero,
                media.puntuacion,
                media.trailer,
                media.portada
              );
            } else {
            }

            // Traer actores
            this.actorService.getActoresPorMedia(id).subscribe({
              next: (actorResponse) => {
                if (actorResponse.success) {
                  this.actoresFilm = actorResponse.data;
                  // Depuración adicional para cada actor
                  this.actoresFilm.forEach(actor => {
                  });
                }
              },
              error: (err) => {
                console.error('Error al obtener actores:', err);
              }
            });
          } else {
            console.error('Media no encontrada:');
          }
        },
        error: (err: any) => {
          console.error('Error al obtener media:', err);
        }
      });
    } else {
      console.error('No se encontró el ID en localStorage');
    }
  }
}

