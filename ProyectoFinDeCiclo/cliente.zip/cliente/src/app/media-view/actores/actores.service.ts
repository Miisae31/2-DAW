import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ActorService {
  private apiUrl = 'http://localhost:8000/api/actores';

  constructor(private http: HttpClient) {}

  getActores(): Observable<any> {
    return this.http.get<any>(this.apiUrl);
  }

  getActoresPorMedia(mediaId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/media/${mediaId}`);
  }
}
