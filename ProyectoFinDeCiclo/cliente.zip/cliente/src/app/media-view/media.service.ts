import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { Media } from '../search/mediaSearch.service';

@Injectable({
  providedIn: 'root'
})
export class MediaService {
  private apiUrl = 'http://localhost:8000/api/medias';

  constructor(private http: HttpClient) {}

  getMediaById(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  getMediaByTitle(titulo: string): Observable<Media | undefined> {
    return this.http.get<Media[]>(`${this.apiUrl}/medias`, {
      params: {
        texto: titulo
      }
    }).pipe(
      map((medias: any[]) => medias.find((media: { titulo: string; }) => media.titulo.toLowerCase() === titulo.toLowerCase()))
    );
  }
}
