import { Component } from "@angular/core";
import { HeaderComponent } from "../header/header.component";
import { FooterComponent } from "../footer/footer.component";
import { OnInit } from "@angular/core";
import { ForoService } from "./foro.service";
import { CommonModule } from "@angular/common";
import { Router, RouterModule } from "@angular/router";
import { ServizoLoginService } from "../services/servizo-login.service";
@Component({
  selector: "app-foros",
  templateUrl: "./foros.component.html",
  standalone: true,
  imports: [HeaderComponent, FooterComponent, CommonModule, RouterModule],
  styleUrls: ["./foros.component.css"],
})
export class ForosComponent implements OnInit {
  foros: any[] = [];
  currentPage = 1;
  lastPage = 1;
  isAdmin = false;
  errorMessage: string = ''; 
  constructor(
    private foroService: ForoService,
    private servicioLogin: ServizoLoginService,
    private router: Router
  ) {}

  ngOnInit(): void {

    this.obtenerForos();

    this.servicioLogin.user$.subscribe(user => {
      this.isAdmin = user?.rol === 'admin';
    });
  }

  obtenerForos(page: number = 1): void {
    this.foroService.obtenerForos(page).subscribe((response) => {
      this.foros = response.data.data;
      this.currentPage = response.data.current_page;
      this.lastPage = response.data.last_page;
    });
  }

  cambiarPagina(page: number) {
    this.obtenerForos(page);
  }

  eliminarForo(id: number) {
    this.errorMessage = ''; 
  
    this.foroService.eliminarForo(id).subscribe({
      next: () => {
        this.obtenerForos(this.currentPage);
      },
      error: () => {
        this.errorMessage = 'Error al eliminar el foro. Por favor, inténtalo de nuevo.';
      }
    });
  }

  editarForo(id: number) {
    this.router.navigate(['/foros/editar', id]);
  }
}
