import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, switchMap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ForoService {
  private API_URL = 'http://localhost:8000/api'; 
  private baseUrl = "http://localhost:8000";

  constructor(private http: HttpClient) {}

  // Obtener foros paginados
  obtenerForos(page: number = 1): Observable<any> {
    return this.http.get(`${this.API_URL}/foros?page=${page}`);
  }

  // Obtener foro específico con publicaciones
  obtenerForoConPublicaciones(foroId: number): Observable<any> {
    return this.http.get(`${this.API_URL}/foros/${foroId}`);
  }

  crearForo(data: { titulo: string; pelicula_asociada?: number | null }): Observable<any> {
    const xsrfToken = this.getCookie('XSRF-TOKEN');

    return this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).pipe(
      switchMap(() =>
        this.http.post(`${this.API_URL}/foros`, data, {
          withCredentials: true,
          headers: {
            'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
          },
        })
      )
    );
  }

  editarForo(id: number, data: { titulo: string; pelicula_asociada?: number | null }): Observable<any> {
    const xsrfToken = this.getCookie('XSRF-TOKEN');

    return this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).pipe(
      switchMap(() =>
        this.http.put(`${this.API_URL}/foros/${id}`, data, {
          withCredentials: true,
          headers: {
            'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
          },
        })
      )
    );
  }

  eliminarForo(id: number): Observable<any> {
    const xsrfToken = this.getCookie('XSRF-TOKEN');

    return this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).pipe(
      switchMap(() =>
        this.http.delete(`${this.API_URL}/foros/${id}`, {
          withCredentials: true,
          headers: {
            'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
          },
        })
      )
    );
  }

  // Editar una publicación existente
editarPublicacion(id: number, data: any): Observable<any> {
  const xsrfToken = this.getCookie('XSRF-TOKEN');

  return this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).pipe(
    switchMap(() =>
      this.http.put(`${this.API_URL}/publicaciones/${id}`, data, {
        withCredentials: true,
        headers: {
          'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
        },
      })
    )
  );
}

// Eliminar una publicación
eliminarPublicacion(id: number): Observable<any> {
  const xsrfToken = this.getCookie('XSRF-TOKEN');

  return this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).pipe(
    switchMap(() =>
      this.http.delete(`${this.API_URL}/publicaciones/${id}`, {
        withCredentials: true,
        headers: {
          'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
        },
      })
    )
  );
}

  private getCookie(name: string): string {
    const cookies = document.cookie.split('; ');
    const cookie = cookies.find(c => c.startsWith(name + '='));
    return cookie ? cookie.split('=')[1] : '';
  }

  // Obtener publicaciones de un foro 
  obtenerPublicaciones(foroId: number, page: number = 1): Observable<any> {
    return this.http.get(`${this.API_URL}/foros/${foroId}/publicaciones?page=${page}`);
  }

  // Crear una nueva publicación con token CSRF
crearPublicacion(data: any): Observable<any> {
  const xsrfToken = this.getCookie('XSRF-TOKEN');

  return this.http.get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true }).pipe(
    switchMap(() =>
      this.http.post(`${this.API_URL}/publicaciones`, data, {
        withCredentials: true,
        headers: {
          'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
        },
      })
    )
  );
}


  // Obtener publicación individual
  obtenerPublicacion(id: number): Observable<any> {
    return this.http.get(`${this.API_URL}/publicaciones/${id}`);
  }

  getForoConPublicaciones(id: number): Observable<any> {
    return this.http.get(`${this.API_URL}/foros/${id}`);
  }
  
}
