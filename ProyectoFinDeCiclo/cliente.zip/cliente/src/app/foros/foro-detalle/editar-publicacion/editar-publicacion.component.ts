import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../header/header.component';
import { FooterComponent } from '../../../footer/footer.component';
import { ForoService } from '../../foro.service';

@Component({
  selector: 'app-editar-publicacion',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule, HeaderComponent, FooterComponent],
  templateUrl: './editar-publicacion.component.html',
})
export class EditarPublicacionComponent implements OnInit {
  publicacionId!: number;
  publicacion: any = {
    titulo: '',
    etiqueta: '',
    body: '',
    imagen: ''
  };
  loading = true;

  constructor(
    private route: ActivatedRoute,
    private foroService: ForoService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.publicacionId = +id;
      this.foroService.obtenerPublicacion(this.publicacionId).subscribe({
        next: (res: any) => {
          this.publicacion = res.data || res;
          this.loading = false;
        },
        error: () => {
          console.error('Error cargando la publicación');
          this.loading = false;
        }
      });
    }
  }

  guardarCambios(): void {
    this.foroService.editarPublicacion(this.publicacionId, this.publicacion).subscribe({
      next: () => {
        this.router.navigate(['/foros', this.publicacion.foro_id]);
      },
    });
  }

  cancelar(): void {
    this.router.navigate(['/foros', this.publicacion.foro_id]);
  }
}
