import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from "@angular/forms";
import { Router, ActivatedRoute, RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { HeaderComponent } from "../../../header/header.component";
import { FooterComponent } from "../../../footer/footer.component";
import { ForoService } from "../../foro.service";

@Component({
  selector: "app-crear-publicacion",
  templateUrl: "./crear-publicacion.component.html",
  styleUrls: ["./crear-publicacion.component.css"],
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, HeaderComponent, FooterComponent, RouterModule],
})
export class CrearPublicacionComponent implements OnInit {
  publicacionForm: FormGroup;
  foroId!: number;
  submitting = false;
  errores: any = null;
  errorMessage = "";
  foroTitulo = "";

  constructor(
    private fb: FormBuilder,
    private foroService: ForoService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.publicacionForm = this.fb.group({
      foro_id: ["", Validators.required],
      titulo: ["", [Validators.required, Validators.maxLength(255)]],
      etiqueta: [""],
      body: ["", Validators.required],
      imagen: [""],
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params) => {
      const id = params.get("foroId");
      if (id) {
        this.foroId = +id;
        this.publicacionForm.patchValue({ foro_id: this.foroId });
        this.foroService.obtenerForoConPublicaciones(this.foroId).subscribe({
          next: (res) => {
            this.foroTitulo = res.titulo || "foro";
          },
          error: () => {
            this.foroTitulo = "foro";
          },
        });
      }
    });
  }

  submit() {
    if (this.publicacionForm.invalid) {
      this.publicacionForm.markAllAsTouched();
      return;
    }

    this.submitting = true;
    this.errorMessage = "";
    this.errores = null;

    this.foroService.crearPublicacion(this.publicacionForm.value).subscribe({
      next: (res) => {
        this.submitting = false;
        this.router.navigate(["/foros", this.foroId]);
      },
      error: (err) => {
        this.submitting = false;
        if (err.status === 422) {
          this.errores = err.error.errors;
        } else {
          this.errorMessage = "Error creando la publicación.";
        }
      },
    });
  }
}
