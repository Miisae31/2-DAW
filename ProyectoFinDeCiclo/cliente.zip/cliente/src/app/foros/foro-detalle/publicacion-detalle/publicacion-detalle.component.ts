import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ForoService } from '../../foro.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from '../../../header/header.component';
import { FooterComponent } from '../../../footer/footer.component';

@Component({
  selector: 'app-publicacion-detalle',
  templateUrl: './publicacion-detalle.component.html',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent, RouterModule],
})
export class PublicacionDetalleComponent implements OnInit {
  publicacion: any = null;
  loading = true;

  constructor(private route: ActivatedRoute, private foroService: ForoService) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.foroService.obtenerPublicacion(+id).subscribe({
        next: (res: any) => {
          this.publicacion = res.data || res;
          this.loading = false;
        },
        error: (err) => {
          console.error('Error cargando publicación:', err);
          this.loading = false;
        }
      });
    }
  }
}
