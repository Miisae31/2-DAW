import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ForoService } from '../foro.service';
import { HeaderComponent } from "../../header/header.component";
import { FooterComponent } from "../../footer/footer.component";
import { CommonModule } from '@angular/common';
import { ServizoLoginService } from '../../services/servizo-login.service';

@Component({
  selector: 'app-foro-detalle',
  templateUrl: './foro-detalle.component.html',
  standalone: true,
  imports: [HeaderComponent, FooterComponent, CommonModule, RouterModule],
})
export class ForoDetalleComponent implements OnInit {
  foro: any = null;
  publicaciones: any[] = [];
  loading = true;
  isAdmin = false;
  currentUser: any = null;
  constructor(
    private route: ActivatedRoute,
    private foroService: ForoService,
    private servicioLogin: ServizoLoginService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.servicioLogin.user$.subscribe(user => {
      this.isAdmin = user?.rol === 'admin';
      this.currentUser = user; 
    });
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.foroService.obtenerForoConPublicaciones(+id).subscribe({
        next: (res: any) => {
          this.foro = res.data.foro || res.foro || res;
          this.publicaciones = (res.data?.publicaciones?.data) || [];
          this.loading = false;
        },
        error: () => {
          console.error('Error cargando foro');
          this.loading = false;
        }
      });
    }
  }

  editarPublicacion(id: number) {
    this.router.navigate(['/publicaciones/editar', id]);
  }

  eliminarPublicacion(id: number) {
    if (!confirm('¿Seguro que deseas eliminar esta publicación?')) return;

    this.foroService.eliminarPublicacion(id).subscribe({
      next: () => {
        this.publicaciones = this.publicaciones.filter(pub => pub.id !== id);
      },
      error: () => {
        console.error('Error al eliminar publicación');
      }
    });
}

}
