import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from "@angular/router";
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from "@angular/forms";
import { ForoService } from "../foro.service";
import { MediaSearchService, Media } from "../../search/mediaSearch.service";
import { CommonModule } from "@angular/common";
import { FooterComponent } from "../../footer/footer.component";
import { HeaderComponent } from "../../header/header.component";

@Component({
  selector: "app-editar-foro",
  templateUrl: "./editar-foro.component.html",
  styleUrls: ["./editar-foro.component.css"],
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, FooterComponent, HeaderComponent],
})
export class EditarForoComponent implements OnInit {
  foroForm: FormGroup;
  medias: Media[] = [];
  errores: any = null;
  submitting = false;
  errorMessage = "";

  foroId!: number;

  constructor(
    private fb: FormBuilder,
    private foroService: ForoService,
    private mediaService: MediaSearchService,
    private route: ActivatedRoute,
    public router: Router
  ) {
    this.foroForm = this.fb.group({
      titulo: ["", [Validators.required, Validators.maxLength(255)]],
      pelicula_asociada: [""],
    });
  }

  ngOnInit(): void {
    this.foroId = Number(this.route.snapshot.paramMap.get("id"));

    // Cargar medias para el select
    this.mediaService.getAllMediaArray().subscribe({
      next: (medias) => (this.medias = medias),
      error: (err) => console.error("Error cargando medias", err),
    });

    // Cargar foro para editar
    this.foroService.obtenerForoConPublicaciones(this.foroId).subscribe({
      next: (res) => {
        const foro = res.data;
        this.foroForm.patchValue({
          titulo: foro.titulo,
          pelicula_asociada: foro.pelicula_asociada ?? "",
        });
      },
      error: (err) => {
        this.errorMessage = "Error cargando el foro para editar.";
      },
    });
  }

  submit() {
    if (this.foroForm.invalid) {
      this.foroForm.markAllAsTouched();
      return;
    }

    this.submitting = true;
    this.errores = null;
    this.errorMessage = "";

    this.foroService.editarForo(this.foroId, this.foroForm.value).subscribe({
      next: (res) => {
        // Redirigir a la lista de foros
        this.router.navigate(["/foros"]);
      },
      error: (err) => {
        this.submitting = false;
        if (err.status === 422) {
          this.errores = err.error.errors;
        } else {
          this.errorMessage = "Error actualizando el foro.";
        }
      },
    });
  }
}
