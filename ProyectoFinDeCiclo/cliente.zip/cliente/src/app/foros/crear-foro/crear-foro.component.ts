import { CommonModule } from "@angular/common";
import { Component, OnInit } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { ForoService } from "../foro.service";
import { Media, MediaSearchService } from "../../search/mediaSearch.service";
import { HeaderComponent } from "../../header/header.component";
import { FooterComponent } from "../../footer/footer.component";
import { Router, RouterModule } from "@angular/router";
@Component({
  selector: "app-create-foro",
  templateUrl: "./crear-foro.component.html",
  styleUrls: ["./crear-foro.component.css"],
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule,
    HeaderComponent,
    FooterComponent,
    RouterModule,
  ],
})
export class CreateForoComponent implements OnInit {
  foroForm: FormGroup;
  medias: Media[] = [];
  submitting = false;
  errorMessage = "";
  errores: any = null;

  constructor(
    private fb: FormBuilder,
    private foroService: ForoService,
    private mediaService: MediaSearchService,
    private router: Router

  ) {
    this.foroForm = this.fb.group({
      titulo: ["", [Validators.required, Validators.maxLength(255)]],
      pelicula_asociada: [""],
    });
  }

  ngOnInit(): void {
    this.mediaService.getAllMediaArray().subscribe({
      next: (medias) => (this.medias = medias),
      error: (err) => console.error("Error cargando medias", err),
    });
  }

  submit() {
    if (this.foroForm.invalid) {
      this.foroForm.markAllAsTouched();
      return;
    }

    this.submitting = true;
    this.errorMessage = "";
    this.errores = null;

    this.foroService.crearForo(this.foroForm.value).subscribe({
      next: (res) => {
        this.submitting = false;
        this.router.navigate(['foros']); 
      },
      error: (err) => {
        if (err.status === 422) {
          // Errores de validación desde Laravel
          this.errores = err.error.errors;
        } else {
          this.errorMessage = "Error creando el foro.";
        }
        this.submitting = false;
      },
    });
  }
}
