import { Component, OnInit, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { PLATFORM_ID } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-log-in',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css'],
})
export class LogInComponent implements OnInit {
  private platformId = inject(PLATFORM_ID);

  ngOnInit(): void {
      this.redirectToLaravelLogin();
  }

  redirectToLaravelLogin() {
    if (isPlatformBrowser(this.platformId)) {
      // Redirige a la página de inicio de sesión de Laravel
    window.location.href = 'http://localhost:8000/login';
    }
  }
}
