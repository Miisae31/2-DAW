import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';

export interface Media {
  id: number;
  titulo: string;
  anio_creacion: number;
  sinopsis: string;
  genero: string;
  puntuacion?: number;
  trailer?: string;
  portada?: string;
  tipo: 'pelicula' | 'serie';
  director?: string;
  guion?: string;
  pais?: string;
  duracion?: number;
  n_episodios?: number;
  temporadas?: number;
}

@Injectable({
  providedIn: 'root'
})
export class MediaSearchService {
  private apiUrl = 'http://localhost:8000/api'; 

  constructor(private http: HttpClient) {}

  searchMedia(text: string): Observable<Media[]> {
    return this.http.get<Media[]>(`${this.apiUrl}/medias`, {
      params: {
        texto: text
      }
    });
  }
getMediaByTitle(titulo: string): Observable<Media | undefined> {
  return this.http.get<Media[]>(`${this.apiUrl}/medias`, {
    params: {
      texto: titulo
    }
  }).pipe(
    map((medias: any[]) => medias.find((media: { titulo: string; }) => media.titulo.toLowerCase() === titulo.toLowerCase()))
  );
}

  getAllMedia(): Observable<Media[]> {
    return this.http.get<Media[]>(`${this.apiUrl}/medias`);
  }

  getAllMediaArray(): Observable<Media[]> {
    return this.http.get<{ data: Media[] }>(`${this.apiUrl}/medias`)
      .pipe(
        map(response => response.data) // Extraemos solo el array para evitar problemas
      );
  }
}