import { Component, OnInit } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Peliculaclase } from "../models/peliculaclase";
import { Serieclase } from "../models/serieclase";
import { MediaSearchService } from "./mediaSearch.service";
import { ThumbnailsService } from "../services/thumbnails.service";
import { HttpClientModule } from "@angular/common/http"; 
import { RouterModule } from "@angular/router";

@Component({
  selector: "app-search",
  standalone: true,
  imports: [CommonModule, HttpClientModule, RouterModule],
  templateUrl: "./search.component.html",
  styleUrl: "./search.component.css",
})
export class SearchComponent implements OnInit {
  // Propiedades
  peliculas: Peliculaclase[] = []; // Array de objetos de tipo Peliculaclase
  series: Serieclase[] = []; // Array de objetos de tipo Serieclase
  sugerencias: (Peliculaclase | Serieclase)[] = [];
  consulta: string = ""; // Consulta del usuario

  constructor(
    private mediaSearchService: MediaSearchService, // Inyección de MediaService para datos de API
    private servizo: ThumbnailsService // Inyección de ThumbnailsService para cambiarTitulo
  ) {} // Inyección de dependencias

  ngOnInit(): void {
    this.cargarDatos(); // Cargar los datos a través del servicio
  }

  getId(sugerencia: Peliculaclase | Serieclase): number {
    if (sugerencia.tipo === 'pelicula') {
      return (sugerencia as Peliculaclase).idPelicula;
    } else if (sugerencia.tipo === 'serie') {
      return (sugerencia as Serieclase).idSerie;
    }
    return 0; 
  }
  
  // Método para cargar datos desde la API
  cargarDatos(): void {
    this.mediaSearchService.getAllMedia().subscribe({
      next: (response: any) => {
        const mediaArray = response.data;

        // Filtrar y mapear películas
        this.peliculas = mediaArray
          .filter((item: any) => {
            const tipoValido = item.tipo === "pelicula";
            return tipoValido;
          })
          .map((peliculaData: any) => {
            return new Peliculaclase(
              peliculaData.id,
              peliculaData.titulo,
              peliculaData.anio_creacion,
              peliculaData.sinopsis,
              peliculaData.genero,
              peliculaData.puntuacion ?? 0,
              peliculaData.trailer || "",
              peliculaData.portada || ""
            );
          });

        // Filtrar y mapear series
        this.series = mediaArray
          .filter((item: any) => {
            const tipoValido = item.tipo === "serie";
            return tipoValido;
          })
          .map((serieData: any) => {
            return new Serieclase(
              serieData.id,
              serieData.titulo,
              serieData.anio_creacion,
              serieData.sinopsis,
              serieData.genero,
              serieData.puntuacion ?? 0,
              serieData.trailer || "",
              serieData.portada || ""
            );
          });
      },
      error: (err: any) => {
        console.error("🚫 Error al obtener datos:", err);
      },
    });
  }

  // Método para filtrar sugerencias
  public filtrarSugerencias(consulta: string): (Peliculaclase | Serieclase)[] {
    const palabras = consulta.toLowerCase().split(" "); // Convertir la consulta a minúsculas y dividirla en palabras

    const peliculasFiltradas = this.peliculas.filter((pelicula) =>
      palabras.every((palabra: string) =>
        this.datosPeliculas(pelicula).toLowerCase().includes(palabra)
      )
    );

    const seriesFiltradas = this.series.filter((serie) =>
      palabras.every((palabra: string) =>
        this.datosSeries(serie).toLowerCase().includes(palabra)
      )
    );

    return [...peliculasFiltradas, ...seriesFiltradas]; // Devuelve un array con películas y series que coinciden
  }

  // Método para obtener los datos de una película
  public datosPeliculas(pelicula: Peliculaclase): string {
    return pelicula._titulo + " (" + pelicula._ano + ")";
  }

  // Método para obtener los datos de una serie
  public datosSeries(serie: Serieclase): string {
    return serie._titulo + " (" + serie._ano + ")";
  }

  // Método para obtener los datos de una sugerencia
  public datosSugerencia(sugerencia: Peliculaclase | Serieclase): string {
    if (sugerencia.tipo === "pelicula") {
      return this.datosPeliculas(sugerencia as Peliculaclase);
    } else if (sugerencia.tipo === "serie") {
      return this.datosSeries(sugerencia as Serieclase);
    }
    return ""; 
  }

  // Método para actualizar la lista de sugerencias
  public actualizarListaxe(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.consulta = target.value.trim();
    if (!this.consulta) {
      this.sugerencias = [];
    } else {
      this.sugerencias = this.filtrarSugerencias(this.consulta);
    }
  }

  cambiarTitulo(idPelicula: number): void {
    this.servizo.cambiarId(idPelicula.toString());
    localStorage.setItem("mediaId", idPelicula.toString());
  }
  
  
}
