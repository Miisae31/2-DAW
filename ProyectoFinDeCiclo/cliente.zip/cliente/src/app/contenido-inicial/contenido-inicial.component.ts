import { Component } from '@angular/core';
import { ThumbnailsService } from '../services/thumbnails.service';
import { RouterModule } from '@angular/router';
import { Media, MediaSearchService } from '../search/mediaSearch.service';

@Component({
  selector: 'app-contenido-inicial',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './contenido-inicial.component.html',
  styleUrl: './contenido-inicial.component.css'
})
export class ContenidoInicialComponent {
  tituloActual: string = ''; 
  constructor(
    private servizo: ThumbnailsService,
    private mediaSearchService: MediaSearchService
  ) {}

  ngOnInit(): void {
    this.servizo.subcribirse$().subscribe((id: string) => {
      this.tituloActual = id; 
    });
  }

  cambiarTitulo(titulo: string): void {
    this.mediaSearchService.getMediaByTitle(titulo).subscribe((media: Media | undefined) => {
      if (media) {
        const idStr = media.id.toString();
        this.servizo.cambiarTitulo(idStr);
        localStorage.setItem('mediaId', idStr);
      } else {
        console.error('No se encontró media con ese título:', titulo);
      }
    });
  }
}
