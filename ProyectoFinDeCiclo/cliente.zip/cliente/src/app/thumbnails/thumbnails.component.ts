import { Component } from '@angular/core';
import { ThumbnailsService } from '../services/thumbnails.service';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MediaSearchService } from '../search/mediaSearch.service';

@Component({
  selector: 'app-thumbnails',
  standalone: true,
  imports: [CommonModule, RouterModule], 
  templateUrl: './thumbnails.component.html',
  styleUrl: './thumbnails.component.css'
})
export class ThumbnailsComponent {

  idActual: string = ''; // Variable para mostrar el id actual

  constructor(
    private servizo: ThumbnailsService,
    private mediaSearchService: MediaSearchService
  ) { }
  ngOnInit(): void {
    this.servizo.subcribirse$().subscribe((id: string) => {
      this.idActual = id; // Actualizar el id actual
    });
  }

  cambiarTitulo(titulo: string): void {
    this.mediaSearchService.getMediaByTitle(titulo).subscribe((media: { id: { toString: () => any; }; }) => {
      if(media) {
        const idStr = media.id.toString();
        this.servizo.cambiarId(idStr);
        localStorage.setItem('mediaId', idStr);
      } else {
        console.error('No se encontró media con ese título:', titulo);
      }
    });
  }

  cambiarId(idPelicula: number): void {
    const idStr = idPelicula.toString();
    this.servizo.cambiarId(idStr); // Enviar el id al servicio
    localStorage.setItem('mediaId', idStr); // Almacenar el id en localStorage
  }
}
