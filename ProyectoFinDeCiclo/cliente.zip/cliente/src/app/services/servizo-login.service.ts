import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { BehaviorSubject, Observable, switchMap, tap } from "rxjs";

@Injectable({
  providedIn: "root",
})
export class ServizoLoginService {
  private baseUrl = "http://localhost:8000";
  private userSubject = new BehaviorSubject<any>(null);
  user$ = this.userSubject.asObservable();

  constructor(private http: HttpClient) {
    this.checkAuth(); // Al cargar, comprobamos si ya está logueado
  }

  getUser(): Observable<any> {
    return this.http
      .get(`${this.baseUrl}/api/user`, { withCredentials: true })
      .pipe(
        tap((user) => {
          this.userSubject.next(user);
        })
      );
  }

  checkAuth(): void {
    this.getUser().subscribe({
      next: (user) => this.userSubject.next(user),
      error: () => this.userSubject.next(null),
    });
  }

  logout(): Observable<any> {
    const xsrfToken = this.getCookie('XSRF-TOKEN');
  
    return this.http
      .get(`${this.baseUrl}/sanctum/csrf-cookie`, { withCredentials: true })
      .pipe(
        switchMap(() =>
          this.http.post(
            `${this.baseUrl}/api/logout`,
            {},
            {
              withCredentials: true,
              headers: {
                'X-XSRF-TOKEN': decodeURIComponent(xsrfToken),
              },
            }
          )
        ),
        tap(() => this.userSubject.next(null))
      );
  }
  
  private getCookie(name: string): string {
    const cookies = document.cookie.split('; ');
    const cookie = cookies.find(c => c.startsWith(name + '='));
    return cookie ? cookie.split('=')[1] : '';
  }
  
  

  isLoggedIn(): boolean {
    return this.userSubject.value !== null;
  }

  getCurrentUser(): any {
    return this.userSubject.value;
  }
}
