import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ThumbnailsService { // Servicio para cambiar el título de la página

  // Creamos un BehaviorSubject para el título
  private idSeleccionado$ = new BehaviorSubject<string>('');

  constructor() { }

  // Método para cambiar el título
  cambiarId(id: string): void {
    this.idSeleccionado$.next(id);
  }
  
  subcribirse$(): Observable<string> {
    return this.idSeleccionado$.asObservable();
  }

  cambiarTitulo(id: string): void {
    this.idSeleccionado$.next(id);
  }
}