import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { ServizoLoginService } from '../services/servizo-login.service';
import { Observable, map } from 'rxjs';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-menu-desplegable',
  templateUrl: './menu-desplegable.component.html',
  styleUrls: ['./menu-desplegable.component.css'],
  imports: [CommonModule, RouterModule],
  standalone: true
})
export class MenuDesplegableComponent implements OnInit {
  isMenuVisible = false;

  user$!: Observable<any>;
  isLogged$!: Observable<boolean>;
  isAdmin$!: Observable<boolean>;
  
  constructor(private servicio: ServizoLoginService, private router: Router) {
    this.user$ = this.servicio.user$;
    this.isLogged$ = this.user$.pipe(map(user => user !== null));
    this.isAdmin$ = this.user$.pipe(map(user => user?.rol === 'admin'));
  }

  ngOnInit(): void {
    this.servicio.checkAuth(); 
  }

  toggleMenu() {
    this.isMenuVisible = !this.isMenuVisible;
  }

  closeMenu() {
    this.isMenuVisible = false;
  }

  logout() {
    this.servicio.logout().subscribe(() => {
      this.router.navigate(['/inicio']);  // redirige a inicio tras logout
    });
  }
}
