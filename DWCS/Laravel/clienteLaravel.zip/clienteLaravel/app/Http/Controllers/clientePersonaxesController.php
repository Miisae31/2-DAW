<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
class clientePersonaxesController extends Controller
{
    public function index() {
        $apiUrl = 'http://localhost:8001/api/personaxes';
        $personaxes = json_decode(Http::withToken('Abcdefg12345678')->get($apiUrl));
        return view('personaxes.index', ['personaxes' => $personaxes] );
    }
}
