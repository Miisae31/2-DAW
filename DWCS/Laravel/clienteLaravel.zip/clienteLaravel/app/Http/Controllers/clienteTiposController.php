<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class clienteTiposController extends Controller
{
    public function index() {
        $apiUrl = 'http://localhost:8001/tipos';
        $tipos = json_decode(Http::get($apiUrl));

        return view('tipos.index', compact('tipos'));
    }
}
