<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Personaxes</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #4CAF50; color: white; }
        img { width: 50px; height: auto; }
    </style>
</head>
<body>
    <h1>Lista de Personaxes</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>Imagen</th>
                <th>Tipo</th>
                <th>Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $personaxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personaxe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($personaxe->id); ?></td>
                    <td><?php echo e($personaxe->nome); ?></td>
                    <td><img src="http://localhost:8001/<?php echo e($personaxe->imaxe); ?>" alt="<?php echo e($personaxe->nome); ?>"></td>
                    <td><?php echo e($personaxe->tipo); ?></td>
                    <td><?php echo e($personaxe->descricion); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH /var/www/html/lara/clienteLaravel/resources/views/personaxes/index.blade.php ENDPATH**/ ?>