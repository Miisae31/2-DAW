<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        if (!User::where('email', 'api@cifprodolfoucha.es')->exists()) {
            User::create([
                'name' => 'api',
                'email' => 'api@cifprodolfoucha.es',
                'password' => Hash::make('abc1234..'), // Cambia la contraseña a una más segura en producción
                'api_token' => 'Abcdefg12345678', // Asigna el valor fijo al api_token
            ]);
        }
    }
}
