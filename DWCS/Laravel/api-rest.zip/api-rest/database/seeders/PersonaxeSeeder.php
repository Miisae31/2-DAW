<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class PersonaxeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $series = [
            ['nome' => 'Bleach', 'tipo' => 'Anime', 'descricion' => 'Serie sobre shinigamis y batallas espirituales.', 'imaxe' => 'imagenes/Bleach.png'],
            ['nome' => 'Captain Tsubasa', 'tipo' => 'Anime', 'descricion' => 'Historia de un joven futbolista con grandes sueños.', 'imaxe' => 'imagenes/CapitanTsubasa.jpeg'],
            ['nome' => 'Doraemon', 'tipo' => 'Anime', 'descricion' => 'Un gato cósmico ayuda a un niño en su vida cotidiana.', 'imaxe' => 'imagenes/Doraemon.png'],
            ['nome' => 'Dragon Ball', 'tipo' => 'Anime', 'descricion' => 'Historia de Goku y su búsqueda de las esferas del dragón.', 'imaxe' => 'imagenes/DragonBall.png'],
            ['nome' => 'Hunter x Hunter', 'tipo' => 'Anime', 'descricion' => 'Un joven busca a su padre convirtiéndose en cazador.', 'imaxe' => 'imagenes/HunterxHunter.png'],
            ['nome' => 'Naruto', 'tipo' => 'Anime', 'descricion' => 'Un ninja con un sueño de convertirse en Hokage.', 'imaxe' => 'imagenes/Naruto1.jpg'],
            ['nome' => 'One Piece', 'tipo' => 'Anime', 'descricion' => 'Un pirata busca el legendario One Piece.', 'imaxe' => 'imagenes/OnePiece.png'],
            ['nome' => 'Pokemon', 'tipo' => 'Anime', 'descricion' => 'Entrenadores capturan criaturas para competir en batallas.', 'imaxe' => 'imagenes/Pokemon.png'],
        ];

        DB::table('personaxes')->insert($series);
    }
}
