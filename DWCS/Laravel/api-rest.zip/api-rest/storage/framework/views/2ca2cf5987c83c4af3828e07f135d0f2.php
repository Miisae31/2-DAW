<?php if(isset($data) && is_array($data) && count($data) > 0): ?>
    <ul>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <strong>Título:</strong> <a href="<?php echo e($movie['url']); ?>" target="_blank"><?php echo e($movie['primaryTitle']); ?></a> <br>
                <strong>Descripción:</strong> <?php echo e($movie['description']); ?> <br>
                <strong>Año de lanzamiento:</strong> <?php echo e($movie['releaseDate']); ?> <br>
                <strong>Duración:</strong> <?php echo e($movie['runtimeMinutes']); ?> minutos <br>
                <strong>Rating promedio:</strong> <?php echo e($movie['averageRating']); ?> <br>

                <img src="<?php echo e($movie['primaryImage']); ?>" alt="Imagen de la película" width="200" />
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php else: ?>
    <p>No se han encontrado películas para mostrar.</p>
<?php endif; ?>
<?php /**PATH /var/www/html/lara/api-rest/resources/views/vista-externa.blade.php ENDPATH**/ ?>