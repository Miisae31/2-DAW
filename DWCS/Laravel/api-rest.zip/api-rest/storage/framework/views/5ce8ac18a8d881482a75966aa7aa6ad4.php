<h1>Pokemons</h1>
<ul>
    <?php if($pokemons !== null): ?>
        <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($pokemon->nome); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    Non se atoparon Pokémons.
    <?php endif; ?>
</ul>
<?php /**PATH /var/www/html/lara/clienteLaravel/resources/views/pokemons.blade.php ENDPATH**/ ?>