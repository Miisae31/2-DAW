<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class ApiTokenMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Obtener el token de las cabeceras de la solicitud
        $token = $request->header('Authorization');
        // Extraer el token sin el prefijo "Bearer"
        // NEste metodo non seria necesario indicar Bearer
        $token = substr($token, 7);

        if (!$token) {
            return response()->json(['error' => 'Token no proporcionado'], 401);
        }

        // Buscar el usuario por el token en la tabla users
        $user = User::where('api_token', $token)->first();

        if (!$user) {
            return response()->json(['error' => 'Token no válido'], 401);
        }

        // Autenticar al usuario con ese token
        Auth::login($user);

        return $next($request);
    }
}
