<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class Mensaxe extends Model
{
    use HasFactory;

     public function users() {
        return $this->belongsTo(User::class, 'receptor_id');
    }

    public function emisor() {
        return $this->belongsTo(User::class, 'emisor_id');
    }
    
}
