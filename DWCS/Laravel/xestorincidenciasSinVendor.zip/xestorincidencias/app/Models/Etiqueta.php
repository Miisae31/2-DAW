<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Incidencia;
class Etiqueta extends Model
{
    use HasFactory;

    public function incidencias() {
        return $this->belongsToMany(Incidencia::class, 'incidencias_etiquetas');
    }
}
