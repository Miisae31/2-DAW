<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Etiqueta;

class EtiquetaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        /* Definir modelo Etiqueta */
        $etiquetas = Etiqueta::all();
        return view('etiquetas.index', ['etiquetas' => $etiquetas]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('etiquetas.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nombreEtiqueta' => 'required|unique:etiquetas|max:50',
        ]);

        $etiqueta = new Etiqueta();
        $etiqueta->nombreEtiqueta = $request->input('nombreEtiqueta');
        $etiqueta->save();

        return redirect()->to('/etiquetas')->with('success', 'A etiqueta foi creada correctamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $etiqueta = Etiqueta::find($id);
        return view('etiquetas.update')->with('etiqueta',$etiqueta);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'nombreEtiqueta' => 'required|unique:etiquetas|max:50'
        ]);
        $etiqueta = Etiqueta::find($id);
        $etiqueta->nombreEtiqueta = $request->input('nombreEtiqueta');
        $etiqueta->save();
        
        return redirect()->to('/etiquetas')->with('success', 'A etiqueta foi actualizada correctamente.');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $etiqueta = Etiqueta::findOrFail($id);
        $etiqueta->delete();
        $etiqueta->incidencias()->detach(); 

        return redirect()->to('/etiquetas')->with('success', 'A etiqueta foi eliminada correctamente.');

    }
}
