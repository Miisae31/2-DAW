<?php

namespace App\Http\Controllers;

use App\Models\Etiqueta;
use Illuminate\Http\Request;
use App\Models\Incidencia;
use Illuminate\Validation\Rules\Enum;


class IncidenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        /* Definir modelo Incidencia */
        $incidencias = Incidencia::all();

        return view('incidencias.index', ['incidencias' => $incidencias]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $etiquetas = Etiqueta::all();
        return view('incidencias.create', ['etiquetas' => $etiquetas]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'titulo' => 'required|string|max:100',
            'detalle' => 'required|string|max:255',
            'comentario' => 'required|string|max:255',
            'estado' => 'required|in:Pendente,Traballando,Pechada',
            'fechaInicio' => 'required|date',
            'fechaFin' => 'required|date',
            'users_id' => 'required|integer|exists:App\Models\User,id',

        ]);

        $incidencia = new Incidencia();
        $incidencia->titulo = $request->input('titulo');
        $incidencia->detalle = $request->input('detalle');
        $incidencia->comentario = $request->input('comentario');
        $incidencia->estado = $request->input('estado');
        $incidencia->fechaInicio = $request->input('fechaInicio');
        $incidencia->fechaFin = $request->input('fechaFin');
        $incidencia->users_id = $request->input('users_id');
        $incidencia->save();

        $incidencia->etiquetas()->attach($request->input('etiquetas'));
       


        return redirect()->to('/incidencias')->with('success', 'A incidencia foi creada correctamente.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $etiquetas = Etiqueta::all();
        $incidencia = Incidencia::find($id);
        return view('incidencias.update')->with('incidencia', $incidencia)->with(['etiquetas' => $etiquetas]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {

        $request->validate([
            'titulo' => 'required|string|max:100',
            'detalle' => 'required|string|max:255',
            'comentario' => 'required|string|max:255',
            'estado' => 'required|in:Pendente,Traballando,Pechada',
            'fechaInicio' => 'required|date',
            'fechaFin' => 'required|date',
            'users_id' => 'required|integer',
            
        ]);

        $incidencia = Incidencia::findOrFail($id);
        $incidencia->titulo = $request->input('titulo');
        $incidencia->detalle = $request->input('detalle');
        $incidencia->comentario = $request->input('comentario');
        $incidencia->estado = $request->input('estado');
        $incidencia->fechaInicio = $request->input('fechaInicio');
        $incidencia->fechaFin = $request->input('fechaFin');
        $incidencia->users_id = $request->input('users_id');
        $incidencia->save();


        // Sincronizar etiquetas (elimina las antiguas y añade las nuevas)
        $incidencia->etiquetas()->sync($request->input('etiquetas', []));

       // dd($incidencia->etiquetas()->pluck('id')->toArray());

        return redirect()->to('/incidencias')->with('success', 'A incidencia foi actualizada correctamente.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
{
    $incidencia = Incidencia::findOrFail($id);
    $incidencia->etiquetas()->detach(); 
    $incidencia->delete();
    return redirect()->to('/incidencias')->with('success', 'A incidencia foi eliminada correctamente.');
}
}
