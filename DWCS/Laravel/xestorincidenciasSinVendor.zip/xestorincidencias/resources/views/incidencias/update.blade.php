@extends('layouts.personalizada')
@section('corpo')
<form action="/incidencia/{{ $incidencia->id }}" method="POST">
    @csrf
    @method('PUT')
    <div class="field">
        <label class="label" for="titulo">Título</label>
        <div class="control">
            <input class="input" type="text" name="titulo" id="tituloIncidencia" value="{{ old('titulo', $incidencia->titulo) }}" required>
        </div>
        @error('titulo')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="detalle">Detalles</label>
        <div class="control">
            <textarea class="textarea" name="detalle" id="detalle" rows="4" required>{{ old('detalle', $incidencia->detalle) }}</textarea>
        </div>
        @error('detalle')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="fechaInicio">Fecha de Inicio</label>
        <div class="control">
            <input class="input" type="date" name="fechaInicio" id="fecha_inicio" value="{{ old('fechaInicio', $incidencia->fechaInicio) }}" required>
        </div>
        @error('fechaInicio')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="fechaFin">Fecha de Fin</label>
        <div class="control">
            <input class="input" type="date" name="fechaFin" id="fechaFin" value="{{ old('fechaFin', $incidencia->fechaFin) }}" required>
        </div>
        @error('fechaFin')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="estado">Estado</label>
        <div class="control">
            <div class="select">
                <select name="estado" id="estado" required>
                    <option value="Pendente" {{ $incidencia->estado == 'Pendente' ? 'selected' : '' }}>Pendente</option>
                    <option value="Traballando" {{ $incidencia->estado == 'Traballando' ? 'selected' : '' }}>Traballando</option>
                    <option value="Pechada" {{ $incidencia->estado == 'Pechada' ? 'selected' : '' }}>Pechada</option>
                </select>
            </div>
        </div>
        @error('estado')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="etiqueta">Etiqueta</label>
        <div class="control select is-link  is-normal is-multiple">
            <select class="" name="etiquetas[]" id="etiqueta" multiple>
                @foreach ($etiquetas as $etiqueta)
                    <option value="{{ $etiqueta->id}}" 
                    @if (in_array($etiqueta->id, $incidencia->etiquetas()->pluck('id')->toArray()))
                    selected
                    @else 
                    no
                    @endif
                    >{{ $etiqueta->nombreEtiqueta}}</option>
                @endforeach
            </select>
        </div>
        @error('etiquetas')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="comentario">Comentario</label>
        <div class="control">
            <textarea class="textarea" name="comentario" id="comentario" rows="4">{{ old('comentario', $incidencia->comentario) }}</textarea>
        </div>
        @error('comentarios')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
        <label class="label" for="users_id">Id del Usuario</label>
        <input type="text" name="users_id" value="{{ $incidencia->users_id }}">
    </div>
    <div class="control">
        <button class="button is-primary" type="submit">Actualizar Incidencia</button>
    </div>
</form>
@endsection