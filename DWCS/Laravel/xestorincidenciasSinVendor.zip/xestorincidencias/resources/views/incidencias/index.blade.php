@extends('layouts.personalizada')
@section('corpo')
<h1 class="tituloCrud">Incidencias</h1><br>
<div style="display: flex;   justify-content: flex-end; ">
    <button><a class="crear button is-primary" href="/incidencia">Nova Incidencia</a></button>
</div>
@if (session('success'))
    <div class="">
        {{ session('success') }}
    </div>
@endif
<table class="table is-bordered">
    <thead>
        <tr class="">
            <th class="">ID</th>
            <th class="">Titulo</th>
            <th class="">Detalle</th>
            <th class="">Fecha de Inicio</th>
            <th class="">Fecha de Fin</th>
            <th class="">Estado</th>
            <th class="">Comentarios</th>
            <th class="">Usuario</th>
        </tr>
    </thead>
    @foreach ($incidencias as $incidencia)
        <tbody>
            <tr class="border-b border-gray-300">
                <td class="">{{ $incidencia->id }}</td>
                <td class="">{{ $incidencia->titulo }}</td>
                <td class="">{{ $incidencia->detalle }}</td>
                <td class="">{{ $incidencia->fechaInicio }}</td>
                <td class="">{{ $incidencia->fechaFin }}</td>
                <td class="">{{ $incidencia->estado }}</td>
                <td class="">{{ $incidencia->comentario }}</td>
                <td class="">{{ $incidencia->users_id }}</td>
                <td class="">
                    <button id="editar" class="button is-link"><a href="/incidencia/{{ $incidencia->id }}">Editar</a></button>
                </td>
                <td>
                    <form action="/incidenciaborrar/{{ $incidencia->id }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button id="eliminar" class="button is-danger" type="submit">Eliminar</button>
                    </form>
                </td> 
            </tr>
        </tbody>
    @endforeach
    <table>
    </div>
@endsection