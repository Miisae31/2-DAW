@extends('layouts.personalizada')
@section('corpo')
<form action="/incidencia" method="POST">
    @csrf
    <div class="field">
        <label class="label" for="titulo">Título</label>
        <div class="control">
            <input class="input" type="text" name="titulo" id="tituloIncidencia" value="{{ old('titulo') }}" required>
        </div>
        @error('titulo')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="detalle">Detalles</label>
        <div class="control">
            <textarea class="textarea" name="detalle" id="detalle" rows="4" required>{{ old('detalle') }}</textarea>
        </div>
        @error('detalle')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="fechaInicio">Fecha de Inicio</label>
        <div class="control">
            <input class="input" type="date" name="fechaInicio" id="fecha_inicio" value="{{ old('fechaInicio') }}" required>
        </div>
        @error('fechaInicio')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="fechaFin">Fecha de Fin</label>
        <div class="control">
            <input class="input" type="date" name="fechaFin" id="fechaFin" value="{{ old('fechaFin') }}" required>
        </div>
        @error('fechaFin')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="estado">Estado</label>
        <div class="control">
            <div class="select">
                <select name="estado" id="estado" required>
                    <option value="Pendente" {{ old('estado') == 'Pendente' ? 'selected' : '' }}>Pendente</option>
                    <option value="Traballando" {{ old('estado') == 'Traballando' ? 'selected' : '' }}>Traballando</option>
                    <option value="Pechada" {{ old('estado') == 'Pechada' ? 'selected' : '' }}>Pechada</option>
                </select>
            </div>
        </div>
        @error('estado')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="etiqueta">Etiqueta</label>
        <div class="control select is-link  is-normal is-multiple">
            <select class="" name="etiquetas[]" id="etiqueta" multiple>
                @foreach ($etiquetas as $etiqueta)
                    <option value="{{ $etiqueta->id}}">{{ $etiqueta->nombreEtiqueta}}</option>
                @endforeach
            </select>
        </div>
        @error('etiquetas')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="comentario">Comentario</label>
        <div class="control">
            <textarea class="textarea" name="comentario" id="comentario" rows="4">{{ old('comentario') }}</textarea>
        </div>
        @error('comentario')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="users_id">Id del Usuario</label>
        <div class="control">
            <input class="input" type="text" name="users_id" value="{{ old('users_id') }}" required>
        </div>
        @error('users_id')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="control">
        <button class="button is-primary" type="submit">Crear Incidencia</button>
    </div>
</form>
@endsection