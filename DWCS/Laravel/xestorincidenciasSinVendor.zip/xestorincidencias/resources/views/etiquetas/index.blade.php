@extends('layouts.personalizada')
@section('corpo')
<h1 class="tituloCrud">Etiquetas</h1><br>
<div style="display: flex; justify-content: flex-end;">
    <button><a class="crear button is-primary" href="/etiqueta">Nova etiqueta</a></button>
</div>

@if (session('success'))
    <div class="notification is-success">
        {{ session('success') }}
    </div>
@endif

<!-- Añadimos la clase "has-background-white" para que el fondo sea blanco -->
<div class="fixed-grid has-3-cols has-background-white">
    <div class="grid">
        <!-- Cabecera de la cuadrícula -->
        <div class="cell has-text-weight-bold has-background-light">ID</div>
        <div class="cell has-text-weight-bold has-background-light">Nome</div>
        <div class="cell has-text-weight-bold has-background-light">Accións</div>

        <!-- Filas de etiquetas -->
        @foreach ($etiquetas as $etiqueta)
            <div class="cell ">{{ $etiqueta->id }}</div>
            <div class="cell ">{{ $etiqueta->nombreEtiqueta }}</div>
            <div class="cell ">
                <div class="buttons">
                    <button id="editar" class="button is-link">
                        <a href="/etiqueta/{{ $etiqueta->id }}">Editar</a>
                    </button>
                    <form action="/eliminaretiqueta/{{ $etiqueta->id }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button class="button is-danger" id="eliminar" type="submit">Eliminar</button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection