@extends('layouts.personalizada')
@section('corpo')
@error('nombreEtiqueta')
	<p class="">{{ $message }}</p>
@enderror
<form action="/etiqueta" method="POST">
      @csrf
       <div class="">
      <label class="label" for="nombreEtiqueta">Nome</label>
        <input type="text" class="input is-medium" id="nombreEtiqueta" name="nombreEtiqueta" value="{{ old('nombreEtiqueta') }}">
        </div><br>                    
       <button type="submit" class="button is-primary">
               Crear
       </button>
</form>
@endsection