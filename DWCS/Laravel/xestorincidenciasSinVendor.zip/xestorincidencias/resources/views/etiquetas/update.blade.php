@extends('layouts.personalizada')
@section('corpo')
    @error('nombreEtiqueta')
        <p class="">{{ $message }}</p>
    @enderror
    <form action="/etiqueta/{{ $etiqueta->id }}" method="POST">
        @csrf
        @method('PUT')
        <div class="">
            <label for="nombreEtiqueta" class="">Nome:</label>
            <input type="text" name="nombreEtiqueta" id="nombreEtiqueta" value="{{ old('nombreEtiqueta', $etiqueta->nombreEtiqueta) }}"
                class="">
        </div>
        <button type="submit" class="">
            Gardar cambios
        </button>
    </form>
@endsection
