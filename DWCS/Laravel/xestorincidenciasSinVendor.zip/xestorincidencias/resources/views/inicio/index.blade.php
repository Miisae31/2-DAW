@extends('layouts.personalizada')
@section('corpo')
<div class="content is-large">
<h2>Hola bienvenido al gestor de incidencias</h2>
<p style="font-size: 30px">Desde aqui podras controlar todas las incidencias juntos con sus etiquetas ademas de poder consultar y mandar mensajes, que lo disfrutes!</p>

</div>
@endsection