@extends('layouts.personalizada')
@section('corpo')
<form class="form-container" action="contacto" method="POST">
    @csrf
    <div class="field">
        <label class="label" for="asunto">Asunto</label>
        <div class="control">
            <input class="input" type="text" name="asunto" value="{{ old('asunto') }}" required>
        </div>
        @error('asunto')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="contenido">Contenido</label>
        <div class="control">
            <textarea class="textarea" name="contenido" id="contenido" rows="4" required>{{ old('contenido') }}</textarea>
        </div>
        @error('contenido')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    </div>
    <div class="field">
        <label class="label" for="receptor_id">Receptor</label>
        <div class="control select is-link is-rounded is-normal">
            <select class="" name="receptor_id" id="receptor_id">
                @foreach ($users as $user)
                    <option value="{{ $user->id}}">{{ $user->email}}</option>
                @endforeach
            </select>
        </div>
            
        @error('receptor_id')
            <p class="help is-danger">{{ $message }}</p>
        @enderror
    <div class="control">
        <br>
        <button class="button is-primary" type="submit">Enviar</button>
    </div>
</form>
@endsection