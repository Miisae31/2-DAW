@extends('layouts.personalizada')
@section('corpo')
<h1 class="tituloCrud">Mensajes</h1><br>
@if (session('success'))
    <div class="">
        {{ session('success') }}
    </div>
@endif
<table class="table">
    <thead>
        <tr class="">
            <th class="">Id</th>
            <th class="">Asunto</th>
            <th class="">Contenido</th>
            <th class="">Fecha de Envio</th>
            <th class="">Fecha de Fin</th>
            <th class="">Receptor</th>
            <th class="">Emisor</th>
        </tr>
    </thead>

        <tbody>
            @foreach ($mensaxes as $mensaxe)
            <tr class="border-b border-gray-300">
                <td class="">{{ $mensaxe->id }}</td>
                <td class="">{{ $mensaxe->asunto }}</td>
                <td class="">{{ $mensaxe->contenido }}</td>
                <td class="">{{ $mensaxe->fecha_envio }}</td>
                <td class="">{{ $mensaxe->users->email }}</td>
                <td class="">{{ $mensaxe->emisor->email }}</td>            
            </tr>
            @endforeach
        </tbody>
    <table>
    </div>
    
@endsection