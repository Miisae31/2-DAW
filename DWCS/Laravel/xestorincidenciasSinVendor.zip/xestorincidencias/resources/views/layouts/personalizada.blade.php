@include ('layouts.cabeceira')
@include ('layouts.menu')

<div class='container'>
    @yield ('corpo')
</div>
@include ('layouts.pe')