<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\IncidenciaController;
use App\Http\Controllers\MensaxeController;
use App\Http\Controllers\EtiquetaController;
use App\Http\Controllers\ContactoController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/welcome', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/inicio', function () {
    return view('inicio.index');
});
Route::get('/', function () {
    return view('inicio.index');
});

Route::middleware('auth')->group(function () {
    Route::get('incidencias', [IncidenciaController::class, 'index']);
    Route::get('incidencia/{id}', [IncidenciaController::class, 'edit']);

    /* Rutas para contacto GET */
    Route::get('contactos', function () {
        return view('contactos');
    });

    Route::get('mensaxes', [MensaxeController::class, 'index']);

    Route::get('contacto', [ContactoController::class, 'create']);
});

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');


    /* Ruta para la vista de la tabla incidencias */


    Route::get('incidencia', [IncidenciaController::class, 'create']);

    Route::post('incidencia', [IncidenciaController::class, 'store']);


    Route::put('incidencia/{id}', [IncidenciaController::class, 'update']);

    Route::delete('/incidenciaborrar/{id}', [IncidenciaController::class, 'destroy']);

    /* Ruta para la vista de la tabla etiquetas */

    Route::get('etiquetas', [EtiquetaController::class, 'index']);

    /* Rutas para etiquetas GET */
    Route::get('/etiqueta', [EtiquetaController::class, 'create']);

    Route::post('/etiqueta', [EtiquetaController::class, 'store']);

    Route::get('/etiqueta/{id}', [EtiquetaController::class, 'edit']);

    Route::put('/etiqueta/{id}', [EtiquetaController::class, 'update']);

    /* Rutas para etiquetas POST */
    Route::delete('/eliminaretiqueta/{id}', [EtiquetaController::class, 'destroy']);



    /* Rutas para contacto POST */

    Route::get('mensaxes/admin', [MensaxeController::class, 'admin']);
});

require __DIR__ . '/auth.php';
