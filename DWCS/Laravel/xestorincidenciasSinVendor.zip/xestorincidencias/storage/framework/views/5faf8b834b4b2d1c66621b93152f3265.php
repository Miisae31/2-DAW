<?php $__env->startSection('corpo'); ?>
<h1 class="tituloCrud">Mensajes</h1><br>
<?php if(session('success')): ?>
    <div class="">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<table class="table">
    <thead>
        <tr class="">
            <th class="">Id</th>
            <th class="">Asunto</th>
            <th class="">Contenido</th>
            <th class="">Fecha de Envio</th>
            <th class="">Fecha de Fin</th>
            <th class="">Receptor</th>
            <th class="">Emisor</th>
        </tr>
    </thead>

        <tbody>
            <?php $__currentLoopData = $mensaxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaxe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b border-gray-300">
                <td class=""><?php echo e($mensaxe->id); ?></td>
                <td class=""><?php echo e($mensaxe->asunto); ?></td>
                <td class=""><?php echo e($mensaxe->contenido); ?></td>
                <td class=""><?php echo e($mensaxe->fecha_envio); ?></td>
                <td class=""><?php echo e($mensaxe->users->email); ?></td>
                <td class=""><?php echo e($mensaxe->emisor->email); ?></td>            
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    <table>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.personalizada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/xestorIncidencias/resources/views/mensaxes/admin.blade.php ENDPATH**/ ?>