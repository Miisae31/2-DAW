<!-- HTML DEL MENU -->
<!-- Menú de navegación -->
<div class='cell' id='lista'>
    <div class='navbar-end' id="menu">
        <div class='navbar-item has-dropdown is-hoverable'>
            <a style="font-weight: bold" class='navbar-link'>Menú</a>
            
            <div class='navbar-dropdown'>
                <?php if(Auth::check()): ?>
                <a class='navbar-item' href="/contacto">Contacto</a>
                <a class='navbar-item' href="/mensaxes">Mensaxes</a>
                <?php if(Auth::user()->rol == 'administrador'): ?>
                <a class='navbar-item ' href="/incidencias">Incidencias</a>
                <a class="navbar-item" href="/etiquetas">Etiquetas</a>
                <a class='navbar-item' href="/mensaxes/admin">Xestionar Mensaxes</a>
                <?php endif; ?>
                <?php endif; ?>

                
            </div>
        </div>
        <?php if(Route::has('login')): ?>
                <div class="sm:fixed sm:top-0 sm:right-0 p-6 text-right z-10">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/dashboard')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Dashboard</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Log in</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
    </div>
</div>
</div>
</div>
<?php /**PATH /var/www/html/laravel/xestorIncidencias/resources/views/layouts/menu.blade.php ENDPATH**/ ?>