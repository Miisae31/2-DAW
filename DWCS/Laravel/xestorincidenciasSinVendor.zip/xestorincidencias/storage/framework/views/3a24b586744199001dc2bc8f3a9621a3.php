<?php $__env->startSection('corpo'); ?>
<div class="content is-large">
<h2>Hola bienvenido al gestor de incidencias</h2>
<p style="font-size: 30px">Desde aqui podras controlar todas las incidencias juntos con sus etiquetas ademas de poder consultar y mandar mensajes, que lo disfrutes!</p>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.personalizada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/xestorIncidencias/resources/views/inicio/index.blade.php ENDPATH**/ ?>