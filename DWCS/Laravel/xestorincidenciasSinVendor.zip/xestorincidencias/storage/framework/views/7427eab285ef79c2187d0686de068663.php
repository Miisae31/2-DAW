<?php echo $__env->make('layouts.cabeceira', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class='container'>
    <?php echo $__env->yieldContent('corpo'); ?>
</div>
<?php echo $__env->make('layouts.pe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/xestorIncidencias/resources/views/layouts/personalizada.blade.php ENDPATH**/ ?>