<?php $__env->startSection('corpo'); ?>
<h1 class="tituloCrud">Etiquetas</h1><br>
<div style="display: flex; justify-content: flex-end;">
    <button><a class="crear button is-primary" href="/etiqueta">Nova etiqueta</a></button>
</div>

<?php if(session('success')): ?>
    <div class="notification is-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<!-- Añadimos la clase "has-background-white" para que el fondo sea blanco -->
<div class="fixed-grid has-3-cols has-background-white">
    <div class="grid">
        <!-- Cabecera de la cuadrícula -->
        <div class="cell has-text-weight-bold has-background-light">ID</div>
        <div class="cell has-text-weight-bold has-background-light">Nome</div>
        <div class="cell has-text-weight-bold has-background-light">Accións</div>

        <!-- Filas de etiquetas -->
        <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cell "><?php echo e($etiqueta->id); ?></div>
            <div class="cell "><?php echo e($etiqueta->nombreEtiqueta); ?></div>
            <div class="cell ">
                <div class="buttons">
                    <button id="editar" class="button is-link">
                        <a href="/etiqueta/<?php echo e($etiqueta->id); ?>">Editar</a>
                    </button>
                    <form action="/eliminaretiqueta/<?php echo e($etiqueta->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="button is-danger" id="eliminar" type="submit">Eliminar</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.personalizada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/xestorIncidencias/resources/views/etiquetas/index.blade.php ENDPATH**/ ?>