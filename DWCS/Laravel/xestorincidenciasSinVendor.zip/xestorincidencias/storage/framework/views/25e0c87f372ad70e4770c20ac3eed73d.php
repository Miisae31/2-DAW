<?php $__env->startSection('corpo'); ?>
<h1 class="tituloCrud">Incidencias</h1><br>
<div style="display: flex;   justify-content: flex-end; ">
    <button><a class="crear button is-primary" href="/incidencia">Nova Incidencia</a></button>
</div>
<?php if(session('success')): ?>
    <div class="">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<table class="table is-bordered">
    <thead>
        <tr class="">
            <th class="">ID</th>
            <th class="">Titulo</th>
            <th class="">Detalle</th>
            <th class="">Fecha de Inicio</th>
            <th class="">Fecha de Fin</th>
            <th class="">Estado</th>
            <th class="">Comentarios</th>
            <th class="">Usuario</th>
        </tr>
    </thead>
    <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
            <tr class="border-b border-gray-300">
                <td class=""><?php echo e($incidencia->id); ?></td>
                <td class=""><?php echo e($incidencia->titulo); ?></td>
                <td class=""><?php echo e($incidencia->detalle); ?></td>
                <td class=""><?php echo e($incidencia->fechaInicio); ?></td>
                <td class=""><?php echo e($incidencia->fechaFin); ?></td>
                <td class=""><?php echo e($incidencia->estado); ?></td>
                <td class=""><?php echo e($incidencia->comentario); ?></td>
                <td class=""><?php echo e($incidencia->users_id); ?></td>
                <td class="">
                    <button id="editar" class="button is-link"><a href="/incidencia/<?php echo e($incidencia->id); ?>">Editar</a></button>
                </td>
                <td>
                    <form action="/incidenciaborrar/<?php echo e($incidencia->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button id="eliminar" class="button is-danger" type="submit">Eliminar</button>
                    </form>
                </td> 
            </tr>
        </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.personalizada', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/xestorIncidencias/resources/views/incidencias/index.blade.php ENDPATH**/ ?>