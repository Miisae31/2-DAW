<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('incidencias', function (Blueprint $table) {
            // Añadir el campo user_id
            $table->unsignedBigInteger('users_id')->after('fechaFin'); // Añade el campo después de 'fechaFin'
            
            // Añadir la clave foránea
            $table->foreign('users_id')->references('id')->on('users');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('incidencias', function (Blueprint $table) {
            // Eliminar la clave foránea
            $table->dropForeign(['users_id']);
            
            // Eliminar el campo user_id
            $table->dropColumn('users_id');
        });
    }
};