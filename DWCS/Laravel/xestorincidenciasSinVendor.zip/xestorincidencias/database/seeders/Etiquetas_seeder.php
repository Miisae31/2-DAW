<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Etiqueta;
use Illuminate\Support\Facades\DB;

class etiquetas_seeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('etiquetas')->delete();
        DB::statement('ALTER TABLE etiquetas AUTO_INCREMENT = 1');

        
        Etiqueta::create(['nombreEtiqueta' => 'Crítico']);
        Etiqueta::create(['nombreEtiqueta' => 'Alta Prioridad']);
        Etiqueta::create(['nombreEtiqueta' => 'Media Prioridad']);
        Etiqueta::create(['nombreEtiqueta' => 'Baja Prioridad']);
        Etiqueta::create(['nombreEtiqueta' => 'Error']);
        Etiqueta::create(['nombreEtiqueta' => 'Mejora']);
        Etiqueta::create(['nombreEtiqueta' => 'Solicitud']);
        Etiqueta::create(['nombreEtiqueta' => 'En Progreso']);
        Etiqueta::create(['nombreEtiqueta' => 'Resuelto']);
        Etiqueta::create(['nombreEtiqueta' => 'Pendiente']);
    }
}
