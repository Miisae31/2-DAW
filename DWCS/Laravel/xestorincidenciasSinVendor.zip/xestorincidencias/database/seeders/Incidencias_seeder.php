<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Incidencia;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class Incidencias_seeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Eliminar todos los registros existentes en la tabla
        DB::table('incidencias')->delete();

        // Reiniciar el autoincremento de la tabla
        DB::statement('ALTER TABLE incidencias AUTO_INCREMENT = 1');

        // Crear incidencias de prueba con usuario_id
        Incidencia::create([
            'titulo' => 'Error en el sistema',
            'detalle' => 'El sistema no permite iniciar sesión',
            'fechaInicio' => Carbon::now(),
            'fechaFin' => Carbon::now(),
            'estado' => 'pechada',
            'comentario' => 'Se está investigando el problema',
            'users_id' => 1, // Asignar un usuario_id
        ]);

        Incidencia::create([
            'titulo' => 'Problema de red',
            'detalle' => 'La conexión a internet es intermitente',
            'fechaInicio' => Carbon::now(),
            'fechaFin' => Carbon::now(),
            'estado' => 'traballando',
            'comentario' => 'Se ha contactado al proveedor de internet',
            'users_id' => 1, // Asignar un usuario_id
        ]);

        Incidencia::create([
            'titulo' => 'Actualización requerida',
            'detalle' => 'El software necesita una actualización urgente',
            'fechaInicio' => Carbon::now(),
            'fechaFin' => Carbon::now(),
            'estado' => 'pendente',
            'comentario' => 'La actualización se ha aplicado correctamente',
            'users_id' => 1, // Asignar un usuario_id
        ]);

        Incidencia::create([
            'titulo' => 'Solicitud de nueva funcionalidad',
            'detalle' => 'Se requiere agregar un nuevo módulo al sistema',
            'fechaInicio' => Carbon::now(),
            'fechaFin' => Carbon::now(),
            'estado' => 'pendente',
            'comentario' => 'En revisión por el equipo de desarrollo',
            'users_id' => 1, // Asignar un usuario_id
        ]);

        Incidencia::create([
            'titulo' => 'Error crítico en producción',
            'detalle' => 'El sistema se cae al realizar una acción específica',
            'fechaInicio' => Carbon::now(),
            'fechaFin' => Carbon::now(),
            'estado' => 'traballando',
            'comentario' => 'El equipo está trabajando en una solución',
            'users_id' => 1, // Asignar un usuario_id
        ]);
    }
}