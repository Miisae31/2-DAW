<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
    <link rel="stylesheet" href="ejercicio1.css">
</head>
<body>
<?php
    define('BENVIDA','Hola, ¿Qué tal?, ');
    printf ("<span class='spanCSS'>". BENVIDA . "%s </span>", " Hugo");
?>
    
</body>
</html>